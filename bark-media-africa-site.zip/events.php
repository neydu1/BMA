<?php
$pageTitle = 'Events';
$pageDesc = 'Spaces, AMAs, workshops and meetups hosted by the Bark Media Africa community.';
require __DIR__ . '/includes/header.php';
$sorted = $EVENTS;
usort($sorted, fn($a, $b) => strtotime($b['date']) - strtotime($a['date']));
$types = array_merge(['All'], array_values(array_unique(array_column($EVENTS, 'type'))));
?>
<?= page_banner('Events from our X timeline', 'Spaces, AMAs, workshops and meetups the community has hosted.') ?>

<section class="section">
  <div class="wrap">
    <div class="chips" role="group" aria-label="Filter events by type">
      <?php foreach ($types as $i => $t): ?>
        <button class="chip" type="button" aria-pressed="<?= $i === 0 ? 'true' : 'false' ?>" data-filter="<?= e($t) ?>"><?= e($t) ?></button>
      <?php endforeach; ?>
    </div>
    <ol class="timeline" id="timeline">
      <?php foreach ($sorted as $ev): $d = strtotime($ev['date']); ?>
        <li data-type="<?= e($ev['type']) ?>">
          <time datetime="<?= e($ev['date']) ?>"><b><?= date('j', $d) ?></b><span><?= date('M Y', $d) ?></span></time>
          <article class="event">
            <div class="event-meta"><span class="tag"><?= e($ev['type']) ?></span><span class="muted"><?= date('D, g:i a', $d) ?> WAT</span></div>
            <h3><?= e($ev['title']) ?></h3>
            <p><?= e($ev['summary']) ?></p>
            <p class="muted small">Host: <?= e($ev['host']) ?><?= $ev['guests'] ? ', with ' . e($ev['guests']) : '' ?><?= $ev['listeners'] ? ', ' . number_format($ev['listeners']) . ' listeners' : '' ?></p>
            <a class="text-link" href="<?= e($ev['link']) ?>" target="_blank" rel="noopener">View on X</a>
          </article>
        </li>
      <?php endforeach; ?>
    </ol>
    <div class="empty" id="events-empty" hidden>No events of this type yet.</div>
  </div>
</section>

<?= newsletter_block('events') ?>
<?php require __DIR__ . '/includes/footer.php'; ?>
