/* Sniff, the BMA guide: chat assistant + events pop-up.
   Works offline from the facts the server puts in window.BMA_ASSISTANT.
   If the server has an AI key (cfg.llm), questions the guide can't answer itself go to api/chat.php. */
(() => {
  const cfg = window.BMA_ASSISTANT;
  if (!cfg) return;
  const $ = (s, r = document) => r.querySelector(s);
  const reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;
  const mobile = () => matchMedia('(max-width: 640px)').matches;
  const store = {
    get(k) { try { return sessionStorage.getItem(k); } catch { return null; } },
    set(k, v) { try { sessionStorage.setItem(k, v); } catch {} },
    del(k) { try { sessionStorage.removeItem(k); } catch {} },
  };

  /* =================================================================
     1. EVENTS POP-UP: shows 10 seconds after the visitor starts scrolling
     ================================================================= */
  (() => {
    const cta = $('#event-cta');
    if (!cta) return;
    const KEY = 'bma-cta-seen';
    const force = /[?&]cta=1\b/.test(location.search);   // add ?cta=1 to any page to preview it again
    if (store.get(KEY) && !force) return;

    let shown = false, armed = false, startY = scrollY;
    const busy = () => !!$('#sn-panel.open') || !!$('.cart-drawer.open') || document.hidden;
    const show = () => {
      if (shown) return;
      if (busy()) return void setTimeout(show, 1500);   // wait until the visitor is free
      shown = true;
      cta.hidden = false;
      requestAnimationFrame(() => requestAnimationFrame(() => cta.classList.add('in')));
      store.set(KEY, '1');
    };
    const hide = () => {
      cta.classList.remove('in'); cta.classList.add('out');
      setTimeout(() => { cta.hidden = true; }, 400);
    };
    $('.ec-x', cta).addEventListener('click', hide);
    $('.ec-go', cta).addEventListener('click', () => store.set(KEY, '1'));
    document.addEventListener('keydown', e => { if (e.key === 'Escape' && shown && !cta.hidden) hide(); });
    window.addEventListener('bma:chat-open', () => { if (!cta.hidden) hide(); });

    const onScroll = () => {
      if (armed || Math.abs(scrollY - startY) < 40) return;   // real scrolling only
      armed = true;
      removeEventListener('scroll', onScroll);
      setTimeout(show, 10000);                                  // 10 seconds after scrolling begins
    };
    addEventListener('scroll', onScroll, { passive: true });
  })();

  /* =================================================================
     2. SNIFF: the chat guide
     ================================================================= */
  const launch = $('#sn-launch'), panel = $('#sn-panel'), log = $('#sn-log'), chipsEl = $('#sn-chips');
  const form = $('#sn-form'), input = $('#sn-input');
  if (!launch || !panel) return;

  const PAGES = {
    home:     { label: 'Home',          href: 'index.php' },
    about:    { label: 'About',         href: 'about.php' },
    services: { label: 'Services',      href: 'services.php' },
    events:   { label: 'Events',        href: 'events.php' },
    spaces:   { label: 'Spaces 24h',    href: 'spaces.php' },
    shop:     { label: 'Shop',          href: 'shop.php' },
    join:     { label: 'Join',          href: 'join.php' },
    partner:  { label: 'Partner with us', href: 'partner.php' },
  };
  const here = (({ index: 'home' })[window.BMA_PAGE]) || window.BMA_PAGE || 'home';
  const go = (key, label, href) => ({ label: label || ('Open ' + PAGES[key].label), href: href || PAGES[key].href });
  const ext = (label, href) => ({ label, href, ext: true });
  const S = cfg.site;
  const stats = cfg.stats.map(s => `${s.value} ${s.label}`).join(', ');

  /* ---------- Page-aware welcome + suggestions ---------- */
  const HINTS = {
    home:     ['What is BMA?', 'How do I join?', 'What are Doginals?', 'Take a tour'],
    about:    ['What is BMA?', 'What are your values?', 'Which countries?', 'Take a tour'],
    services: ['Hire an intern', 'Earn from X', 'Crypto onboarding', 'How do I join?'],
    events:   ['What events are coming up?', 'What are Spaces?', 'How do I join?', 'Get the newsletter'],
    spaces:   ['What are Spaces?', 'What events are coming up?', 'Is it free?', 'How do I join?'],
    shop:     ["What's in the shop?", 'Delivery options', 'How do I pay?', 'Where is my cart?'],
    join:     ['Is it free?', 'Become a country lead', 'What happens after I apply?', 'Hire an intern'],
    partner:  ['How does partnering work?', 'Is this an investment offer?', 'What happens after I submit?', 'Contact the team'],
  };
  const DEFAULT_CHIPS = ['What is BMA?', 'What are Doginals?', 'How do I join?', 'Take a tour'];
  const WELCOME = {
    home: "Ẹ káàbọ̀! I'm Sniff, the BMA guide. Ask me about Bark Media Africa or Doginals, or I can walk you around the site.",
    shop: "Hi, I'm Sniff. Looking at merch? I can tell you what's in the shop, delivery and how payment works.",
    partner: "Hi, I'm Sniff. Thinking of partnering with BMA? Ask me how it works before you fill in the form.",
    events: "Hi, I'm Sniff. I can tell you what's coming up and how to join a Space.",
    join: "Hi, I'm Sniff. Questions before you apply? Ask away.",
  };

  /* ---------- Intents ---------- */
  // kw: "phrase:weight, prefix*:weight". Weight 3 = very specific, 2 = clear keyword, 1 = weak hint.
  const kw = s => s.split(',').map(x => { x = x.trim(); const i = x.lastIndexOf(':'); return i > 0 ? [x.slice(0, i), +x.slice(i + 1)] : [x, 2]; });
  const evText = () => cfg.events.length
    ? cfg.events.slice(0, 3).map(e => `• ${e.title} (${e.type}), ${e.when}`).join('\n')
    : '';

  const INTENTS = [
    { id: 'greet', kw: kw('hi:2, hello:2, hey:2, hiya:2, sannu:3, karibu:3, akwaaba:3, good morning:3, good evening:3, good afternoon:3, howdy:2, yo:1'),
      reply: () => ({ text: "Hello! I'm Sniff, BMA's guide dog. I can explain BMA and Doginals, point you to the right page, or give you a quick tour. What would you like?", chips: DEFAULT_CHIPS }) },

    { id: 'who', kw: kw('who are you:4, what are you:4, your name:3, are you a bot:4, are you ai:4, are you real:4, are you human:4, sniff:3, chatbot:3, bot:2'),
      reply: () => ({ text: cfg.llm
          ? "I'm Sniff, BMA's guide dog. I'm an AI assistant that knows this site. I can get things wrong, so for anything important the team on X or Telegram are real people."
          : "I'm Sniff, BMA's guide dog. I'm an automated guide: I match your question to what BMA publishes on this site. For anything personal, the team on X or Telegram are real people.",
        links: [ext('Message us on X', S.x), ext('Telegram group', S.telegram)], chips: DEFAULT_CHIPS }) },

    { id: 'about', kw: kw('what is bma:5, about bma:4, bark media africa:4, bark media:3, bma:2, who is bma:4, your story:3, our story:3, about you:3, about us:3, what do you do:4, what does bma do:5, mission:2, collective:2'),
      reply: () => ({ text: `Bark Media Africa is the African chapter of the DoginalDogs community. It began as one X Space between African holders and today it's ${stats}. We onboard newcomers to crypto, help creators earn, host Spaces and train interns to run Web3 accounts.`,
        links: [go('about', 'Read our story'), go('services', 'See what we offer')], chips: ['What are Doginals?', 'How do I join?', 'Which countries?'] }) },

    { id: 'doginals', kw: kw('doginal*:4, doginal dogs:5, doginaldogs:5, dogecoin:3, doge:2, ordinal*:3, inscription*:3, inscribe*:3, drc:2, dunes:2'),
      reply: () => ({ text: "Doginals are inscriptions on the Dogecoin blockchain, the same idea as Bitcoin's Ordinals but on Doge. DoginalDogs is a collection in that ecosystem, and BMA is its African collective. I don't have supply, price or mint details, so ask in the community, and always do your own research.",
        links: [ext('Ask on Telegram', S.telegram), ext('Follow on X', S.x)], chips: ['How do I get started?', 'Staying safe', 'How do I join?'] }) },

    { id: 'start', kw: kw('get started:4, how do i start:4, where do i start:4, begin:2, beginner*:3, newbie:3, new to crypto:4, learn:2, onboarding:3, onboard:3, wallet*:2, first wallet:3, how to buy:3'),
      reply: () => ({ text: "Easy path: 1) Drop into a Space and just listen, no wallet needed. 2) When you're ready, apply and pick Crypto onboarding so the team can walk you through wallets and P2P safety. 3) Keep learning with the community.",
        links: [go('spaces', 'See Spaces'), go('join', 'Apply for onboarding', 'join.php?focus=Crypto+onboarding')], chips: ['Is it free?', 'Staying safe', 'What are Spaces?'] }) },

    { id: 'join', kw: kw('join:3, join bma:4, how do i join:5, become a member:4, membership:3, member:2, sign up:3, signup:3, apply:3, application:3, passport:3, register:3'),
      reply: () => ({ text: "Joining takes about two minutes: fill in the form on the Join page, tell us what you're interested in, and the team replies on Telegram or X, usually within two days.",
        links: [go('join', 'Open the Join form')], chips: ['Is it free?', 'What happens after I apply?', 'Become a country lead'] }) },

    { id: 'after_apply', kw: kw('what happens after:5, after i apply:5, after i submit:5, after applying:4, after i join:4, hear back:4, how long:3, how soon:3, when will you reply:4, reply time:3, response time:3, confirmation:3'),
      reply: () => ({ text: here === 'partner'
          ? "You get a confirmation email straight away with a copy of what you sent, then a member of the team replies personally within two days. If nothing arrives, check spam or message us on X or Telegram."
          : "After you apply, the team replies on Telegram or X, usually within two days. You'll also get a welcome email, so check spam if it doesn't show up.",
        links: [ext('Message us on X', S.x)], chips: DEFAULT_CHIPS }) },

    { id: 'free', kw: kw('free:3, cost:3, how much to join:5, price to join:4, fee:2, fees:2, pay to join:4, is it free:5, charge:2, paid:1'),
      reply: () => ({ text: "Joining the community and our public Spaces is free. Some services, like hiring an intern for your project, are paid. The team agrees scope and pricing with you directly.",
        links: [go('join', 'Join for free')], chips: ['Hire an intern', 'What are Spaces?'] }) },

    { id: 'spaces', kw: kw('what are spaces:5, space:2, spaces:3, x space:4, twitter space:4, live:1, listen:2, audio:2, stage:1, join a space:5, host a space:4'),
      reply: () => ({ text: "Spaces are our live X audio rooms, hosted every week. You can just listen, no wallet needed, and ask questions when you're ready. The Spaces page shows what's live now and everything from the last 24 hours.",
        links: [go('spaces', 'See Spaces 24h'), ext('Follow on X', S.x)], chips: ['What events are coming up?', 'How do I get started?'] }) },

    { id: 'events', kw: kw('event*:3, upcoming:3, coming up:3, calendar:2, schedule:2, ama:3, workshop*:3, meetup*:3, hangout:2, whats on:3, what is on:3, next space:3, when is:2, this week:2'),
      reply: () => {
        const t = evText();
        return { text: t
            ? `Coming up:\n${t}\nFollow ${S.handle} on X so you don't miss a Space.`
            : `No dated events are posted right now, but new Spaces and meetups are on the way. Follow ${S.handle} on X to be first to know.`,
          links: [go('events', 'See all events'), go('spaces', 'Spaces 24h'), ext('Follow on X', S.x)], chips: ['What are Spaces?', 'Get the newsletter'] };
      } },

    { id: 'shop', kw: kw("shop:3, store:3, merch:3, merchandise:3, hoodie*:3, tee:3, t shirt:3, tshirt:3, cap:2, bottle:3, tote:3, sleeve:2, sticker*:3, buy something:3, whats in the shop:5, what is in the shop:5, products:3, apparel:2"),
      reply: () => {
        const list = cfg.products.slice(0, 5).map(p => `• ${p.name}, ${p.price}`).join('\n');
        return { text: list ? `The BMA shop has:\n${list}\nPay by card, bank transfer or USSD through Paystack.` : 'The BMA shop has tees, hoodies, bottles and more. Pay by card, bank transfer or USSD through Paystack.',
          links: [go('shop', 'Browse the shop')], chips: ['Delivery options', 'How do I pay?', 'Where is my cart?'] };
      } },

    { id: 'shipping', kw: kw('ship*:3, deliver*:3, courier:2, pickup:3, pick up:3, international:2, abroad:2, how long will it take:3, arrive:2, postage:2'),
      reply: () => ({ text: cfg.shipping.length ? `Delivery options:\n${cfg.shipping.map(s => `• ${s.label}: ${s.price} (${s.eta})`).join('\n')}` : 'Delivery options and fees are shown at checkout.',
        links: [go('shop', 'Go to the shop')], chips: ['How do I pay?', "What's in the shop?"] }) },

    { id: 'pay', kw: kw('pay:2, payment*:3, paystack:4, card:2, transfer:2, ussd:3, checkout:3, how do i pay:5, refund*:2, receipt:3, order:2'),
      reply: () => ({ text: "At checkout you finish payment on Paystack's secure page by card, bank transfer or USSD. You get a receipt by email, and the team gets your delivery details. If a payment is cancelled you aren't charged and your cart stays put.",
        links: [go('shop', 'Back to the shop')], chips: ['Delivery options', 'Where is my cart?'] }) },

    { id: 'partner', kw: kw('partner*:4, partner with us:6, invest*:4, investor*:5, sponsor*:4, funder*:3, funding:3, fund:2, collaborat*:3, grant*:2, vc:2, venture:2, angel:2, support bma:3, back bma:3, brand deal:3, work with you:3'),
      reply: () => ({ text: "We'd love to hear from you. You can back the intern programme, sponsor Spaces and events, fund a country chapter or build with our shop. Fill in the short form on the Partner page: you'll get a confirmation email right away and a personal reply within two days.",
        links: [go('partner', 'Partner with us', 'partner.php#partner-form')], chips: ['Is this an investment offer?', 'What happens after I submit?', 'Contact the team'] }) },

    { id: 'terms', kw: kw('investment offer:6, is this an investment:6, returns:4, roi:4, profit*:3, securities:4, equity:3, token sale:4, how does partnering work:6, terms:2, valuation:3, stake:2, share*:1'),
      reply: () => ({ text: "The Partner page starts a conversation. It isn't an offer of securities and BMA doesn't publish investment terms or promise returns on the site. Tell the team what you have in mind and they'll reply personally; anything agreed is agreed separately and in writing.",
        links: [go('partner', 'Open the Partner page', 'partner.php#partner-form')], chips: ['What happens after I submit?', 'Contact the team'] }) },

    { id: 'lead', kw: kw('country lead:6, chapter*:4, start a chapter:5, lead my country:5, lead a country:5, kenya:3, egypt:3, rwanda:3, cameroon:2, morocco:2, local community:2'),
      reply: () => ({ text: "We're recruiting country leads in Kenya, Egypt, Rwanda and beyond to start local BMA chapters. On the Join form choose \"Becoming a country lead\" and tell us about your community.",
        links: [go('join', 'Apply as a country lead', 'join.php?focus=Becoming+a+country+lead'), go('partner', 'Fund a chapter', 'partner.php?interest=Country+chapters#partner-form')], chips: ['Which countries?', 'How do I join?'] }) },

    { id: 'nations', kw: kw('countries:4, country:3, nations:4, nation:3, where are you:4, where is bma:4, africa:2, nigeria:3, ghana:3, uganda:3, tanzania:3, ethiopia:3, south africa:3, lagos:2, abuja:2, accra:2, nairobi:2, which countries:6'),
      reply: () => ({ text: `We have members in ${cfg.nations.length} nations:\n${cfg.nations.map(n => `${n.flag} ${n.name}: ${n.members}`).join('\n')}\nNot on the list? You can still join, and we're recruiting leads for more countries.`,
        links: [go('home', 'See the globe', 'index.php#nations'), go('join', 'Join')], chips: ['Become a country lead', 'How do I join?'] }) },

    { id: 'intern', kw: kw('intern*:4, hire:3, hiring:3, account management:4, manage my account:4, manage account:4, social media manager:3, community manager:3, x account:3'),
      reply: () => ({ text: "Trained BMA interns can run your project's X account: curating the feed, hosting Spaces and keeping your community active and genuine. Choose \"Hire an account intern\" on the Join form and the team will agree scope and pricing with you.",
        links: [go('join', 'Hire an intern', 'join.php?focus=Hire+an+account+intern'), go('services', 'About the service')], chips: ['Is it free?', 'Earn from X'] }) },

    { id: 'monetize', kw: kw('monetiz*:4, monetis*:4, earn:3, earning:3, make money:3, income:3, payout*:4, creator*:3, sponsorship*:2, revenue:2'),
      reply: () => ({ text: "We help African creators earn from X, Spaces, sponsorships and decentralized social platforms through real partnerships, with practical advice rather than hype. Choose \"Social media monetization\" on the Join form to get started.",
        links: [go('join', 'Get monetization help', 'join.php?focus=Social+media+monetization'), go('services', 'See services')], chips: ['Hire an intern', 'How do I join?'] }) },

    { id: 'services', kw: kw('services:4, service:3, what do you offer:5, what can you do:4, offer*:2, help me:1, programme:2, program:2'),
      reply: () => ({ text: `BMA offers:\n${cfg.services.map(s => `• ${s.title}: ${s.summary}`).join('\n')}`,
        links: [go('services', 'See services'), go('join', 'Join')], chips: ['Hire an intern', 'Earn from X', 'Crypto onboarding'] }) },

    { id: 'values', kw: kw('ubuntu:4, harambee:4, sankofa:4, values:3, value:2, believe:2, culture:2, principles:2, adinkra:2'),
      reply: () => ({ text: "Three ideas guide BMA: Ubuntu (I am because we are), Harambee (all pull together) and Sankofa (go back and fetch it): we carry African stories and values into the future we build.",
        links: [go('about', 'Read more')], chips: ['What is BMA?', 'How do I join?'] }) },

    { id: 'safety', kw: kw('seed phrase:5, recovery phrase:5, private key:5, scam*:4, phishing:4, hack*:3, safe:2, safety:3, staying safe:5, security:3, secure:2, rug:2, fake:2, p2p:3, trust:1'),
      reply: () => ({ text: "Golden rules: never share your seed phrase or private key with anyone, admins included. Check links carefully, ignore DMs offering free tokens, and be strict with P2P trades. BMA's onboarding clinics cover all of this.",
        links: [go('join', 'Get onboarding help', 'join.php?focus=Crypto+onboarding'), go('events', 'Find a clinic')], chips: ['How do I get started?', 'What events are coming up?'] }) },

    { id: 'advice', kw: kw('should i buy:6, should i invest:6, price prediction:6, predict*:3, will it pump:6, pump:3, moon:2, go up:2, good investment:5, worth buying:5, how high:2, 100x:4, 10x:4, when to sell:5, when to buy:5, financial advice:4, best coin:4'),
      reply: () => ({ text: "I can't give financial advice or price calls, and nobody can promise where a price will go. What I can do is point you to BMA's onboarding so you learn the basics and the risks first.",
        links: [go('join', 'Get onboarding help', 'join.php?focus=Crypto+onboarding')], chips: ['Staying safe', 'What are Spaces?'] }) },

    { id: 'newsletter', kw: kw('newsletter:5, weekly bark:5, subscribe:4, mailing list:4, email list:4, updates:2, friday email:3'),
      reply: () => ({ text: "The weekly bark is one email every Friday: upcoming Spaces, Doginals news from an African point of view and open intern roles. You'll find the sign-up box in the footer of every page.",
        links: [go('events', 'Sign up on the Events page', 'events.php#newsletter')], chips: ['What events are coming up?'] }) },

    { id: 'contact', kw: kw('contact*:4, reach:3, email:3, telegram:4, twitter:3, x handle:4, dm:2, talk to someone:5, talk to a human:6, speak to:4, human:3, support:3, help:1, team:2, message you:3'),
      reply: () => ({ text: `The quickest way to reach the team is X (${S.handle}) or the Telegram group. You can also email ${S.email}.`,
        links: [ext('Message on X', S.x), ext('Telegram group', S.telegram), { label: 'Email us', href: 'mailto:' + S.email, ext: true }], chips: DEFAULT_CHIPS }) },

    { id: 'cart', kw: kw('cart:4, basket:3, my bag:3, where is my cart:6, view cart:5'),
      reply: () => ({ text: 'Opening your cart for you.', action: 'cart', chips: ['Delivery options', 'How do I pay?'] }) },

    { id: 'tour', kw: kw('tour:5, take a tour:6, show me around:6, guide me:5, navigate:3, walk me through:5, where do i go:4, lost:3, explore:2, i am new:2, im new:2'),
      reply: () => tourStep(0) },

    { id: 'thanks', kw: kw('thanks:3, thank you:4, thx:3, cheers:2, appreciate:2, nice:1, great:1, awesome:1, cool:1'),
      reply: () => ({ text: "Anytime! Anything else I can sniff out for you?", chips: DEFAULT_CHIPS }) },

    { id: 'bye', kw: kw('bye:3, goodbye:3, see you:3, later:1, cya:3'),
      reply: () => ({ text: 'Go well! I\'ll be here if you need me. 🐾', chips: [] }) },
  ];

  /* ---------- Guided tour ---------- */
  const TOUR = [
    ['home',     "Stop 1, Home. The front door: a 3D globe of our nations, live Space status and ways to get involved."],
    ['about',    "Stop 2, About. How one X Space became a pan-African community, and the values behind it."],
    ['spaces',   "Stop 3, Spaces 24h. What's live right now and everything we hosted in the last 24 hours. Just listen, no wallet needed."],
    ['events',   "Stop 4, Events. AMAs, workshops and meetups, plus the Friday newsletter sign-up."],
    ['shop',     "Stop 5, Shop. BMA merch with Paystack checkout by card, bank transfer or USSD."],
    ['partner',  "Stop 6, Partner with us. For sponsors, funders and anyone who wants to back the intern programme or a new chapter."],
    ['join',     "Final stop, Join. Your BMA passport: two minutes, free, and the team replies within two days."],
  ];
  function tourStep(i) {
    i = Math.max(0, Math.min(TOUR.length - 1, i));
    ctx.tour = i;
    const [key, text] = TOUR[i];
    const last = i === TOUR.length - 1;
    return { text, links: [go(key, 'Take me there')], chips: last ? ['Restart tour', 'How do I join?'] : ['Next stop', 'End tour'] };
  }

  /* ---------- Matching ---------- */
  const ctx = { tour: -1, llmTries: 0 };
  const norm = s => ' ' + s.toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[^a-z0-9$]+/g, ' ').trim() + ' ';
  const hit = (t, p) => p.endsWith('*') ? t.includes(' ' + p.slice(0, -1)) : t.includes(' ' + p + ' ');

  function match(text) {
    const t = norm(text);
    const scored = INTENTS.map(it => ({ it, score: it.kw.reduce((n, [p, w]) => n + (hit(t, p) ? w : 0), 0) }))
      .filter(x => x.score > 0).sort((a, b) => b.score - a.score);
    const best = scored[0], second = scored[1];
    return { best, confident: !!best && best.score >= 3 && (!second || best.score > second.score) || (!!best && best.score >= 2 && !second) };
  }

  const NAV_VERB = /\b(take me|go to|open|show me|bring me|head to|visit|navigate to|send me)\b/i;
  const NAV_WORDS = [
    ['cart',     /\b(cart|basket)\b/i],
    ['partner',  /\b(partner\w*|invest\w*|sponsor\w*)\b/i],
    ['spaces',   /\bspaces?\b/i],
    ['events',   /\bevents?\b/i],
    ['shop',     /\b(shop|store|merch)\b/i],
    ['join',     /\b(join|sign ?up|apply)\b/i],
    ['services', /\bservices?\b/i],
    ['about',    /\b(about|story)\b/i],
    ['home',     /\b(home|homepage|main page|start page)\b/i],
  ];

  function suspiciousSeed(text) {
    const words = text.trim().toLowerCase().split(/\s+/);
    return (words.length === 12 || words.length === 15 || words.length === 18 || words.length === 24) && words.every(w => /^[a-z]{3,8}$/.test(w));
  }

  function fallback() {
    return { text: "I'm not sure I have that one. I'm best with BMA, Doginals, Spaces, events, the shop and partnering. The team on X or Telegram can answer anything else.",
      links: [ext('Ask the team on X', S.x), ext('Telegram group', S.telegram)], chips: HINTS[here] || DEFAULT_CHIPS };
  }

  /* ---------- Rendering + history ---------- */
  let hist = [];
  try { hist = JSON.parse(store.get('sn-hist') || '[]'); } catch { hist = []; }
  const save = () => store.set('sn-hist', JSON.stringify(hist.slice(-40)));

  const scrollDown = () => { log.scrollTop = log.scrollHeight; };

  function linkEl(l) {
    const a = document.createElement('a');
    a.className = 'sn-link'; a.href = l.href; a.textContent = l.label;
    if (l.ext && !l.href.startsWith('mailto:')) { a.target = '_blank'; a.rel = 'noopener'; }
    else if (!l.ext) a.addEventListener('click', () => { if (mobile()) store.set('sn-open', '0'); });
    return a;
  }
  function bubble(m) {
    if (m.who === 'note') {
      const n = document.createElement('div'); n.className = 'sn-note'; n.textContent = m.text; log.appendChild(n); return n;
    }
    const row = document.createElement('div'); row.className = 'sn-msg ' + (m.who === 'me' ? 'me' : 'bot');
    const b = document.createElement('div'); b.className = 'sn-bubble'; b.textContent = m.text; row.appendChild(b);
    if (m.links?.length) { const w = document.createElement('div'); w.className = 'sn-links'; m.links.forEach(l => w.appendChild(linkEl(l))); row.appendChild(w); }
    log.appendChild(row); return row;
  }
  function setChips(list) {
    chipsEl.textContent = '';
    (list || []).slice(0, 4).forEach(c => {
      const b = document.createElement('button'); b.type = 'button'; b.className = 'sn-chip'; b.textContent = c;
      b.addEventListener('click', () => ask(c));
      chipsEl.appendChild(b);
    });
    chipsEl.hidden = !chipsEl.children.length;
  }
  function push(m, render = true) {
    hist.push(m); save();
    if (render) { bubble(m); scrollDown(); }
  }
  function typing() {
    const row = document.createElement('div'); row.className = 'sn-msg bot';
    row.innerHTML = '<div class="sn-bubble sn-typing" aria-label="Sniff is typing"><i></i><i></i><i></i></div>';
    log.appendChild(row); scrollDown(); return row;
  }

  function botSay(r, delay) {
    return new Promise(res => {
      const t = typing();
      const wait = reduce ? 0 : (delay ?? Math.min(900, 380 + (r.text || '').length * 5));
      setTimeout(() => {
        t.remove();
        push({ who: 'bot', text: r.text, links: r.links, chips: r.chips });
        setChips(r.chips && r.chips.length ? r.chips : (r.chips ? [] : (HINTS[here] || DEFAULT_CHIPS)));
        if (r.action === 'cart') document.querySelector('[data-cart-open]')?.click();
        res();
      }, wait);
    });
  }

  let busy = false;
  async function ask(raw) {
    const text = raw.trim().slice(0, 300);
    if (!text || busy) return;
    busy = true;
    input.value = '';
    setChips([]);

    // Never echo or store something that looks like a seed phrase
    if (suspiciousSeed(text)) {
      await botSay({ text: "Whoa, that looks like it could be a wallet seed phrase. Never type or share those anywhere, with anyone, including me. I haven't saved it. If it's real, move your funds to a new wallet.", chips: ['Staying safe'] }, 300);
      busy = false; return;
    }
    push({ who: 'me', text });

    const low = text.toLowerCase();

    // Tour controls
    if (/^(next stop|next)$/i.test(low) && ctx.tour >= 0) { await botSay(tourStep(ctx.tour + 1)); busy = false; return; }
    if (/^(restart tour)$/i.test(low)) { await botSay(tourStep(0)); busy = false; return; }
    if (/^(end tour|stop|exit)$/i.test(low)) { ctx.tour = -1; await botSay({ text: 'Tour ended. Ask me anything, any time.', chips: HINTS[here] || DEFAULT_CHIPS }); busy = false; return; }

    // "Take me to ..." actually takes them
    if (NAV_VERB.test(text)) {
      const hitNav = NAV_WORDS.find(([, re]) => re.test(text));
      if (hitNav) {
        const key = hitNav[0];
        if (key === 'cart') { await botSay({ text: 'Opening your cart.', action: 'cart' }, 250); busy = false; return; }
        const p = PAGES[key];
        await botSay({ text: key === here ? `You're already on ${p.label}. Scroll around, or ask me anything about it.` : `On it, taking you to ${p.label}…`, links: key === here ? [] : [go(key, 'Go now')] }, 250);
        if (key !== here) { if (mobile()) store.set('sn-open', '0'); setTimeout(() => { location.href = p.href; }, reduce ? 0 : 900); }
        busy = false; return;
      }
    }

    const m = match(text);
    if (m.confident) {
      ctx.last = m.best.it.id;
      await botSay(m.best.it.reply());
    } else if (cfg.llm && ctx.llmTries < 30) {
      ctx.llmTries++;
      const r = await askAI();
      await botSay(r || (m.best && m.best.score >= 3 ? m.best.it.reply() : fallback()), r ? 0 : 200);
    } else {
      await botSay(m.best && m.best.score >= 3 ? m.best.it.reply() : fallback());
    }
    busy = false;
    if (!mobile()) input.focus();
  }

  async function askAI() {
    const t = typing();
    try {
      const msgs = hist.filter(h => h.who === 'me' || h.who === 'bot').slice(-8).map(h => ({ role: h.who === 'me' ? 'user' : 'assistant', content: h.text }));
      const res = await fetch('api/chat.php', {
        method: 'POST', credentials: 'same-origin',
        headers: { 'Content-Type': 'application/json', 'X-CSRF': document.querySelector('meta[name="csrf"]')?.content || '' },
        body: JSON.stringify({ messages: msgs }),
      });
      const data = await res.json();
      t.remove();
      if (res.status === 429 && data.reply) return { text: data.reply, chips: HINTS[here] || DEFAULT_CHIPS };
      if (!data.ok || !data.reply) return null;
      const page = Object.values(PAGES).find(p => p.href === data.link);
      return { text: data.reply, links: page ? [{ label: 'Open ' + page.label, href: page.href }] : [], chips: HINTS[here] || DEFAULT_CHIPS };
    } catch { t.remove(); return null; }
  }

  /* ---------- Open / close ---------- */
  let isOpen = false;
  function open(focus = true) {
    if (isOpen) return;
    isOpen = true;
    panel.hidden = false;
    launch.setAttribute('aria-expanded', 'true');
    launch.classList.add('seen'); store.set('sn-seen', '1');
    requestAnimationFrame(() => requestAnimationFrame(() => panel.classList.add('open')));
    document.documentElement.classList.toggle('sn-lock', mobile());
    store.set('sn-open', '1');
    dispatchEvent(new Event('bma:chat-open'));
    if (!log.children.length) start();
    scrollDown();
    if (focus && !mobile()) setTimeout(() => input.focus(), 250);
  }
  function close() {
    if (!isOpen) return;
    isOpen = false;
    panel.classList.remove('open');
    launch.setAttribute('aria-expanded', 'false');
    document.documentElement.classList.remove('sn-lock');
    store.set('sn-open', '0');
    setTimeout(() => { if (!isOpen) panel.hidden = true; }, reduce ? 0 : 280);
    launch.focus({ preventScroll: true });
  }

  function start() {
    // Restore the conversation, or begin a fresh one
    if (hist.length) {
      hist.forEach(m => bubble(m));
      const lastPage = store.get('sn-page');
      if (lastPage && lastPage !== here) {
        const note = { who: 'note', text: `You're now on ${PAGES[here]?.label || 'this page'}` };
        hist.push(note); save(); bubble(note);
      }
      const lastBot = [...hist].reverse().find(m => m.who === 'bot');
      setChips(lastPage && lastPage !== here ? (HINTS[here] || DEFAULT_CHIPS) : (lastBot?.chips ?? HINTS[here] ?? DEFAULT_CHIPS));
    } else {
      push({ who: 'bot', text: WELCOME[here] || WELCOME.home, chips: HINTS[here] || DEFAULT_CHIPS });
      setChips(HINTS[here] || DEFAULT_CHIPS);
    }
    store.set('sn-page', here);
  }

  function reset() {
    hist = []; save(); log.textContent = ''; ctx.tour = -1; store.del('sn-page');
    start(); scrollDown();
  }

  launch.addEventListener('click', () => (isOpen ? close() : open()));
  $('#sn-close').addEventListener('click', close);
  $('#sn-reset').addEventListener('click', reset);
  form.addEventListener('submit', e => { e.preventDefault(); ask(input.value); });
  document.addEventListener('keydown', e => { if (e.key === 'Escape' && isOpen) close(); });
  // Other parts of the site can open the guide: <a href="#" data-sniff> or <button data-sniff="events">
  document.addEventListener('click', e => {
    const t = e.target.closest('[data-sniff]');
    if (!t) return;
    e.preventDefault(); open();
    if (t.dataset.sniff) ask(t.dataset.sniff);
  });
  addEventListener('resize', () => { document.documentElement.classList.toggle('sn-lock', isOpen && mobile()); });

  if (!store.get('sn-seen')) launch.classList.add('new');
  // Keep the chat open across pages on desktop; on phones it would cover the page you just opened.
  if (store.get('sn-open') === '1' && !mobile() && hist.length) open(false);
})();
