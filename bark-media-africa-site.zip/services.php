<?php
$pageTitle = 'Services';
$pageDesc = 'Crypto onboarding, social media monetization, X account management and Web3 experiences from Bark Media Africa.';
require __DIR__ . '/includes/header.php';
?>
<?= page_banner('Services for builders and Web3 projects', "Whether you're starting from zero or launching a project, there's a BMA team for it.") ?>

<section class="section">
  <div class="wrap grid g-2">
    <?php foreach ($SERVICES as $s): ?>
      <article class="tilt-card wide" data-tilt>
        <div class="tilt-inner">
          <span class="symbol"><?= e($s['symbol']) ?><i><?= e($s['meaning']) ?></i></span>
          <h3><?= e($s['title']) ?></h3>
          <p class="summary"><?= e($s['summary']) ?></p>
          <p class="muted"><?= e($s['body']) ?></p>
          <a class="text-link" href="join.php?focus=<?= urlencode($s['title'] === 'X account management' ? 'Hire an account intern' : ($s['title'] === 'Web3 experiences' ? 'Hosting a Space with BMA' : $s['title'])) ?>">Ask about <?= e(lcfirst($s['title'])) ?></a>
        </div>
      </article>
    <?php endforeach; ?>
  </div>
</section>

<section class="section tinted">
  <div class="wrap">
    <div class="section-head">
      <h2>More from the BMA ecosystem</h2>
      <p class="muted">Ways to work with us, learn with us or rep us.</p>
    </div>
    <div class="grid g-4">
      <?php foreach ($OFFERS as $o): ?>
        <article class="offer">
          <span class="tag"><?= e($o['tag']) ?></span>
          <h3><?= e($o['title']) ?></h3>
          <p class="muted"><?= e($o['body']) ?></p>
          <a class="btn btn-gold" href="<?= e($o['link']) ?>"><?= e($o['cta']) ?></a>
        </article>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<section class="section">
  <div class="wrap narrow">
    <h2>Questions</h2>
    <?php foreach ($FAQ as $f): ?>
      <details class="faq"><summary><?= e($f['q']) ?></summary><p><?= e($f['a']) ?></p></details>
    <?php endforeach; ?>
  </div>
</section>

<?= join_cta() ?>
<?php require __DIR__ . '/includes/footer.php'; ?>
