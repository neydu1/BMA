<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/functions.php';
require_once __DIR__ . '/data.php';
require_once __DIR__ . '/products.php';
require_once __DIR__ . '/components.php';

$page = current_page();
$pageTitle = $pageTitle ?? $SITE['name'];
$pageDesc = $pageDesc ?? "Bark Media Africa is the African chapter of the DoginalDogs community: weekly X Spaces, crypto onboarding and trained interns for Web3 projects.";
$bodyClass = $bodyClass ?? '';
?><!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
  <title><?= e($pageTitle === $SITE['name'] ? $SITE['name'] . ' — ' . $SITE['tagline'] : $pageTitle . ' | ' . $SITE['name']) ?></title>
  <meta name="description" content="<?= e($pageDesc) ?>">
  <meta name="theme-color" content="#16124A">
  <meta property="og:title" content="<?= e($pageTitle) ?>">
  <meta property="og:description" content="<?= e($pageDesc) ?>">
  <meta property="og:image" content="<?= e($SITE['heroImage']) ?>">
  <meta name="csrf" content="<?= e(csrf_token()) ?>">
  <link rel="icon" href="<?= e($SITE['logo']) ?>">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Bricolage+Grotesque:opsz,wght@12..96,400;12..96,600;12..96,800&family=Instrument+Sans:wght@400;500;600&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="assets/css/style.css?v=3">
  <link rel="stylesheet" href="assets/css/extras.css?v=1">
  <script>document.documentElement.classList.add("js")</script>
</head>
<body class="<?= e($bodyClass) ?>">
<a class="skip" href="#main">Skip to content</a>

<header class="site-header" id="top">
  <div class="wrap nav-row">
    <a class="brand" href="index.php" aria-label="<?= e($SITE['name']) ?> home">
      <img src="<?= e($SITE['logo']) ?>" alt="" width="44" height="44">
      <span><b><?= e($SITE['name']) ?></b><small><?= e($SITE['tagline']) ?></small></span>
    </a>

    <nav class="main-nav" id="main-nav" aria-label="Main">
      <?php foreach ($NAV as $key => $label): ?>
        <a href="<?= $key ?>.php" <?= $page === $key ? 'aria-current="page"' : '' ?>><?= e($label) ?></a>
      <?php endforeach; ?>
      <a href="partner.php" <?= $page === 'partner' ? 'aria-current="page"' : '' ?>>Partner</a>
      <a class="btn btn-gold nav-join" href="join.php" <?= $page === 'join' ? 'aria-current="page"' : '' ?>>Join the community</a>
    </nav>

    <button class="cart-btn" type="button" data-cart-open aria-label="Open cart">
      <svg viewBox="0 0 24 24" width="22" height="22" aria-hidden="true"><path d="M6 7h12l-1 13H7L6 7Z" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round"/><path d="M9 7a3 3 0 0 1 6 0" fill="none" stroke="currentColor" stroke-width="1.8"/></svg>
      <span class="cart-count" data-cart-count hidden>0</span>
    </button>

    <button class="menu-btn" id="menu-btn" aria-expanded="false" aria-controls="main-nav">
      <span></span><span></span><span></span><b class="sr">Menu</b>
    </button>
  </div>
</header>

<main id="main">
