<?php
/* =================================================================
   BARK MEDIA AFRICA — SITE CONFIG
   Edit this file first. Everything else reads from here.
   ================================================================= */

// ---- Who gets notified when someone joins or subscribes ----------
define('ADMIN_EMAIL', 'barkmediafrica@gmail.com');        // TODO: your inbox
define('ADMIN_NAME',  'BMA Admin');

// ---- Outgoing mail (SMTP) ----------------------------------------
// Use your host's mailbox (cPanel "Email Accounts") or Gmail/Zoho/Brevo.
// If SMTP_HOST is left empty, PHP's built-in mail() is used instead.
define('SMTP_HOST',   'mail.barkmediafrica.com'); // e.g. smtp.gmail.com
define('SMTP_PORT',   465);                        // 465 = SSL, 587 = TLS
define('SMTP_SECURE', 'ssl');                      // 'ssl' or 'tls'
define('SMTP_USER',   'admin@barkmediafrica.com');
define('SMTP_PASS',   '@Barkmedia001');
define('MAIL_FROM',      'admin@barkmediafrica.com');
define('MAIL_FROM_NAME', 'Bark Media Africa');

// Send a "welcome" email to the new member / subscriber too?
define('SEND_CONFIRMATIONS', true);

// ---- Shop + Paystack ---------------------------------------------
// Get keys at dashboard.paystack.com > Settings > API Keys & Webhooks.
// Use the sk_test_/pk_test_ keys while testing, then switch to live.
define('PAYSTACK_SECRET_KEY', 'sk_test_xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
define('PAYSTACK_PUBLIC_KEY', 'pk_test_xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
define('SHOP_CURRENCY', 'NGN');          // Paystack currency: NGN, GHS, ZAR, KES, USD
define('SHOP_SYMBOL', '₦');

// Full public address of the site, no trailing slash. Leave '' to auto-detect.
define('SITE_URL', '');

// Password for /admin/orders.php (change this!)
define('ADMIN_PASSWORD', 'change-this-password');

// ---- Where submissions are saved (CSV backups) -------------------
define('STORAGE_DIR', __DIR__ . '/../storage');

date_default_timezone_set('Africa/Lagos');

$SITE = [
  'name'     => 'Bark Media Africa',
  'short'    => 'BMA',
  'tagline'  => 'DoginalDogs African Collective',
  'handle'   => '@barkmediaafrica',
  'xUrl'     => 'https://x.com/barkmediaafrica',
  'telegram' => 'https://t.me/barkmediaafrica',     // TODO: confirm
  'email'    => 'hello@barkmediaafrica.com',        // TODO: confirm
  'logo'     => 'assets/images/logo.png',
  'heroImage'      => 'https://vibe.filesafe.space/1789381503189835252/assets/6b47563c-c2f9-4721-87df-cc7a11d729e7.png',
  'communityImage' => 'https://vibe.filesafe.space/1789381503189835252/assets/5e037613-dca8-457b-ab07-22a414a0d4a8.png',
  'stats' => [
    ['value' => '250+', 'label' => 'active members'],
    ['value' => '6',    'label' => 'African nations'],
    ['value' => '42',   'label' => 'intern accounts managed'],
  ],
];

$NAV = [
  'index'    => 'Home',
  'about'    => 'About',
  'services' => 'Services',
  'events'   => 'Events',
  'spaces'   => 'Spaces 24h',
  'shop'     => 'Shop',
];
