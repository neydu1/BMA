# Bark Media Africa — community website

Multi-page PHP site with three.js 3D scenes, a newsletter, and email alerts when someone joins.
Runs on any PHP 7.4+ shared host (cPanel, Hostinger, Namecheap). No database, no Composer.

## 1. Set your email (required)

Open `includes/config.php`:

| Setting | What to put |
|---|---|
| `ADMIN_EMAIL` | The inbox that should receive new member and subscriber alerts |
| `SMTP_HOST`, `SMTP_PORT`, `SMTP_SECURE` | Your mail server. cPanel: `mail.yourdomain.com`, 465, `ssl`. Gmail: `smtp.gmail.com`, 587, `tls` |
| `SMTP_USER`, `SMTP_PASS` | Mailbox login. For Gmail use an App Password, not your normal password |
| `MAIL_FROM` | Must be the same mailbox as `SMTP_USER` on most hosts |
| `SEND_CONFIRMATIONS` | `true` also emails the new member/subscriber a welcome message |

Leave `SMTP_HOST` empty to fall back to PHP `mail()` (less reliable, often lands in spam).

## 2. Turn on the shop (Paystack)

1. Log in at dashboard.paystack.com > Settings > API Keys & Webhooks.
2. Copy the **test** secret and public keys into `PAYSTACK_SECRET_KEY` / `PAYSTACK_PUBLIC_KEY` in `includes/config.php`.
3. Set the **Webhook URL** to `https://yourdomain.com/api/paystack-webhook.php`. This confirms orders even if a buyer closes the tab before returning to the site.
4. Set `ADMIN_PASSWORD`, then place a test order with Paystack's test card (4084 0840 8408 4081, any future date, CVV 408, OTP 123456).
5. When that works, swap in the **live** keys.

Your server needs PHP's cURL extension (on by default on almost every host).

### How a sale works
1. Visitors add items to the cart (kept in their browser, synced across tabs).
2. At checkout, `api/checkout.php` re-prices every item from `includes/products.php`, so nobody can change prices in the browser, saves a pending order in `storage/orders/`, and opens Paystack's secure payment page (card, bank transfer, USSD).
3. Paystack sends the buyer back to `order-complete.php`, which **verifies the payment with Paystack's API** and checks the amount and currency before marking it paid. The webhook does the same thing in the background; whichever arrives first wins, and emails go out only once.
4. You get an email with the items, sizes, colours, phone number and delivery address. The buyer gets a receipt.
5. Manage orders at `/admin/orders.php`: see revenue, filter to "To ship", tap a phone number to open WhatsApp, and mark orders as shipped. Paid orders are also logged to `storage/orders.csv`.

### Editing products
Everything is in `includes/products.php`: name, price (in naira), description, colours and sizes. Prices there are placeholders.
Product images are drawn by `art.php` with the BMA logo on them, so every colour option has its own picture. When you have real product photos, add `'photo' => 'assets/images/shop/tee.jpg'` to a product and that photo is used instead.
Delivery options and fees are in `$SHIPPING` in the same file.

## 3. Upload

Upload everything to `public_html/`. Make sure `storage/` is writable (755 or 775).

## What happens on submit

**Join form** (`join.php` → `api/join.php`)
1. Validates the email and name, checks the CSRF token, blocks bots (honeypot) and floods (3 per 15 min).
2. Saves the member to `storage/members.csv` (so nobody is lost if email fails).
3. Emails **you** the member's name, email, Telegram/X handle, country, interest, message and join time. Hit Reply to answer them directly.
4. Sends the member a welcome email (if enabled).
5. If they ticked the newsletter box, adds them to `storage/subscribers.csv`.

**Newsletter** (footer on every page + home/events band → `api/subscribe.php`)
Saves to `storage/subscribers.csv`, skips duplicates, emails you, sends a welcome email.
To send newsletters, import the CSV into Mailchimp, Brevo or MailerLite, or add their API call where marked in `api/subscribe.php`.

Both forms work without JavaScript too (they post normally and redirect back).

## 3D scenes (`assets/js/scene3d.js`)

- **Home hero**: spinning gold BMA coin (paw + "Bark Media Africa" edge text, Ubuntu/Harambee/Sankofa on the back), kente-coloured orbit rings, a particle disc and floating crystals. Follows the mouse, flips as you scroll.
- **Home "nations" section**: dotted globe with Africa lit in gold, a pin per country (height = member count) and arcs flowing out from Abuja. Drag to spin. Built from the `$NATIONS` lat/lng in `includes/data.php`.
- **Inner page banners**: floating gold coins.
- **Shop hero**: a spinning branded water bottle with the kente band, a gold coin and floating stickers.

## Homepage sections
Hero (3D coin, counting stats) → live crypto price ticker (DOGE, BTC, ETH, SOL from CoinGecko, falls back to community news) → last 24h Spaces → "Your path into Web3" steps (the line draws as you scroll) → services (3D tilt) → "Inside the pack" gallery (parallax) → nations globe → "Rep the pack" shop rail → member quotes marquee → recent events → values → newsletter → join CTA.
The member quotes and gallery posters are **samples**: replace them with real quotes and event photos in `$VOICES` and `$GALLERY` in `includes/data.php` (drop photos in `assets/images/gallery/`).

three.js is bundled in `assets/vendor/three/` (no CDN needed). Scenes pause when off screen, render one still frame for people with reduced-motion turned on, and fall back to a plain gradient if WebGL is unavailable.

## Editing content

All text lives in `includes/data.php`: services, offers, nations, values, milestones, events, Spaces and FAQ.
Spaces use `hours_from_now()` for the demo; swap in real times like `'start' => '2026-10-10T19:00:00+01:00'`.

## Files

```
index.php  about.php  services.php  events.php  spaces.php  join.php  404.php
shop.php  product.php  checkout.php  order-complete.php
art.php                 product images (SVG with logo)
admin/orders.php        orders dashboard (password)
api/checkout.php        creates order + starts Paystack payment
api/paystack-webhook.php  Paystack confirms payments here
includes/products.php   ← products, prices, delivery fees
includes/orders.php     order storage, Paystack verify, order emails
assets/js/shop.js       cart drawer, product options, checkout
api/join.php            join form handler + admin email
api/subscribe.php       newsletter handler
includes/config.php     ← edit first
includes/data.php       content
includes/header.php / footer.php / components.php / functions.php / mailer.php
lib/                    PHPMailer 6.9.1
assets/css/style.css
assets/js/main.js       menu, greeting, tilt cards, AJAX forms
assets/js/scene3d.js    3D scenes
storage/                CSV backups + orders/ (web access blocked by .htaccess)
```

Still to confirm from the client: real contact email, Telegram link, and real event entries.

---

## Partner page, Sniff chat guide and events pop-up
New files are listed below. `includes/header.php` and `includes/footer.php` were also updated to add the Partner link, the new stylesheet, and the chat + pop-up. Nothing in `includes/config.php` has to change.

| File | What it is |
|---|---|
| `partner.php` | The Partner With Us page and investor form |
| `api/partner.php` | Saves the enquiry to `storage/partners.csv`, emails your team, emails the investor a confirmation |
| `includes/partner_data.php` | The form options (investor types, budgets, interests) and the four "where support goes" cards |
| `includes/assistant.php` | Builds Sniff's knowledge from `data.php` / `products.php` and prints the chat + pop-up |
| `api/chat.php` | Optional AI mode for Sniff (see below) |
| `assets/js/assistant.js`, `assets/js/partner.js` | Chat + pop-up logic, form behaviour |
| `assets/css/extras.css` | Styles for all of the above, plus small-phone fixes for the footer and nav |

### Testing the investor emails
Add `define('DEBUG_MAIL', true);` to `includes/config.php`, submit the form, and any mail error is shown in the response.
Remove it (or set it to `false`) before going live. Enquiries are saved to `storage/partners.csv` even if email fails.

### Sniff, the chat guide
Works out of the box: it answers from your site data (events, nations, shop, shipping, FAQ), so it stays up to date when you edit `data.php`.
Edit the replies in `assets/js/assistant.js` (the `INTENTS` list).

Optional AI mode: add `define('CHATBOT_API_KEY', 'your-anthropic-api-key');` to `includes/config.php`.
Questions Sniff can't answer itself then go to `api/chat.php`, which answers only from your site facts. The key stays on the server.
If the key is missing or the call fails, Sniff falls back to the built-in answers.

### Events pop-up
Appears once per visit, 10 seconds after the visitor starts scrolling. It shows the next upcoming item from `$EVENTS` in `data.php`
(or a generic "Stay tuned" if none are dated in the future). Add `?cta=1` to any page URL to preview it again.

