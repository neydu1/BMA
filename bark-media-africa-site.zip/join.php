<?php
$pageTitle = 'Join';
$pageDesc = 'Join Bark Media Africa: crypto onboarding, monetization support, Space access, or an intern for your project.';
require __DIR__ . '/includes/header.php';
$flash = $_SESSION['flash'] ?? null; unset($_SESSION['flash']);
$preFocus = $_GET['focus'] ?? '';
?>
<?= page_banner('Join Bark Media Africa', 'Get your BMA passport: onboarding, monetization support, Space access, or an intern for your project.') ?>

<section class="section">
  <div class="wrap join-grid">
    <div class="passport">
      <h2>Tell us about you</h2>
      <p class="muted">We reply on Telegram or X, usually within two days.</p>
      <form class="form" id="join-form" action="api/join.php" method="post" data-api="api/join.php" novalidate>
        <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
        <input type="text" name="website" class="hp" tabindex="-1" autocomplete="off" aria-hidden="true">
        <div><label for="fn">First name</label><input id="fn" name="first_name" autocomplete="given-name" required></div>
        <div><label for="ln">Last name</label><input id="ln" name="last_name" autocomplete="family-name"></div>
        <div class="full"><label for="em">Email address</label><input id="em" name="email" type="email" required autocomplete="email"></div>
        <div class="full"><label for="hd">Telegram or X handle</label><input id="hd" name="handle" placeholder="@yourhandle"></div>
        <div><label for="nt">Your country</label>
          <select id="nt" name="nation">
            <?php foreach (array_merge(array_map(fn($n) => $n['name'] . ' ' . $n['flag'], $NATIONS), $EXTRA_COUNTRIES) as $o): ?><option><?= e($o) ?></option><?php endforeach; ?>
          </select></div>
        <div><label for="fc">I'm interested in</label>
          <select id="fc" name="focus">
            <?php foreach ($FOCUS_OPTIONS as $o): ?><option <?= $o === $preFocus ? 'selected' : '' ?>><?= e($o) ?></option><?php endforeach; ?>
          </select></div>
        <div class="full"><label for="ms">Anything else? (optional)</label><textarea id="ms" name="message" rows="4"></textarea></div>
        <label class="full check"><input type="checkbox" name="newsletter" value="1" checked> Send me the weekly bark newsletter</label>
        <p class="full form-msg <?= $flash ? ($flash['ok'] ? 'ok' : 'err') : '' ?>" id="form-msg" role="status" aria-live="polite"><?= $flash ? e($flash['msg']) : '' ?></p>
        <div class="full"><button class="btn btn-gold" type="submit">Send my application</button></div>
      </form>
    </div>
    <aside class="panel-dark">
      <h3>Other ways to reach us</h3>
      <p><strong>X:</strong> <a href="<?= e($SITE['xUrl']) ?>" target="_blank" rel="noopener"><?= e($SITE['handle']) ?></a></p>
      <p><strong>Telegram:</strong> <a href="<?= e($SITE['telegram']) ?>" target="_blank" rel="noopener">Join the group</a></p>
      <p><strong>Email:</strong> <a href="mailto:<?= e($SITE['email']) ?>"><?= e($SITE['email']) ?></a></p>
      <div class="kente thin" aria-hidden="true"></div>
      <h3>Lead your country</h3>
      <p class="muted">We're looking for country leads in Kenya, Egypt, Rwanda and beyond to start local chapters. Pick "Becoming a country lead" in the form.</p>
    </aside>
  </div>
</section>
<?php require __DIR__ . '/includes/footer.php'; ?>
