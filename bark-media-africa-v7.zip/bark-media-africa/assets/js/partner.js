/* Partner With Us form: validation, AJAX submit, thank-you state. Works without JS too (plain POST + redirect). */
(() => {
  const form = document.getElementById('partner-form');
  if (!form) return;
  const $ = (s, r = form) => r.querySelector(s);
  const msg = document.getElementById('pf-msg');
  const btn = document.getElementById('pf-submit');
  const thanks = document.getElementById('pf-thanks');
  const csrf = document.querySelector('meta[name="csrf"]')?.content || '';
  const validEmail = v => /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(v);

  const say = (text, ok) => {
    msg.textContent = text;
    msg.classList.remove('ok', 'err');
    msg.classList.add(ok ? 'ok' : 'err');
  };
  const bad = (el, text) => {
    el.setAttribute('aria-invalid', 'true');
    (el.matches('fieldset') ? el.querySelector('input') : el).focus();
    el.scrollIntoView({ block: 'center', behavior: 'smooth' });
    say(text, false);
  };

  // Clear the red border as soon as the field is touched
  form.addEventListener('input', e => e.target.removeAttribute?.('aria-invalid'));
  form.addEventListener('change', e => {
    e.target.removeAttribute?.('aria-invalid');
    const fs = e.target.closest('fieldset'); if (fs) fs.removeAttribute('aria-invalid');
  });

  // If the page was opened from a card (?interest=...), bring the form into view
  if (/[?&]interest=/.test(location.search)) {
    setTimeout(() => document.getElementById('partner-card')?.scrollIntoView({ behavior: 'smooth', block: 'start' }), 350);
  }

  form.addEventListener('submit', async e => {
    e.preventDefault();
    form.querySelectorAll('[aria-invalid]').forEach(el => el.removeAttribute('aria-invalid'));

    const first = $('#pf-fn'), email = $('#pf-em'), typeSet = $('#pf-type'), consent = $('input[name="consent"]');
    if (!first.value.trim()) return bad(first, 'Enter your first name.');
    if (!validEmail(email.value.trim())) return bad(email, 'Enter a valid email address, like name@email.com.');
    if (!$('input[name="investor_type"]:checked')) return bad(typeSet, 'Choose how you are partnering with us.');
    if (!consent.checked) return bad(consent, 'Tick the box to confirm we can contact you.');

    const label = btn.textContent;
    btn.disabled = true; btn.textContent = 'Sending…';
    say('', true); msg.classList.remove('ok', 'err');

    const fd = new FormData(form);
    if (!fd.get('csrf')) fd.set('csrf', csrf);

    try {
      const res = await fetch(form.action, { method: 'POST', body: fd, headers: { 'X-Requested-With': 'fetch' }, credentials: 'same-origin' });
      let data;
      try { data = await res.json(); } catch { data = { ok: false, message: 'The server sent an unexpected reply. Please try again in a moment.' }; }
      if (data.ok) {
        document.getElementById('pf-thanks-text').textContent = data.message;
        form.hidden = true;
        document.querySelector('#partner-card > h2')?.setAttribute('hidden', '');
        document.querySelector('#partner-card > p.muted')?.setAttribute('hidden', '');
        thanks.hidden = false;
        thanks.focus({ preventScroll: true });
        document.getElementById('partner-card').scrollIntoView({ behavior: 'smooth', block: 'start' });
        return;
      }
      say(data.message || 'Something went wrong. Please try again.', false);
    } catch {
      say('Could not reach the server. Check your connection and try again.', false);
    }
    btn.disabled = false; btn.textContent = label;
  });
})();
