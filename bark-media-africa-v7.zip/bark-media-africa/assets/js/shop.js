/* BMA shop: cart (saved in this browser), drawer, product options, checkout */
(() => {
  const SHOP = window.BMA_SHOP || { products: {}, shipping: {}, symbol: '₦' };
  const KEY = 'bma_cart_v1';
  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => [...r.querySelectorAll(s)];
  const reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;
  const money = n => SHOP.symbol + Number(n).toLocaleString('en-NG');
  const esc = s => String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

  /* ---------- cart storage ---------- */
  const read = () => {
    try {
      const c = JSON.parse(localStorage.getItem(KEY) || '[]');
      return Array.isArray(c) ? c.filter(i => SHOP.products[i.id]) : [];
    } catch { return []; }
  };
  let cart = read();
  const save = () => { try { localStorage.setItem(KEY, JSON.stringify(cart)); } catch {} render(); };
  const lineKey = i => `${i.id}|${i.color}|${i.size || ''}`;
  const subtotal = () => cart.reduce((n, i) => n + SHOP.products[i.id].price * i.qty, 0);
  const count = () => cart.reduce((n, i) => n + i.qty, 0);

  function add(id, color, size = '', qty = 1) {
    const ex = cart.find(i => lineKey(i) === lineKey({ id, color, size }));
    if (ex) ex.qty = Math.min(20, ex.qty + qty); else cart.push({ id, color, size, qty });
    save();
  }
  function setQty(key, qty) {
    cart = cart.map(i => (lineKey(i) === key ? { ...i, qty: Math.max(0, Math.min(20, qty)) } : i)).filter(i => i.qty > 0);
    save();
  }

  /* ---------- toast ---------- */
  const toast = $('#toast');
  let tt;
  const say = msg => { if (!toast) return; toast.textContent = msg; toast.classList.add('show'); clearTimeout(tt); tt = setTimeout(() => toast.classList.remove('show'), 2600); };

  /* ---------- drawer ---------- */
  const drawer = $('#cart-drawer'), scrim = $('.drawer-scrim');
  let lastFocus = null;
  const openDrawer = () => {
    if (!drawer) return;
    lastFocus = document.activeElement;
    scrim.hidden = false; requestAnimationFrame(() => scrim.classList.add('show'));
    drawer.classList.add('open'); drawer.setAttribute('aria-hidden', 'false'); drawer.focus();
    document.body.classList.add('no-scroll');
  };
  const closeDrawer = () => {
    if (!drawer || !drawer.classList.contains('open')) return;
    drawer.classList.remove('open'); drawer.setAttribute('aria-hidden', 'true');
    scrim.classList.remove('show'); setTimeout(() => (scrim.hidden = true), 300);
    document.body.classList.remove('no-scroll');
    lastFocus?.focus?.();
  };
  $$('[data-cart-open]').forEach(b => b.addEventListener('click', openDrawer));
  $$('[data-cart-close]').forEach(b => b.addEventListener('click', closeDrawer));
  document.addEventListener('keydown', e => { if (e.key === 'Escape') closeDrawer(); });

  function lineHTML(i, compact = false) {
    const p = SHOP.products[i.id], k = lineKey(i);
    const variant = [p.colors.length > 1 ? i.color : '', i.size ? `Size ${i.size}` : ''].filter(Boolean).join(', ');
    return `<div class="cart-line" data-key="${esc(k)}">
      <img src="${esc(p.img[i.color] || Object.values(p.img)[0])}" alt="" width="72" height="72">
      <div class="cl-body"><b>${esc(p.name)}</b>${variant ? `<small>${esc(variant)}</small>` : ''}
        ${compact ? `<small>Qty ${i.qty}</small>` : `<div class="qty sm"><button type="button" data-step="-1" aria-label="Decrease">−</button><span>${i.qty}</span><button type="button" data-step="1" aria-label="Increase">+</button></div>`}
      </div>
      <div class="cl-end"><span>${money(p.price * i.qty)}</span>${compact ? '' : `<button type="button" class="link-btn" data-remove>Remove</button>`}</div>
    </div>`;
  }

  function render() {
    const n = count();
    $$('[data-cart-count]').forEach(el => { el.textContent = n; el.hidden = n === 0; });
    const lines = $('[data-cart-lines]');
    if (lines) {
      lines.innerHTML = cart.length ? cart.map(i => lineHTML(i)).join('')
        : `<div class="drawer-empty"><p><b>Your cart is empty.</b></p><p class="muted">Tees, hoodies, bottles and stickers are waiting.</p><a class="btn btn-gold" href="shop.php">Browse the shop</a></div>`;
      $('[data-cart-foot]').hidden = !cart.length;
      $('[data-cart-subtotal]').textContent = money(subtotal());
    }
    renderCheckout();
  }

  document.addEventListener('click', e => {
    const line = e.target.closest('.cart-line[data-key]');
    if (!line) return;
    const item = cart.find(i => lineKey(i) === line.dataset.key);
    if (!item) return;
    if (e.target.closest('[data-step]')) setQty(line.dataset.key, item.qty + Number(e.target.closest('[data-step]').dataset.step));
    if (e.target.closest('[data-remove]')) { setQty(line.dataset.key, 0); say(`${SHOP.products[item.id].name} removed`); }
  });

  /* ---------- fly-to-cart animation ---------- */
  function flyToCart(img) {
    const target = $('.cart-btn');
    if (!img || !target || reduce || !img.animate) return Promise.resolve();
    const a = img.getBoundingClientRect(), b = target.getBoundingClientRect();
    const ghost = img.cloneNode();
    ghost.className = 'fly-ghost';
    Object.assign(ghost.style, { left: a.left + 'px', top: a.top + 'px', width: a.width + 'px', height: a.height + 'px' });
    document.body.appendChild(ghost);
    const dx = b.left + b.width / 2 - (a.left + a.width / 2), dy = b.top + b.height / 2 - (a.top + a.height / 2);
    const anim = ghost.animate([
      { transform: 'translate(0,0) scale(1) rotate(0)', opacity: 1 },
      { transform: `translate(${dx * .6}px, ${dy - 120}px) scale(.5) rotate(-20deg)`, opacity: 1, offset: .6 },
      { transform: `translate(${dx}px, ${dy}px) scale(.08) rotate(-40deg)`, opacity: .4 },
    ], { duration: 750, easing: 'cubic-bezier(.5,0,.3,1)' });
    return anim.finished.then(() => {
      ghost.remove();
      target.classList.remove('bump'); void target.offsetWidth; target.classList.add('bump');
    });
  }

  /* ---------- product cards ---------- */
  document.addEventListener('click', e => {
    const sw = e.target.closest('.mini-sw');
    if (sw) {
      const card = sw.closest('.product-card');
      $$('.mini-sw', card).forEach(s => s.setAttribute('aria-pressed', s === sw));
      const img = $('[data-pc-img]', card); img.src = sw.dataset.src;
      const addBtn = $('[data-add]', card); if (addBtn) addBtn.dataset.color = sw.getAttribute('aria-label');
      return;
    }
    const addBtn = e.target.closest('[data-add]');
    if (addBtn) {
      const id = addBtn.dataset.add;
      add(id, addBtn.dataset.color || SHOP.products[id].colors[0]);
      flyToCart($('[data-pc-img]', addBtn.closest('.product-card')));
      say(`${SHOP.products[id].name} added to your cart`);
    }
  });

  // shop filter
  const filterChips = $$('[data-shop-filter]');
  filterChips.forEach(chip => chip.addEventListener('click', () => {
    filterChips.forEach(c => c.setAttribute('aria-pressed', c === chip));
    const f = chip.dataset.shopFilter;
    $$('#product-grid .product-card').forEach(card => {
      const show = f === 'All' || card.dataset.cat === f;
      card.hidden = !show;
      if (show && !reduce && card.animate) card.animate([{ opacity: 0, transform: 'translateY(14px) scale(.98)' }, { opacity: 1, transform: 'none' }], { duration: 400, easing: 'ease-out' });
    });
  }));

  /* ---------- product page ---------- */
  const pd = $('#pd-form');
  if (pd) {
    const id = pd.dataset.product, img = $('#pd-img'), cname = $('#color-name');
    $$('input[name="color"]', pd).forEach(r => r.addEventListener('change', () => {
      if (cname) cname.textContent = r.value;
      img.classList.add('swap');
      setTimeout(() => { img.src = r.dataset.src; img.alt = `${SHOP.products[id].name} in ${r.value}`; }, 180);
      img.onload = () => img.classList.remove('swap');
    }));
    const qty = $('input[name="qty"]', pd);
    $$('[data-qty]', pd).forEach(b => b.addEventListener('click', () => {
      qty.value = Math.max(1, Math.min(20, (parseInt(qty.value, 10) || 1) + Number(b.dataset.qty)));
    }));
    pd.addEventListener('submit', e => {
      e.preventDefault();
      const fd = new FormData(pd);
      const needsSize = SHOP.products[id].sizes.length > 0;
      const size = fd.get('size') || '';
      const msg = $('#size-msg');
      if (needsSize && !size) {
        msg.textContent = 'Choose a size first.';
        $('.sizes', pd).animate?.([{ transform: 'translateX(0)' }, { transform: 'translateX(-6px)' }, { transform: 'translateX(6px)' }, { transform: 'translateX(0)' }], { duration: 300 });
        $('input[name="size"]', pd).focus();
        return;
      }
      if (msg) msg.textContent = '';
      add(id, fd.get('color'), size, Math.max(1, parseInt(fd.get('qty'), 10) || 1));
      if (e.submitter?.value === 'buy') { location.href = 'checkout.php'; return; }
      flyToCart(img);
      say(`${SHOP.products[id].name} added to your cart`);
    });
  }

  /* ---------- checkout ---------- */
  const co = $('#checkout-form');
  function renderCheckout() {
    if (!co) return;
    $('#checkout-empty').hidden = cart.length > 0;
    co.hidden = cart.length === 0;
    $('[data-co-lines]').innerHTML = cart.map(i => lineHTML(i, true)).join('');
    const ship = Number($('input[name="shipping"]:checked', co)?.dataset.price || 0);
    $('[data-co-subtotal]').textContent = money(subtotal());
    $('[data-co-ship]').textContent = ship ? money(ship) : 'Free';
    $('[data-co-total]').textContent = money(subtotal() + ship);
    $('#pay-btn').textContent = `Pay ${money(subtotal() + ship)} with Paystack`;
  }
  if (co) {
    const addr = $('#address-fields'), country = $('#country-field'), state = $('#co-state');
    const syncShip = () => {
      const v = $('input[name="shipping"]:checked', co).value;
      addr.hidden = v === 'pickup';
      if (v === 'intl') state.value = 'Outside Nigeria';
      if (v === 'abuja') state.value = 'Abuja (FCT)';
      country.hidden = state.value !== 'Outside Nigeria';
      if (country.hidden) $('#co-country').value = 'Nigeria';
      renderCheckout();
    };
    $$('input[name="shipping"]', co).forEach(r => r.addEventListener('change', syncShip));
    state.addEventListener('change', () => { country.hidden = state.value !== 'Outside Nigeria'; });
    syncShip();

    co.addEventListener('submit', async e => {
      e.preventDefault();
      const msg = $('#co-msg'), btn = $('#pay-btn');
      const bad = (el, text) => { el.setAttribute('aria-invalid', 'true'); el.focus(); msg.className = 'form-msg err'; msg.textContent = text; };
      $$('[aria-invalid]', co).forEach(el => el.removeAttribute('aria-invalid'));
      const shipVal = $('input[name="shipping"]:checked', co).value;
      if (!$('#co-name').value.trim()) return bad($('#co-name'), 'Enter your full name.');
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test($('#co-email').value.trim())) return bad($('#co-email'), 'Enter a valid email address for your receipt.');
      if ($('#co-phone').value.replace(/\D/g, '').length < 7) return bad($('#co-phone'), 'Enter a phone number so the rider can reach you.');
      if (shipVal !== 'pickup' && !$('#co-address').value.trim()) return bad($('#co-address'), 'Enter a delivery address.');

      const label = btn.textContent;
      btn.disabled = true; btn.textContent = 'Opening Paystack…';
      msg.textContent = '';
      const fd = new FormData(co);
      fd.set('cart', JSON.stringify(cart));
      try {
        const res = await fetch('api/checkout.php', { method: 'POST', body: fd, headers: { 'X-Requested-With': 'fetch' }, credentials: 'same-origin' });
        const data = await res.json();
        if (data.ok && data.url) { location.href = data.url; return; }
        msg.className = 'form-msg err'; msg.textContent = data.message || 'Could not start payment. Try again.';
      } catch {
        msg.className = 'form-msg err'; msg.textContent = 'Could not reach the server. Check your connection and try again.';
      }
      btn.disabled = false; btn.textContent = label;
    });
  }

  /* ---------- after payment ---------- */
  if ($('[data-clear-cart]')) { cart = []; save(); }

  // keep tabs in sync
  addEventListener('storage', e => { if (e.key === KEY) { cart = read(); render(); } });
  render();
})();
