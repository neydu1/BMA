/* =================================================================
   BMA 3D scenes (three.js)
   • #hero3d   — spinning gold BMA coin in kente orbit rings, particle
                 disc, floating crystals; follows pointer and scroll
   • #globe3d  — dotted globe with Africa lit up, member pins and
                 arcs from the Abuja hub; drag to spin
   • .banner-3d — floating coins behind inner-page banners
   ================================================================= */
import * as THREE from 'three';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';

const REDUCE = matchMedia('(prefers-reduced-motion: reduce)').matches;
const COLORS = {
  gold: 0xF4B63F, goldDeep: 0xC98A14, green: 0x1F8A5B, red: 0xC8372D,
  bone: 0xF5EEE1, indigo: 0x3A33A0, night: 0x0F0C36,
};

/* ---------- helpers ---------- */
function makeRenderer(canvas) {
  const r = new THREE.WebGLRenderer({ canvas, antialias: true, alpha: true, powerPreference: 'high-performance' });
  r.setPixelRatio(Math.min(devicePixelRatio, 2));
  r.outputColorSpace = THREE.SRGBColorSpace;
  r.toneMapping = THREE.ACESFilmicToneMapping;
  r.toneMappingExposure = 1.1;
  return r;
}

function envFor(renderer) {
  const pm = new THREE.PMREMGenerator(renderer);
  const tex = pm.fromScene(new RoomEnvironment(), 0.04).texture;
  pm.dispose();
  return tex;
}

/** Runs a render loop only while the canvas is on screen and the tab is visible. */
function loop(canvas, frame) {
  let visible = true, raf = 0, last = performance.now();
  const tick = now => {
    const dt = Math.min((now - last) / 1000, 0.05); last = now;
    frame(dt, now / 1000);
    raf = requestAnimationFrame(tick);
  };
  const start = () => { if (!raf && visible && !document.hidden) { last = performance.now(); raf = requestAnimationFrame(tick); } };
  const stop = () => { cancelAnimationFrame(raf); raf = 0; };
  new IntersectionObserver(([e]) => { visible = e.isIntersecting; visible ? start() : stop(); }).observe(canvas);
  document.addEventListener('visibilitychange', () => (document.hidden ? stop() : start()));
  if (REDUCE) { frame(0, 0); return; }   // one still frame
  start();
}

function fit(renderer, camera, canvas) {
  const w = canvas.clientWidth, h = canvas.clientHeight;
  if (!w || !h) return;
  renderer.setSize(w, h, false);
  camera.aspect = w / h;
  camera.updateProjectionMatrix();
}

/* ---------- coin textures (drawn on canvas, no image files needed) ---------- */
function drawPaw(ctx, cx, cy, s, color) {
  ctx.fillStyle = color;
  ctx.beginPath(); ctx.ellipse(cx, cy + s * .28, s * .42, s * .34, 0, 0, Math.PI * 2); ctx.fill();
  [[-.46, -.12, .15, .2, -.35], [-.17, -.42, .15, .21, -.1], [.17, -.42, .15, .21, .1], [.46, -.12, .15, .2, .35]]
    .forEach(([x, y, rx, ry, rot]) => { ctx.beginPath(); ctx.ellipse(cx + x * s, cy + y * s, rx * s, ry * s, rot, 0, Math.PI * 2); ctx.fill(); });
}

function coinFaceTexture(back = false) {
  const S = 1024, c = document.createElement('canvas'); c.width = c.height = S;
  const ctx = c.getContext('2d'), m = S / 2;
  // cylinder caps map UVs 90° turned, so draw turned the other way
  ctx.translate(m, m); ctx.rotate(-Math.PI / 2); ctx.translate(-m, -m);
  const g = ctx.createRadialGradient(m * .7, m * .6, 40, m, m, m);
  g.addColorStop(0, '#FFE6A8'); g.addColorStop(.45, '#F4B63F'); g.addColorStop(1, '#B67A10');
  ctx.fillStyle = g; ctx.fillRect(0, 0, S, S);

  // raised rims
  ctx.lineWidth = 18; ctx.strokeStyle = '#8A5A08';
  ctx.beginPath(); ctx.arc(m, m, m - 22, 0, Math.PI * 2); ctx.stroke();
  ctx.lineWidth = 6; ctx.strokeStyle = '#FFE6A8';
  ctx.beginPath(); ctx.arc(m, m, m - 112, 0, Math.PI * 2); ctx.stroke();

  // text around the edge
  const text = back ? ' UBUNTU • HARAMBEE • SANKOFA • I AM BECAUSE WE ARE •' : ' BARK MEDIA AFRICA • DOGINALDOGS AFRICAN COLLECTIVE •';
  ctx.font = '600 50px "Bricolage Grotesque", Arial, sans-serif';
  ctx.fillStyle = '#5E3D05'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
  const chars = [...text], step = (Math.PI * 2) / chars.length;
  chars.forEach((ch, i) => {
    ctx.save(); ctx.translate(m, m); ctx.rotate(i * step - Math.PI / 2);
    ctx.translate(0, -(m - 70)); ctx.fillText(ch, 0, 0); ctx.restore();
  });

  // inner adinkra-style ring of diamonds
  for (let i = 0; i < 24; i++) {
    const a = (i / 24) * Math.PI * 2, r = m - 150;
    ctx.save(); ctx.translate(m + Math.cos(a) * r, m + Math.sin(a) * r); ctx.rotate(a + Math.PI / 4);
    ctx.fillStyle = i % 2 ? '#8A5A08' : '#1F8A5B'; ctx.fillRect(-9, -9, 18, 18); ctx.restore();
  }

  if (back) {
    ctx.font = '800 220px "Bricolage Grotesque", Arial, sans-serif';
    ctx.fillStyle = '#5E3D05'; ctx.fillText('BMA', m, m + 10);
  } else {
    drawPaw(ctx, m, m - 40, 250, '#5E3D05');
    ctx.font = '800 96px "Bricolage Grotesque", Arial, sans-serif';
    ctx.fillStyle = '#5E3D05'; ctx.fillText('BMA', m, m + 225);
  }
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace; t.anisotropy = 8;
  return t;
}

function coinEdgeTexture() {
  const c = document.createElement('canvas'); c.width = 1024; c.height = 32;
  const ctx = c.getContext('2d');
  for (let x = 0; x < 1024; x += 8) {
    ctx.fillStyle = '#FFFFFF'; ctx.fillRect(x, 0, 4, 32);
    ctx.fillStyle = '#555555'; ctx.fillRect(x + 4, 0, 4, 32);
  }
  const t = new THREE.CanvasTexture(c); t.wrapS = THREE.RepeatWrapping; t.repeat.x = 2;
  return t;
}

function makeCoin(radius = 2, depth = .26) {
  const geo = new THREE.CylinderGeometry(radius, radius, depth, 128, 1);
  const metal = { metalness: 1, roughness: .28, envMapIntensity: 1.2 };
  const edge = new THREE.MeshStandardMaterial({ color: COLORS.gold, bumpMap: coinEdgeTexture(), bumpScale: 2, ...metal });
  const front = new THREE.MeshStandardMaterial({ map: coinFaceTexture(false), ...metal, roughness: .32 });
  const back = new THREE.MeshStandardMaterial({ map: coinFaceTexture(true), ...metal, roughness: .32 });
  const coin = new THREE.Mesh(geo, [edge, front, back]);
  coin.rotation.x = Math.PI / 2;            // face the camera
  const holder = new THREE.Group(); holder.add(coin);
  return holder;
}

/* =================================================================
   HERO
   ================================================================= */
function initHero(canvas) {
  const renderer = makeRenderer(canvas);
  const scene = new THREE.Scene();
  scene.environment = envFor(renderer);
  const camera = new THREE.PerspectiveCamera(38, 1, .1, 100);
  camera.position.set(0, 0, 11);

  scene.add(new THREE.AmbientLight(0xffffff, .35));
  const key = new THREE.DirectionalLight(0xFFE2A0, 2.4); key.position.set(-4, 5, 6); scene.add(key);
  const rim = new THREE.PointLight(0x6A5CFF, 40, 20); rim.position.set(4, -2, -3); scene.add(rim);

  const rig = new THREE.Group(); scene.add(rig);

  // coin
  const coin = makeCoin(1.9, .26);
  rig.add(coin);

  // kente orbit rings
  const rings = [
    { c: COLORS.gold, r: 3.0, t: .025, rot: [1.15, .25, 0], speed: .35 },
    { c: COLORS.green, r: 3.45, t: .02, rot: [1.35, -.4, .3], speed: -.25 },
    { c: COLORS.red, r: 3.9, t: .018, rot: [.95, .6, -.2], speed: .18 },
  ].map(d => {
    const m = new THREE.Mesh(new THREE.TorusGeometry(d.r, d.t, 12, 220),
      new THREE.MeshStandardMaterial({ color: d.c, emissive: d.c, emissiveIntensity: .6, metalness: .6, roughness: .3 }));
    m.rotation.set(...d.rot);
    // a bead travelling on each ring
    const bead = new THREE.Mesh(new THREE.SphereGeometry(.09, 16, 16), new THREE.MeshBasicMaterial({ color: d.c }));
    bead.position.x = d.r; m.add(bead);
    rig.add(m);
    return { mesh: m, speed: d.speed };
  });

  // particle disc
  const N = 2400, pos = new Float32Array(N * 3), col = new Float32Array(N * 3);
  const palette = [new THREE.Color(COLORS.gold), new THREE.Color(COLORS.bone), new THREE.Color(COLORS.green), new THREE.Color(0x8F86FF)];
  for (let i = 0; i < N; i++) {
    const a = Math.random() * Math.PI * 2, r = 2.6 + Math.pow(Math.random(), 1.6) * 3.6;
    pos[i * 3] = Math.cos(a) * r; pos[i * 3 + 1] = (Math.random() - .5) * .35 * (r / 3); pos[i * 3 + 2] = Math.sin(a) * r;
    const p = palette[Math.random() < .55 ? 0 : Math.random() < .6 ? 1 : Math.random() < .5 ? 2 : 3];
    col.set([p.r, p.g, p.b], i * 3);
  }
  const discGeo = new THREE.BufferGeometry();
  discGeo.setAttribute('position', new THREE.BufferAttribute(pos, 3));
  discGeo.setAttribute('color', new THREE.BufferAttribute(col, 3));
  const disc = new THREE.Points(discGeo, new THREE.PointsMaterial({ size: .035, vertexColors: true, transparent: true, opacity: .9, depthWrite: false, blending: THREE.AdditiveBlending }));
  disc.rotation.set(1.2, 0, .25);
  rig.add(disc);

  // floating crystals
  const crystals = [];
  const cMats = [COLORS.indigo, COLORS.green, COLORS.red, COLORS.gold].map(c =>
    new THREE.MeshStandardMaterial({ color: c, metalness: .35, roughness: .2, flatShading: true }));
  for (let i = 0; i < 9; i++) {
    const m = new THREE.Mesh(i % 3 ? new THREE.OctahedronGeometry(.22 + Math.random() * .2) : new THREE.IcosahedronGeometry(.2 + Math.random() * .15), cMats[i % 4]);
    const a = (i / 9) * Math.PI * 2;
    m.userData = { a, r: 4.4 + Math.random() * 1.2, y: (Math.random() - .5) * 3.4, s: .15 + Math.random() * .2, spin: Math.random() * 2 };
    rig.add(m); crystals.push(m);
  }

  // distant stars
  const sN = 600, sPos = new Float32Array(sN * 3);
  for (let i = 0; i < sN; i++) sPos.set([(Math.random() - .5) * 60, (Math.random() - .5) * 36, -10 - Math.random() * 20], i * 3);
  const sGeo = new THREE.BufferGeometry(); sGeo.setAttribute('position', new THREE.BufferAttribute(sPos, 3));
  const stars = new THREE.Points(sGeo, new THREE.PointsMaterial({ size: .06, color: 0xD9D2FF, transparent: true, opacity: .6 }));
  scene.add(stars);

  // layout: right side on desktop, top on mobile
  const layout = () => {
    fit(renderer, camera, canvas);
    const mobile = canvas.clientWidth < 760;
    rig.position.set(mobile ? 0 : 3.4, mobile ? 2.2 : 0, 0);
    rig.scale.setScalar(mobile ? .7 : 1);
  };
  layout(); addEventListener('resize', layout);

  // pointer + scroll
  const target = { x: 0, y: 0 }, cur = { x: 0, y: 0 };
  addEventListener('pointermove', e => {
    target.x = (e.clientX / innerWidth - .5) * 2;
    target.y = (e.clientY / innerHeight - .5) * 2;
  }, { passive: true });
  let scrollP = 0;
  addEventListener('scroll', () => { scrollP = Math.min(scrollY / (canvas.clientHeight || 1), 1); }, { passive: true });

  // intro: coin flies in
  let intro = REDUCE ? 1 : 0;

  loop(canvas, (dt, t) => {
    intro = Math.min(intro + dt * .6, 1);
    const ease = 1 - Math.pow(1 - intro, 3);
    cur.x += (target.x - cur.x) * .05; cur.y += (target.y - cur.y) * .05;

    coin.rotation.y = t * .6 + (1 - ease) * Math.PI * 3 + scrollP * Math.PI;
    coin.rotation.x = -cur.y * .35;
    coin.rotation.z = Math.sin(t * .8) * .05;
    coin.position.y = Math.sin(t * 1.2) * .12;
    coin.scale.setScalar(.4 + ease * .6);

    rings.forEach(({ mesh, speed }) => { mesh.rotation.z += dt * speed; });
    disc.rotation.y += dt * .08;
    crystals.forEach(m => {
      const u = m.userData; u.a += dt * u.s;
      m.position.set(Math.cos(u.a) * u.r, u.y + Math.sin(t + u.spin) * .25, Math.sin(u.a) * u.r * .6);
      m.rotation.x += dt * .6; m.rotation.y += dt * .9;
    });

    rig.rotation.y = cur.x * .35;
    rig.rotation.x = cur.y * .2;
    rig.position.z = -scrollP * 4;
    stars.position.x = -cur.x * .6; stars.position.y = cur.y * .4;
    renderer.render(scene, camera);
  });
}

/* =================================================================
   GLOBE
   ================================================================= */
const AFRICA = [[-17.5,14.7],[-16.5,19.5],[-17,21],[-13,27.5],[-9.8,29.5],[-6,35.8],[0,35.9],[10,37.2],[11,33],[20,30.5],[25,31.7],[32.3,31.3],[34,27.8],[35,24],[38.5,18],[43.3,12.6],[51.2,11.8],[49,6],[47,4],[42,-1],[39.5,-6],[40.5,-10.5],[40.5,-15],[35.5,-22],[32.9,-26],[31,-29.8],[27.5,-33.5],[20,-34.8],[18.4,-34],[17.2,-29],[14.5,-22.5],[11.8,-17],[13.5,-11],[12.2,-6],[9.5,-1],[9.6,3.8],[6,4.3],[2.5,6.3],[-2,4.8],[-7.5,4.4],[-11.5,6.9],[-13.3,9],[-15,11],[-16.8,12.5]];
const MADAGASCAR = [[44,-25],[47,-25],[50.4,-15.5],[49.3,-12],[47,-15],[44,-17.5],[43.2,-22]];
const inPoly = (x, y, poly) => {
  let inside = false;
  for (let i = 0, j = poly.length - 1; i < poly.length; j = i++) {
    const [xi, yi] = poly[i], [xj, yj] = poly[j];
    if ((yi > y) !== (yj > y) && x < ((xj - xi) * (y - yi)) / (yj - yi) + xi) inside = !inside;
  }
  return inside;
};
const toVec = (lat, lng, r) => {
  const phi = (90 - lat) * Math.PI / 180, th = (lng + 180) * Math.PI / 180;
  return new THREE.Vector3(-r * Math.sin(phi) * Math.cos(th), r * Math.cos(phi), r * Math.sin(phi) * Math.sin(th));
};

function initGlobe(canvas) {
  const nations = window.BMA_NATIONS || [];
  const renderer = makeRenderer(canvas);
  const scene = new THREE.Scene();
  const camera = new THREE.PerspectiveCamera(35, 1, .1, 100);
  camera.position.set(0, 0, 8.2);
  const R = 2;
  const globe = new THREE.Group(); scene.add(globe);

  // inner sphere
  globe.add(new THREE.Mesh(new THREE.SphereGeometry(R * .985, 64, 64),
    new THREE.MeshBasicMaterial({ color: 0x1A1560, transparent: true, opacity: .92 })));

  // fibonacci dots — Africa lit
  const N = 5200, dots = [], cols = [], sizes = [];
  const gold = new THREE.Color(COLORS.gold), dim = new THREE.Color(0x4C46A8);
  for (let i = 0; i < N; i++) {
    const y = 1 - (i / (N - 1)) * 2, rad = Math.sqrt(1 - y * y), th = i * Math.PI * (3 - Math.sqrt(5));
    const v = new THREE.Vector3(Math.cos(th) * rad, y, Math.sin(th) * rad).multiplyScalar(R);
    const lat = 90 - Math.acos(v.y / R) * 180 / Math.PI;
    let lng = Math.atan2(v.z, -v.x) * 180 / Math.PI - 180; if (lng < -180) lng += 360;
    const africa = inPoly(lng, lat, AFRICA) || inPoly(lng, lat, MADAGASCAR);
    dots.push(v.x, v.y, v.z);
    const c = africa ? gold : dim; cols.push(c.r, c.g, c.b);
    sizes.push(africa ? 1 : .55);
  }
  const dg = new THREE.BufferGeometry();
  dg.setAttribute('position', new THREE.Float32BufferAttribute(dots, 3));
  dg.setAttribute('color', new THREE.Float32BufferAttribute(cols, 3));
  dg.setAttribute('size', new THREE.Float32BufferAttribute(sizes, 1));
  const dotMat = new THREE.ShaderMaterial({
    transparent: true, depthWrite: false,
    uniforms: { uPx: { value: renderer.getPixelRatio() } },
    vertexShader: `attribute float size; varying vec3 vC; varying float vF;
      uniform float uPx;
      void main(){ vC = color; vec4 mv = modelViewMatrix * vec4(position,1.);
        vec3 n = normalize(normalMatrix * normalize(position)); vF = smoothstep(-.1,.5,n.z);
        gl_PointSize = size * 7. * uPx * (6. / -mv.z); gl_Position = projectionMatrix * mv; }`,
    fragmentShader: `varying vec3 vC; varying float vF;
      void main(){ float d = length(gl_PointCoord - .5); if(d > .5) discard;
        gl_FragColor = vec4(vC, (1. - smoothstep(.3,.5,d)) * (.25 + vF * .75)); }`,
    vertexColors: true,
  });
  globe.add(new THREE.Points(dg, dotMat));

  // atmosphere glow
  const atmo = new THREE.Mesh(new THREE.SphereGeometry(R * 1.18, 64, 64), new THREE.ShaderMaterial({
    transparent: true, side: THREE.BackSide, depthWrite: false, blending: THREE.AdditiveBlending,
    vertexShader: `varying vec3 vN; void main(){ vN = normalize(normalMatrix * normal); gl_Position = projectionMatrix * modelViewMatrix * vec4(position,1.); }`,
    fragmentShader: `varying vec3 vN; void main(){ float i = pow(.72 - dot(vN, vec3(0,0,1.)), 3.); gl_FragColor = vec4(.96,.71,.25,1.) * i * 1.4; }`,
  }));
  scene.add(atmo);

  // pins + arcs from hub (first nation = Nigeria)
  const maxM = Math.max(1, ...nations.map(n => n.members));
  const hub = nations[0];
  const travellers = [];
  const pinMat = new THREE.MeshBasicMaterial({ color: COLORS.gold });
  const ringMat = new THREE.MeshBasicMaterial({ color: COLORS.gold, transparent: true, opacity: .7, side: THREE.DoubleSide });
  const pulses = [];
  nations.forEach((n, idx) => {
    const p = toVec(n.lat, n.lng, R);
    const h = .25 + (n.members / maxM) * .7;
    const beam = new THREE.Mesh(new THREE.CylinderGeometry(.018, .018, h, 8), new THREE.MeshBasicMaterial({ color: idx === 0 ? COLORS.red : COLORS.green }));
    beam.position.copy(p.clone().multiplyScalar(1 + h / (2 * R)));
    beam.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), p.clone().normalize());
    globe.add(beam);
    const tip = new THREE.Mesh(new THREE.SphereGeometry(.055, 16, 16), pinMat);
    tip.position.copy(p.clone().multiplyScalar(1 + h / R)); globe.add(tip);
    const ring = new THREE.Mesh(new THREE.RingGeometry(.05, .08, 32), ringMat.clone());
    ring.position.copy(p.clone().multiplyScalar(1.002)); ring.lookAt(p.clone().multiplyScalar(2));
    globe.add(ring); pulses.push({ ring, off: idx * .4 });

    if (idx > 0 && hub) {
      const a = toVec(hub.lat, hub.lng, R), b = p;
      const mid = a.clone().add(b).multiplyScalar(.5);
      mid.normalize().multiplyScalar(R + a.distanceTo(b) * .45);
      const curve = new THREE.QuadraticBezierCurve3(a, mid, b);
      const tube = new THREE.Mesh(new THREE.TubeGeometry(curve, 64, .008, 6, false),
        new THREE.MeshBasicMaterial({ color: COLORS.gold, transparent: true, opacity: .45 }));
      globe.add(tube);
      const dot = new THREE.Mesh(new THREE.SphereGeometry(.035, 12, 12), new THREE.MeshBasicMaterial({ color: 0xFFF1C9 }));
      globe.add(dot); travellers.push({ curve, dot, t: Math.random(), speed: .25 + Math.random() * .2 });
    }
  });

  // face Africa
  const centre = toVec(4, 20, R);
  const baseY = Math.atan2(-centre.x, centre.z);
  globe.rotation.set(.12, baseY, 0);

  // drag to rotate
  let drag = false, lastX = 0, vel = 0, offset = 0;
  canvas.addEventListener('pointerdown', e => { drag = true; lastX = e.clientX; canvas.setPointerCapture(e.pointerId); });
  canvas.addEventListener('pointermove', e => { if (!drag) return; const dx = e.clientX - lastX; lastX = e.clientX; vel = dx * .006; offset += vel; });
  const end = () => { drag = false; };
  canvas.addEventListener('pointerup', end); canvas.addEventListener('pointercancel', end);

  const layout = () => fit(renderer, camera, canvas);
  layout(); addEventListener('resize', layout);

  loop(canvas, (dt, t) => {
    if (!drag) { vel *= .94; offset += vel; offset += (Math.sin(t * .25) * .35 - offset) * .004; }
    globe.rotation.y = baseY + offset;
    travellers.forEach(tr => { tr.t = (tr.t + dt * tr.speed) % 1; tr.dot.position.copy(tr.curve.getPoint(tr.t)); });
    pulses.forEach(({ ring, off }) => {
      const k = ((t * .8 + off) % 1);
      ring.scale.setScalar(1 + k * 3); ring.material.opacity = .8 * (1 - k);
    });
    renderer.render(scene, camera);
  });
}

/* =================================================================
   BANNER (inner pages)
   ================================================================= */
function initBanner(canvas) {
  const renderer = makeRenderer(canvas);
  const scene = new THREE.Scene();
  scene.environment = envFor(renderer);
  const camera = new THREE.PerspectiveCamera(40, 1, .1, 100);
  camera.position.z = 12;
  scene.add(new THREE.AmbientLight(0xffffff, .4));
  const key = new THREE.DirectionalLight(0xFFE2A0, 2); key.position.set(-3, 4, 6); scene.add(key);

  const group = new THREE.Group(); scene.add(group);
  const spots = [[4.5, 1.2, 0, 1], [7.2, -1.4, -2, .7], [2.8, -2.2, -3, .5], [8.8, 2.2, -4, .55], [6, .4, -6, .45]];
  const coins = spots.map(([x, y, z, s], i) => {
    const c = makeCoin(1, .14); c.position.set(x, y, z); c.scale.setScalar(s);
    c.userData = { y, phase: i * 1.3, spin: .4 + i * .12 };
    group.add(c); return c;
  });
  // dust
  const N = 400, p = new Float32Array(N * 3);
  for (let i = 0; i < N; i++) p.set([Math.random() * 16 - 2, (Math.random() - .5) * 8, -Math.random() * 8], i * 3);
  const g = new THREE.BufferGeometry(); g.setAttribute('position', new THREE.BufferAttribute(p, 3));
  const dust = new THREE.Points(g, new THREE.PointsMaterial({ size: .045, color: COLORS.gold, transparent: true, opacity: .55, depthWrite: false }));
  group.add(dust);

  const layout = () => {
    fit(renderer, camera, canvas);
    const mobile = canvas.clientWidth < 760;
    group.position.x = mobile ? 1.5 : 0;
    group.visible = true;
    group.scale.setScalar(mobile ? .6 : 1);
  };
  layout(); addEventListener('resize', layout);

  const target = { x: 0, y: 0 }, cur = { x: 0, y: 0 };
  addEventListener('pointermove', e => { target.x = e.clientX / innerWidth - .5; target.y = e.clientY / innerHeight - .5; }, { passive: true });

  loop(canvas, (dt, t) => {
    cur.x += (target.x - cur.x) * .05; cur.y += (target.y - cur.y) * .05;
    coins.forEach(c => {
      const u = c.userData;
      c.rotation.y = t * u.spin + u.phase;
      c.rotation.x = Math.sin(t * .5 + u.phase) * .3;
      c.position.y = u.y + Math.sin(t * .9 + u.phase) * .25;
    });
    dust.rotation.y = t * .02;
    group.rotation.y = cur.x * .3; group.rotation.x = cur.y * .15;
    renderer.render(scene, camera);
  });
}


/* =================================================================
   SHOP HERO — spinning branded bottle + coin + floating stickers
   ================================================================= */
function loadImage(src) {
  return new Promise(res => { const i = new Image(); i.onload = () => res(i); i.onerror = () => res(null); i.src = src; });
}

async function initShop(canvas) {
  const logo = await loadImage('assets/images/logo.png');
  const renderer = makeRenderer(canvas);
  const scene = new THREE.Scene();
  scene.environment = envFor(renderer);
  const camera = new THREE.PerspectiveCamera(36, 1, .1, 100);
  camera.position.set(0, 0, 11);
  scene.add(new THREE.AmbientLight(0xffffff, .4));
  const key = new THREE.DirectionalLight(0xFFE2A0, 2.2); key.position.set(-4, 5, 6); scene.add(key);
  const rim = new THREE.PointLight(0x7A6CFF, 30, 20); rim.position.set(4, 1, -3); scene.add(rim);

  const rig = new THREE.Group(); scene.add(rig);

  // bottle label texture
  const c = document.createElement('canvas'); c.width = 1024; c.height = 512;
  const x = c.getContext('2d');
  x.fillStyle = '#2A2380'; x.fillRect(0, 0, 1024, 512);
  const stripes = [['#F4B63F', 24], ['#0F0C36', 3], ['#1F8A5B', 13], ['#F4B63F', 3], ['#C8372D', 14], ['#0F0C36', 3]];
  for (let px = 0; px < 1024;) for (const [col, w] of stripes) { x.fillStyle = col; x.fillRect(px, 400, w * 1.6, 48); px += w * 1.6; }
  if (logo) { x.drawImage(logo, 512 - 120, 120, 240, 190); x.drawImage(logo, 0 - 120, 120, 240, 190); x.drawImage(logo, 1024 - 120, 120, 240, 190); }
  const tex = new THREE.CanvasTexture(c); tex.colorSpace = THREE.SRGBColorSpace; tex.anisotropy = 8;

  const prof = [[0, 0], [.52, 0], [.6, .06], [.62, .2], [.62, 1.75], [.58, 1.95], [.42, 2.12], [.3, 2.22], [.3, 2.42]].map(([a, b]) => new THREE.Vector2(a, b));
  const bottle = new THREE.Group();
  const body = new THREE.Mesh(new THREE.LatheGeometry(prof, 96), new THREE.MeshStandardMaterial({ map: tex, metalness: .55, roughness: .3, envMapIntensity: 1 }));
  const cap = new THREE.Mesh(new THREE.CylinderGeometry(.34, .34, .42, 48), new THREE.MeshStandardMaterial({ color: 0x24242C, metalness: .6, roughness: .35 }));
  cap.position.y = 2.62;
  const loopRing = new THREE.Mesh(new THREE.TorusGeometry(.2, .05, 12, 40), cap.material); loopRing.position.y = 2.92;
  bottle.add(body, cap, loopRing);
  bottle.position.y = -1.3;
  bottle.scale.setScalar(1.35);
  rig.add(bottle);

  const coin = makeCoin(.9, .14);
  coin.position.set(-2.1, 1.3, -1);
  rig.add(coin);

  // floating sticker shapes
  const stickerCols = [COLORS.gold, COLORS.green, COLORS.red, 0xF5EEE1];
  const stickers = [];
  for (let i = 0; i < 7; i++) {
    const g = i % 2 ? new THREE.CircleGeometry(.28, 40) : new THREE.PlaneGeometry(.7, .26);
    const m = new THREE.Mesh(g, new THREE.MeshStandardMaterial({ color: stickerCols[i % 4], side: THREE.DoubleSide, roughness: .5 }));
    const a = (i / 7) * Math.PI * 2;
    m.userData = { a, r: 2.4 + (i % 3) * .4, y: (i % 4) * .9 - 1.4, s: .2 + (i % 3) * .08 };
    rig.add(m); stickers.push(m);
  }

  const layout = () => {
    fit(renderer, camera, canvas);
    const mobile = canvas.clientWidth < 760;
    rig.position.set(mobile ? 0 : 3.6, mobile ? 1.9 : 0, 0);
    rig.scale.setScalar(mobile ? .62 : 1);
  };
  layout(); addEventListener('resize', layout);
  const target = { x: 0, y: 0 }, cur = { x: 0, y: 0 };
  addEventListener('pointermove', e => { target.x = e.clientX / innerWidth - .5; target.y = e.clientY / innerHeight - .5; }, { passive: true });

  loop(canvas, (dt, t) => {
    cur.x += (target.x - cur.x) * .05; cur.y += (target.y - cur.y) * .05;
    bottle.rotation.y = t * .5;
    bottle.rotation.z = Math.sin(t * .7) * .06;
    bottle.position.y = -1.3 + Math.sin(t * 1.1) * .12;
    coin.rotation.y = t * .9;
    coin.position.y = 1.3 + Math.sin(t * .9 + 1) * .2;
    stickers.forEach(m => {
      const u = m.userData; u.a += dt * u.s;
      m.position.set(Math.cos(u.a) * u.r, u.y + Math.sin(t + u.a) * .2, Math.sin(u.a) * u.r * .5);
      m.rotation.x = t * .6 + u.a; m.rotation.y = t * .8;
    });
    rig.rotation.y = cur.x * .4; rig.rotation.x = cur.y * .2;
    renderer.render(scene, camera);
  });
}

/* ---------- boot ---------- */
function boot() {
  try {
    const hero = document.getElementById('hero3d');
    if (hero) initHero(hero);
    const globeEl = document.getElementById('globe3d');
    if (globeEl) {
      // build the globe only when it scrolls near the viewport
      const io = new IntersectionObserver(([e]) => { if (e.isIntersecting) { io.disconnect(); initGlobe(globeEl); } }, { rootMargin: '200px' });
      io.observe(globeEl);
    }
    document.querySelectorAll('.banner-3d').forEach(initBanner);
    const shop = document.getElementById('shop3d');
    if (shop) initShop(shop).catch(err => console.warn('3D disabled:', err));
  } catch (err) {
    console.warn('3D disabled:', err);
    document.documentElement.classList.add('no-webgl');
  }
}
// wait for the display font so it is drawn onto the coins
(document.fonts ? document.fonts.ready : Promise.resolve()).then(boot);
