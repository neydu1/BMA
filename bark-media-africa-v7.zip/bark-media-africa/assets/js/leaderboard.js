/* Two Paws leaderboard: X sign-in status, run submission, team + duo tables.
   Also fills any [data-mini-board] (homepage teaser) and [data-doa-portrait] art. */
(() => {
  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => [...r.querySelectorAll(s)];
  const API = 'api/leaderboard.php';
  const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const store = { get(k, d) { try { const v = localStorage.getItem(k); return v ? JSON.parse(v) : d; } catch { return d; } }, set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch {} } };
  const fmt = s => `${Math.floor(s / 60)}:${String(Math.floor(s % 60)).padStart(2, '0')}`;
  const FLAGS = { Nigeria: '🇳🇬', 'South Africa': '🇿🇦', Ghana: '🇬🇭', Uganda: '🇺🇬', Tanzania: '🇹🇿', Ethiopia: '🇪🇹', Kenya: '🇰🇪', Egypt: '🇪🇬', Rwanda: '🇷🇼', Cameroon: '🇨🇲', Morocco: '🇲🇦', Diaspora: '🌍' };

  // portraits anywhere on the page
  if (window.DOA) $$('[data-doa-portrait]').forEach(el => { const c = DOA.portrait(el.dataset.doaPortrait, 320); c.setAttribute('role', 'img'); c.setAttribute('aria-label', DOA.byId[el.dataset.doaPortrait]?.name || ''); el.append(c); });

  /* ---------- local fallback (when PHP isn't running, e.g. a static preview) ---------- */
  let offline = false;
  const local = () => store.get('tp-local-board', []);
  function localBoard() {
    const runs = local().sort((a, b) => b.score - a.score);
    const by = {};
    runs.forEach(r => (by[r.team] = by[r.team] || []).push(r));
    const teams = Object.entries(by).map(([team, list]) => {
      const top = list.slice(0, 3), ppl = new Set();
      list.forEach(r => ['p1', 'p2'].forEach(p => r[p].handle && ppl.add(r[p].handle.toLowerCase())));
      return { team, flag: FLAGS[team] || '🌍', power: Math.round(top.reduce((s, r) => s + r.score, 0) / top.length), best: list[0].score, runs: list.length, players: ppl.size, duo: [list[0].p1, list[0].p2], chars: list[0].chars };
    }).sort((a, b) => b.power - a.power);
    return { ok: true, runs: runs.slice(0, 25), teams, total: runs.length, offline: true };
  }
  async function getBoard() {
    try {
      const r = await fetch(API, { headers: { Accept: 'application/json' }, cache: 'no-store' });
      if (!r.ok) throw 0;
      const d = await r.json(); if (!d.ok) throw 0;
      offline = false; return d;
    } catch { offline = true; return localBoard(); }
  }

  const person = p => {
    if (!p || !p.handle) return '';
    const av = p.avatar ? `<img src="${esc(p.avatar)}" alt="" width="32" height="32" loading="lazy" referrerpolicy="no-referrer" onerror="this.replaceWith(Object.assign(document.createElement('span'),{className:'lb-av',textContent:'${esc(p.handle[0].toUpperCase())}'}))">` : `<span class="lb-av">${esc(p.handle[0].toUpperCase())}</span>`;
    return `<a class="lb-person" href="https://x.com/${esc(p.handle)}" target="_blank" rel="noopener" data-no-transition>${av}<span>@${esc(p.handle)}${p.verified ? ' <i class="tp-tick" title="Signed in with X">✓</i>' : ''}</span></a>`;
  };
  const charsArt = ch => (ch || []).map(id => window.DOA ? `<span class="lb-char" data-char="${esc(id)}"></span>` : '').join('');
  const paintChars = root => { if (!window.DOA) return; $$('.lb-char', root).forEach(el => { if (!el.firstChild) el.append(DOA.portrait(el.dataset.char, 64)); }); };

  /* ---------- full board (game page) ---------- */
  const body = $('#lb-body');
  let tab = 'teams', data = null, highlight = null;
  function render() {
    if (!body || !data) return;
    const note = data.offline ? '<p class="lb-offline">Showing scores saved on this device (the server leaderboard is not reachable).</p>' : '';
    if (tab === 'teams') {
      body.innerHTML = note + (data.teams.length ? `<ol class="lb-list">${data.teams.map((t, i) => `
        <li class="lb-row ${i < 3 ? 'top' + (i + 1) : ''}">
          <span class="lb-rank">${i + 1}</span>
          <span class="lb-team"><span class="lb-flag">${t.flag}</span><b>${esc(t.team)}</b><small>${t.runs} run${t.runs === 1 ? '' : 's'} · ${t.players} player${t.players === 1 ? '' : 's'}</small></span>
          <span class="lb-duo">${person(t.duo[0])}${person(t.duo[1])}</span>
          <span class="lb-score"><b>${t.power.toLocaleString()}</b><small>power · best ${t.best.toLocaleString()}</small></span>
        </li>`).join('')}</ol>` : `<p class="muted">No scores yet. Be the first duo to put your nation on the board.</p>`);
    } else {
      body.innerHTML = note + (data.runs.length ? `<ol class="lb-list">${data.runs.map((r, i) => `
        <li class="lb-row ${i < 3 ? 'top' + (i + 1) : ''} ${highlight && highlight.at === r.at && highlight.score === r.score ? 'is-you' : ''}">
          <span class="lb-rank">${i + 1}</span>
          <span class="lb-duo">${charsArt(r.chars)}${person(r.p1)}${person(r.p2)}</span>
          <span class="lb-team sm"><span class="lb-flag">${FLAGS[r.team] || '🌍'}</span><small>${esc(r.team)} · ${r.levels}/4 · ${fmt(r.time)}${r.mode === 'solo' ? ' · solo' : ''}</small></span>
          <span class="lb-score"><b>${r.score.toLocaleString()}</b><small>${r.coins} coins · ${r.deaths} falls</small></span>
        </li>`).join('')}</ol>` : `<p class="muted">No runs posted yet.</p>`);
      paintChars(body);
    }
  }
  $$('[data-lb-tab]').forEach(b => b.addEventListener('click', () => {
    tab = b.dataset.lbTab;
    $$('[data-lb-tab]').forEach(x => x.setAttribute('aria-selected', String(x === b)));
    render();
  }));
  if (body) getBoard().then(d => { data = d; render(); });

  /* ---------- mini board (homepage) ---------- */
  $$('[data-mini-board]').forEach(async el => {
    const d = await getBoard();
    el.innerHTML = d.teams.length
      ? d.teams.slice(0, 3).map((t, i) => `<li><span>${i + 1}. ${t.flag} ${esc(t.team)}</span><b>${t.power.toLocaleString()}</b></li>`).join('')
      : '<li><span>No scores yet. Your nation could be first.</span><b>–</b></li>';
  });

  /* ---------- X identity + submission (game page) ---------- */
  const form = $('#tp-submit-form');
  if (!form) return;
  let lastRun = null, xState = { configured: false, players: {} };
  const saved = store.get('tp-identity', {});
  if (saved.team) form.team.value = saved.team;
  ['p1', 'p2'].forEach(s => { if (saved[s]) form[s].value = saved[s]; });

  function paintX() {
    ['p1', 'p2'].forEach(slot => {
      const box = $(`[data-xslot="${slot}"]`, form);
      const btn = $('.tp-xbtn', box), who = $('.tp-x-who', box), input = form[slot];
      const me = xState.players[slot];
      btn.hidden = !xState.configured || !!me;
      if (me) {
        input.value = me.username; input.readOnly = true;
        who.hidden = false;
        who.innerHTML = `${me.avatar ? `<img src="${esc(me.avatar)}" alt="" width="22" height="22" referrerpolicy="no-referrer">` : ''} Signed in as <b>${esc(me.name)}</b> <i class="tp-tick">✓</i> · <a href="api/x-auth.php?logout=${slot}" data-no-transition>switch</a>`;
      } else { input.readOnly = false; who.hidden = true; }
    });
  }
  fetch('api/x-auth.php?status', { cache: 'no-store' }).then(r => r.json()).then(d => { xState = d; paintX(); }).catch(() => paintX());

  window.addEventListener('tp:run', e => {
    lastRun = e.detail;
    $('[data-xslot="p2"]', form).hidden = lastRun.mode === 'solo';
    $('.form-msg', form).textContent = '';
    const btn = $('button[type="submit"]', form); btn.disabled = false; btn.textContent = 'Post to leaderboard';
  });
  // after coming back from X sign-in, land on the board
  if (/[?&]x=/.test(location.search) && location.hash !== '#tp-board') location.hash = 'tp-board';

  form.addEventListener('submit', async e => {
    e.preventDefault();
    const msg = $('.form-msg', form), btn = $('button[type="submit"]', form);
    const say = (t, ok) => { msg.textContent = t; msg.className = 'form-msg full ' + (ok ? 'ok' : 'err'); };
    if (!lastRun) return say('Finish a run first.', false);
    const clean = v => v.trim().replace(/^@/, '').replace(/^https?:\/\/(www\.)?(x|twitter)\.com\//i, '').split(/[/?#]/)[0];
    const p1 = clean(form.p1.value), p2 = clean(form.p2.value);
    if (!form.team.value) { form.team.focus(); return say('Pick the nation team you play for.', false); }
    if (!/^[A-Za-z0-9_]{1,15}$/.test(p1)) { form.p1.focus(); return say("Add Player 1's X handle (letters, numbers and _).", false); }
    if (lastRun.mode === 'coop' && !/^[A-Za-z0-9_]{1,15}$/.test(p2)) { form.p2.focus(); return say("Add Player 2's X handle.", false); }
    store.set('tp-identity', { team: form.team.value, p1, p2 });

    const fd = new FormData(form);
    fd.set('p1', p1); fd.set('p2', p2);
    Object.entries({ levels: lastRun.levels, coins: lastRun.coins, deaths: lastRun.deaths, time: lastRun.time.toFixed(2), mode: lastRun.mode, c1: lastRun.picks[0], c2: lastRun.picks[1] }).forEach(([k, v]) => fd.set(k, v));
    btn.disabled = true; btn.textContent = 'Posting…';
    try {
      const r = await fetch(API, { method: 'POST', body: fd, credentials: 'same-origin' });
      const d = await r.json();
      say(d.message, d.ok);
      if (d.ok) {
        data = { ...d, offline: false }; highlight = d.runs[d.rank - 1] || null; tab = 'runs';
        $$('[data-lb-tab]').forEach(x => x.setAttribute('aria-selected', String(x.dataset.lbTab === 'runs')));
        render(); btn.textContent = 'Posted ✓'; return;
      }
    } catch {
      // no server: keep it on this device so the board still works in a static preview
      const avatar = h => h ? 'https://unavatar.io/x/' + encodeURIComponent(h) : '';
      const run = { score: lastRun.score, team: form.team.value, mode: lastRun.mode, p1: { handle: p1, avatar: avatar(p1), verified: false }, p2: lastRun.mode === 'coop' ? { handle: p2, avatar: avatar(p2), verified: false } : { handle: '' }, chars: lastRun.picks, levels: lastRun.levels, coins: lastRun.coins, deaths: lastRun.deaths, time: lastRun.time, at: new Date().toISOString() };
      const all = local(); all.push(run); store.set('tp-local-board', all.slice(-200));
      data = localBoard(); highlight = run; tab = 'runs'; render();
      say('Saved on this device. It will post to the live board when the site runs on your server.', true);
      btn.textContent = 'Saved ✓'; return;
    }
    btn.disabled = false; btn.textContent = 'Post to leaderboard';
  });
})();
