/* =================================================================
   TWO PAWS — It takes the pack
   A two-player co-op platformer for Bark Media Africa.
   P1 carries the Talking Drum (bark: breaks cracked stone, beats drums).
   P2 wears the Sky Cape (hold jump in the air to glide, ride the wind).
   Same-device co-op (keyboard, touch, two gamepads) or solo with swap.
   ================================================================= */
(() => {
  const root = document.getElementById('tp');
  if (!root || !window.DOA || !window.BMA_LEVELS) return;

  const $ = (s, r = root) => r.querySelector(s);
  const $$ = (s, r = root) => [...r.querySelectorAll(s)];
  const LEVELS = window.BMA_LEVELS;
  const T = 32, VW = 960, VH = 544, ROWS = 17;
  const GRAV = 1900, JUMP = 640, SPEED = 235, MAXFALL = 900, GLIDE = 75;
  const DW = 22, DH = 30;
  const COLORS = { p1: '#F4B63F', p2: '#2DB9DA', door: { Q: '#D2643F', W: '#E2557E', E: '#8A5CFF', V: '#F4B63F' }, bridge: { R: '#13A881', Y: '#2DB9DA' }, plate: { q: '#D2643F', w: '#E2557E', e: '#8A5CFF', r: '#13A881', y: '#2DB9DA', v: '#F4B63F' } };
  /* skills: what each dog can do, unlocked by clearing chapters */
  const SKILLS = {
    stack: { name: 'Pack Lift', who: 'Both dogs', icon: '⇡', from: 0, text: 'Stand on your partner to reach ledges four blocks high.' },
    glide: { name: 'Sky Cape', who: 'Cape dog (P2)', icon: '🪂', from: 0, text: 'Hold jump in the air to glide over wide gaps and ride rising wind.' },
    bark: { name: 'Talking Drum', who: 'Drum dog (P1)', icon: '🥁', from: 1, text: 'Bark to crack stone walls and beat drums that raise sky bridges.' },
    boost: { name: 'Sky Boost', who: 'Cape dog (P2)', icon: '✦', from: 2, text: 'Tap jump again in mid-air for a second leap. Tap = boost, hold = glide.' },
    grip: { name: 'Paw Grip', who: 'Drum dog (P1)', icon: '🐾', from: 3, text: 'Slide down walls and jump off them to climb narrow shafts.' },
  };
  const has = k => !!L && SKILLS[k].from <= L.i;
  const NOIN = { left: false, right: false, jump: false, power: false };
  /* online co-op state (see "online co-op" further down) */
  const net = { role: null, slot: 0, pc: null, ch: null, room: null, peer: {}, remote: { ...NOIN }, fx: [], lastIn: '', inT: 0, lastSnap: 0, target: null, timers: [], send() {} };
  const REDUCE = matchMedia('(prefers-reduced-motion: reduce)').matches;
  const store = { get(k, d) { try { const v = localStorage.getItem(k); return v ? JSON.parse(v) : d; } catch { return d; } }, set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch {} } };

  /* ---------------- settings (saved per device) ---------------- */
  const DEFAULTS = { calm: true, music: .55, sfx: .7, shake: false, cinema: true, hints: true, touchSize: 'm', touchAlpha: .8, lefty: false, quality: 'hd', haptics: true };
  const S = Object.assign({}, DEFAULTS, store.get('tp-settings', {}));
  const saveSettings = () => { store.set('tp-settings', S); applySettings(); };

  /* ---------------- canvas ---------------- */
  const canvas = $('#tp-canvas');
  const ctx = canvas.getContext('2d');
  let scale = 1;
  function fitCanvas() {
    const r = canvas.getBoundingClientRect();
    if (!r.width) return;
    const dpr = Math.min(devicePixelRatio || 1, S.quality === 'hd' ? 2 : 1);
    canvas.width = Math.round(r.width * dpr); canvas.height = Math.round(r.width * dpr * VH / VW);
    scale = canvas.width / VW;
  }
  new ResizeObserver(fitCanvas).observe(canvas); fitCanvas();

  /* ---------------- audio: calm ambient score + soft effects ---------------- */
  let AC = null, musicBus = null, sfxBus = null, delay = null, padNodes = [], mbiraTimer = 0, musicOn = false;
  const audio = () => {
    if (!AC) {
      try {
        AC = new (window.AudioContext || window.webkitAudioContext)();
        musicBus = AC.createGain(); sfxBus = AC.createGain();
        delay = AC.createDelay(1.5); delay.delayTime.value = .42;
        const fb = AC.createGain(); fb.gain.value = .38; const wet = AC.createGain(); wet.gain.value = .35;
        delay.connect(fb).connect(delay); delay.connect(wet).connect(musicBus);
        musicBus.connect(AC.destination); sfxBus.connect(AC.destination);
        applyVolumes();
      } catch {}
    }
    if (AC && AC.state === 'suspended') AC.resume();
    return AC;
  };
  function applyVolumes() { if (!AC) return; const t = AC.currentTime; musicBus.gain.setTargetAtTime(S.music * .9, t, .2); sfxBus.gain.setTargetAtTime(S.sfx, t, .05); }
  function tone(f, d = .12, type = 'triangle', v = .06, slide = 0) {
    if (!S.sfx || !audio()) return;
    const o = AC.createOscillator(), g = AC.createGain(), t = AC.currentTime;
    o.type = S.calm && type === 'square' ? 'triangle' : type;
    o.frequency.setValueAtTime(f, t); if (slide) o.frequency.exponentialRampToValueAtTime(Math.max(30, f + slide), t + d);
    g.gain.setValueAtTime(0, t); g.gain.linearRampToValueAtTime(v, t + .008); g.gain.exponentialRampToValueAtTime(.0001, t + d);
    o.connect(g).connect(sfxBus); o.start(t); o.stop(t + d + .02);
  }
  function drum(f = 120, v = .25, bus) {
    if (!audio()) return;
    const t = AC.currentTime, o = AC.createOscillator(), g = AC.createGain();
    o.type = 'sine'; o.frequency.setValueAtTime(f * 1.8, t); o.frequency.exponentialRampToValueAtTime(f, t + .12);
    g.gain.setValueAtTime(v, t); g.gain.exponentialRampToValueAtTime(.0001, t + .4);
    o.connect(g).connect(bus || sfxBus); o.start(t); o.stop(t + .45);
  }
  // mbira (thumb piano) pluck: a sine with a bright partial, sent into the echo
  function mbira(f, v = .07) {
    if (!audio()) return;
    const t = AC.currentTime;
    [[1, v], [3.01, v * .18], [5.9, v * .06]].forEach(([m, a]) => {
      const o = AC.createOscillator(), g = AC.createGain();
      o.type = 'sine'; o.frequency.value = f * m;
      g.gain.setValueAtTime(0, t); g.gain.linearRampToValueAtTime(a, t + .005); g.gain.exponentialRampToValueAtTime(.0001, t + (m === 1 ? 1.8 : .4));
      o.connect(g); g.connect(musicBus); g.connect(delay); o.start(t); o.stop(t + 2);
    });
  }
  const SFX = {
    jump: () => tone(380, .12, 'triangle', .04, 180), coin: () => { tone(1046, .12, 'sine', .05); setTimeout(() => tone(1568, .2, 'sine', .04), 70); },
    bark: () => { drum(90, .3); tone(220, .14, 'triangle', .035, -100); }, drumHit: () => { drum(70, .38); setTimeout(() => drum(110, .28), 160); },
    door: () => tone(180, .3, 'sine', .06, 60), crumble: () => { for (let i = 0; i < 4; i++) setTimeout(() => tone(90 + Math.random() * 60, .1, 'triangle', .04, -40), i * 50); },
    die: () => tone(330, .45, 'sine', .06, -200), land: () => tone(120, .06, 'sine', .035), check: () => { tone(660, .2, 'sine', .05); setTimeout(() => tone(990, .3, 'sine', .045), 110); },
    win: () => [523, 659, 784, 1047].forEach((f, i) => setTimeout(() => mbira(f, .09), i * 160)),
    latch: () => [392, 523, 659].forEach((f, i) => setTimeout(() => drum(f / 3, .28), i * 140)),
  };
  // per-chapter pentatonic keys (calm, unhurried)
  const KEYS = [[196, 220, 262, 294, 330, 392, 440], [174.6, 196, 233, 262, 294, 349, 392], [220, 247, 294, 330, 370, 440, 494], [164.8, 185, 220, 247, 277, 330, 370]];
  function music(on) {
    musicOn = on; clearTimeout(mbiraTimer);
    padNodes.forEach(n => { try { n.g.gain.setTargetAtTime(0, AC.currentTime, .8); n.o.forEach(o => o.stop(AC.currentTime + 3)); } catch {} });
    padNodes = [];
    if (!on || !S.music || !audio()) return;
    const key = KEYS[(L ? L.i : 0) % KEYS.length];
    // soft pad: root + fifth, slowly breathing through a low-pass
    const lp = AC.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.value = 700; lp.Q.value = .4; lp.connect(musicBus);
    const lfo = AC.createOscillator(), lfoG = AC.createGain(); lfo.frequency.value = .07; lfoG.gain.value = 260; lfo.connect(lfoG).connect(lp.frequency); lfo.start();
    [key[0] / 2, key[0] * .75, key[2] / 2].forEach((f, i) => {
      const g = AC.createGain(); g.gain.value = 0; g.gain.setTargetAtTime(.05 - i * .01, AC.currentTime, 2.5); g.connect(lp);
      const o = [AC.createOscillator(), AC.createOscillator()];
      o.forEach((x, k) => { x.type = k ? 'triangle' : 'sine'; x.frequency.value = f * (k ? 1.003 : 1); x.connect(g); x.start(); });
      padNodes.push({ g, o: [...o, lfo] });
    });
    const play = () => {
      if (!musicOn) return;
      if (state === 'play' || state === 'intro') {
        const n = key[Math.floor(Math.random() * key.length)] * (Math.random() < .3 ? 2 : 1);
        mbira(n, S.calm ? .05 : .07);
        if (Math.random() < .25) setTimeout(() => mbira(key[Math.floor(Math.random() * 4)] * 2, .035), 190);
      }
      mbiraTimer = setTimeout(play, (S.calm ? 900 : 600) + Math.random() * 900);
    };
    play();
  }
  const kick = v => { if (S.shake && !REDUCE) shake = Math.max(shake, v); };
  const buzz = ms => { if (S.haptics && navigator.vibrate) navigator.vibrate(ms); };

  /* ---------------- input ---------------- */
  const keys = new Set();
  const pads = [{}, {}];
  const KEYMAP = {
    0: { left: ['KeyA'], right: ['KeyD'], jump: ['KeyW', 'Space'], power: ['KeyS', 'KeyF'] },
    1: { left: ['ArrowLeft'], right: ['ArrowRight'], jump: ['ArrowUp'], power: ['ArrowDown', 'Slash', 'Period'] },
  };
  addEventListener('keydown', e => {
    if (state !== 'play') { if (e.code === 'Escape' && state === 'pause') resume(); return; }
    if (e.target.closest('input, select, textarea')) return;
    if (['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'Space', 'Tab'].includes(e.code)) e.preventDefault();
    if (e.code === 'Escape' || e.code === 'KeyP') { pause(); return; }
    if (mode === 'solo' && (e.code === 'Tab' || e.code === 'KeyQ' || e.code === 'KeyE')) { swap(); return; }
    keys.add(e.code);
  });
  addEventListener('keyup', e => keys.delete(e.code));
  addEventListener('blur', () => keys.clear());

  // touch: each pointer is tracked to whichever button is under it (thumbs can slide between buttons)
  const touchState = { 0: {}, 1: {}, solo: {} };
  const ptr = new Map();
  function touchFrom(el) { const b = el && el.closest && el.closest('[data-btn]'); return b ? [b.dataset.who, b.dataset.btn] : null; }
  function touchApply() {
    for (const k of Object.keys(touchState)) touchState[k] = {};
    $$('[data-btn]').forEach(b => b.classList.remove('on'));
    ptr.forEach(v => { if (v) { touchState[v[0]][v[1]] = true; const b = $(`[data-who="${v[0]}"][data-btn="${v[1]}"]`); b && b.classList.add('on'); } });
  }
  const pad = $('#tp-touch');
  pad.addEventListener('pointerdown', e => {
    const t = touchFrom(e.target); if (!t) return;
    e.preventDefault(); audio();
    if (t[1] === 'swap') { swap(); return; }
    pad.setPointerCapture?.(e.pointerId); ptr.set(e.pointerId, t); touchApply();
    if (t[1] !== 'left' && t[1] !== 'right') buzz(8);
  });
  pad.addEventListener('pointermove', e => {
    if (!ptr.has(e.pointerId)) return;
    const t = touchFrom(document.elementFromPoint(e.clientX, e.clientY));
    if (t && t[1] !== 'swap') { ptr.set(e.pointerId, t); touchApply(); }
  });
  ['pointerup', 'pointercancel', 'lostpointercapture'].forEach(ev => pad.addEventListener(ev, e => { ptr.delete(e.pointerId); touchApply(); }));
  pad.addEventListener('contextmenu', e => e.preventDefault());

  function readPads() {
    const gp = navigator.getGamepads ? [...navigator.getGamepads()].filter(Boolean) : [];
    [0, 1].forEach(i => {
      const g = gp[i]; pads[i] = {};
      if (!g) return;
      const ax = g.axes[0] || 0, b = n => g.buttons[n] && g.buttons[n].pressed;
      pads[i] = { left: ax < -.35 || b(14), right: ax > .35 || b(15), jump: b(0), power: b(2) || b(1) || b(7), swap: b(3) || b(4) || b(5) };
    });
  }
  function controls(slot) {
    const any = (list) => list.some(c => keys.has(c));
    const local1 = mode === 'solo' || mode === 'online';
    const k = local1
      ? { left: any(KEYMAP[0].left) || any(KEYMAP[1].left), right: any(KEYMAP[0].right) || any(KEYMAP[1].right), jump: any(KEYMAP[0].jump) || any(KEYMAP[1].jump), power: any(KEYMAP[0].power) || any(KEYMAP[1].power) }
      : { left: any(KEYMAP[slot].left), right: any(KEYMAP[slot].right), jump: any(KEYMAP[slot].jump), power: any(KEYMAP[slot].power) };
    const t = local1 ? touchState.solo : touchState[slot];
    const p = local1 ? pads[0] : pads[slot];
    return { left: k.left || t.left || p.left, right: k.right || t.right || p.right, jump: k.jump || t.jump || p.jump, power: k.power || t.power || p.power };
  }

  /* ---------------- level runtime ---------------- */
  let L = null;          // current level runtime
  let dogs = [];
  let cam = { x: 0 }, shake = 0;
  let particles = [], waves = [], floaters = [];
  let mode = 'coop', active = 0, picks = store.get('tp-picks', ['rose', 'jollof']);
  let state = 'title', chapter = 0, practice = false;
  let run = { time: 0, coins: 0, deaths: 0, levels: 0 };
  let lvStats = { time: 0, coins: 0, deaths: 0 };

  function loadLevel(i) {
    const src = LEVELS[i];
    const grid = src.rows.map(r => r.split(''));
    const W = grid[0].length;
    const spawns = {};
    const plates = {}, coins = [], checks = [], portal = [];
    grid.forEach((row, y) => row.forEach((ch, x) => {
      if (ch === '1' || ch === '2') { spawns[ch] = { x, y }; row[x] = ' '; }
      if ('qwervy'.includes(ch)) (plates[ch] = plates[ch] || []).push({ x, y });
      if (ch === 'c') coins.push({ x, y, got: false, t: Math.random() * 6 });
      if (ch === 'k') checks.push({ x, y, on: false, flag: 0 });
      if (ch === 'O') portal.push({ x, y });
    }));
    L = {
      i, src, grid, W, spawns, plates, coins, checks, portal,
      broken: [], pressed: {}, open: { Q: 0, W: 0, E: 0, V: 0 }, bridge: { R: 0, Y: 0, U: 0 }, latched: false, drum: 0, drumSeen: false,
      respawn: { x: spawns['1'].x, y: spawns['1'].y }, hintIdx: -1, hintT: 0, winT: 0, t: 0,
    };
    dogs = [0, 1].map(slot => {
      const sp = spawns[slot ? '2' : '1'];
      return { slot, id: picks[slot], x: sp.x * T + (T - DW) / 2, y: (sp.y + 1) * T - DH, vx: 0, vy: 0, ground: false, face: 1, coyote: 0, buf: 0, jumpHeld: false, powerHeld: false, cool: 0, sq: 0, at: 0, state: 'idle', dead: 0, ride: null, glide: false, lastY: 0, prevX: 0 };
    });
    cam.x = clampCam(midX() - VW / 2);
    particles = []; waves = []; floaters = [];
    lvStats = { time: 0, coins: 0, deaths: 0 };
    buildStatic();
    buildBackdrop();
  }

  const tile = (x, y) => (y < 0 ? '#' : y >= ROWS ? ' ' : x < 0 || x >= L.W ? '#' : L.grid[y][x]);
  const midX = () => mode === 'solo' ? dogs[active].x + DW / 2 : (dogs[0].x + dogs[1].x + DW) / 2;
  const clampCam = x => Math.max(0, Math.min(L.W * T - VW, x));

  function solid(ch, dog) {
    switch (ch) {
      case '#': case 'x': return true;
      case 'Q': case 'W': case 'E': case 'V': return L.open[ch] < .5;
      case 'R': case 'Y': return L.bridge[ch] > .5;
      case 'U': return L.drum > 0;
      case 'G': return dog.slot === 1;
      case 'T': return dog.slot === 0;
      default: return false;
    }
  }
  function overlapTiles(x, y, w, h, fn) {
    const x0 = Math.floor(x / T), x1 = Math.floor((x + w - .001) / T), y0 = Math.floor(y / T), y1 = Math.floor((y + h - .001) / T);
    for (let ty = y0; ty <= y1; ty++) for (let tx = x0; tx <= x1; tx++) if (fn(tx, ty, tile(tx, ty))) return true;
    return false;
  }

  /* ---------------- physics ---------------- */
  function stepDog(d, dt, inp) {
    if (d.dead > 0) { d.dead -= dt; if (d.dead <= 0) respawn(d); return; }
    const other = dogs[1 - d.slot];
    // tiles we are already inside (a door closing on us) never trap us
    const inside = new Set();
    overlapTiles(d.x, d.y, DW, DH, (tx, ty, ch) => { if (solid(ch, d)) inside.add(tx + ',' + ty); });
    const blocks = (tx, ty, ch) => solid(ch, d) && !inside.has(tx + ',' + ty);

    // carry along when standing on the partner
    if (d.ride && d.ground) d.x += d.ride.x - d.ride.prevX;

    const dir = (inp.right ? 1 : 0) - (inp.left ? 1 : 0);
    if (dir) d.face = dir;
    const accel = d.ground ? 18 : 9;
    if (!(d.lock > 0)) d.vx += (dir * SPEED - d.vx) * Math.min(1, accel * dt);
    d.lock = Math.max(0, (d.lock || 0) - dt);
    if (Math.abs(d.vx) < 4 && !dir) d.vx = 0;

    // jump with coyote time + buffer + variable height
    d.coyote = d.ground ? .1 : Math.max(0, d.coyote - dt);
    if (inp.jump && !d.jumpHeld) d.buf = .13; else d.buf = Math.max(0, d.buf - dt);
    let jumpedNow = false;
    const fresh = inp.jump && !d.jumpHeld;
    if (d.ground) d.boosts = 1;
    if (d.buf > 0 && d.coyote > 0) {
      d.vy = -JUMP; d.ground = false; d.coyote = 0; d.buf = 0; d.sq = -.28; d.ride = null; SFX.jump(); dust(d, 5); jumpedNow = true;
    }
    // Paw Grip (Drum dog): slide down walls, kick off them
    d.wall = 0;
    if (d.slot === 0 && has('grip') && !d.ground && !jumpedNow) {
      const onL = overlapTiles(d.x - 2, d.y + 4, 2, DH - 10, blocks), onR = overlapTiles(d.x + DW, d.y + 4, 2, DH - 10, blocks);
      d.wall = onL ? -1 : onR ? 1 : 0;
      if (d.wall && d.vy > 0 && ((d.wall < 0 && inp.left) || (d.wall > 0 && inp.right))) {
        d.vy = Math.min(d.vy, 130);
        if (Math.random() < .25) particles.push({ x: d.wall < 0 ? d.x : d.x + DW, y: d.y + DH - 4, vx: -d.wall * 20, vy: -20, life: .3, max: .3, c: '#F1D3AA', s: 2 });
      }
      if (d.wall && fresh) {
        d.vy = -JUMP * .95; d.vx = -d.wall * SPEED * 1.15; d.lock = .17; d.face = -d.wall; d.buf = 0; d.sq = -.25; jumpedNow = true;
        SFX.jump(); for (let i = 0; i < 6; i++) particles.push({ x: d.wall < 0 ? d.x : d.x + DW, y: d.y + DH / 2, vx: -d.wall * (60 + Math.random() * 80), vy: (Math.random() - .5) * 80, life: .35, max: .35, c: '#F4B63F', s: 3 });
      }
    }
    // Sky Boost (Cape dog): one extra leap in the air
    if (d.slot === 1 && has('boost') && !d.ground && !jumpedNow && fresh && d.boosts > 0 && d.coyote <= 0) {
      d.vy = -JUMP * .85; d.boosts = 0; d.buf = 0; d.sq = -.3; buzz(10);
      tone(700, .14, 'sine', .045, 300);
      for (let i = 0; i < 12; i++) { const a = i / 12 * Math.PI * 2; particles.push({ x: d.x + DW / 2, y: d.y + DH, vx: Math.cos(a) * 110, vy: Math.sin(a) * 50 + 40, life: .4, max: .4, c: i % 2 ? '#2DB9DA' : '#BFF3FF', s: 3 }); }
    }
    if (!inp.jump && d.vy < -220) d.vy += GRAV * 1.1 * dt;
    d.jumpHeld = inp.jump;

    d.vy = Math.min(MAXFALL, d.vy + GRAV * dt);

    // P2 glide + rising wind
    d.glide = false;
    const wcx = d.x + DW / 2, wcy = d.y + DH / 2;
    const inWind = tile(Math.floor(wcx / T), Math.floor(wcy / T)) === 'u' || tile(Math.floor(wcx / T), Math.floor((wcy + 20) / T)) === 'u';
    if (d.slot === 1 && has('glide') && !d.ground && (inp.jump || inp.power) && (d.vy > -60 || inWind)) {
      d.glide = true;
      if (inWind) {
        d.vy = Math.max(-330, d.vy - 3200 * dt);
        if (Math.random() < .5) particles.push({ x: d.x + Math.random() * DW, y: d.y + DH, vx: 0, vy: 60, life: .5, max: .5, c: '#BFF3FF', s: 2 });
      } else d.vy = Math.min(d.vy, GLIDE);
      if (Math.random() < .3) particles.push({ x: d.x + (d.face > 0 ? 0 : DW), y: d.y + 10, vx: -d.face * 30, vy: 10, life: .4, max: .4, c: ['#F4B63F', '#13A881', '#D2643F', '#2DB9DA'][Math.floor(Math.random() * 4)], s: 2 });
    }

    // P1 bark
    d.cool = Math.max(0, d.cool - dt);
    if (d.slot === 0 && inp.power && !d.powerHeld && d.cool <= 0) { if (has('bark')) bark(d); else if (!d.toldBark) { d.toldBark = true; showHint('The Talking Drum unlocks when you clear Chapter 1.', 'drum'); } }
    d.powerHeld = inp.power;

    // move X
    d.prevX = d.x;
    let nx = d.x + d.vx * dt;
    if (d.vx > 0 && overlapTiles(nx, d.y, DW, DH, blocks)) { nx = Math.floor((nx + DW) / T) * T - DW - .01; d.vx = 0; }
    else if (d.vx < 0 && overlapTiles(nx, d.y, DW, DH, blocks)) { nx = (Math.floor(nx / T) + 1) * T + .01; d.vx = 0; }
    // co-op leash: the camera can only stretch so far
    if (mode !== 'solo' && other.dead <= 0) {
      const maxGap = VW - 90;
      if (nx - other.x > maxGap && nx > d.x) nx = Math.max(d.x, other.x + maxGap);
      if (other.x - nx > maxGap && nx < d.x) nx = Math.min(d.x, other.x - maxGap);
    }
    d.x = Math.max(0, Math.min(L.W * T - DW, nx));

    // move Y
    const bottom0 = d.y + DH;
    let ny = d.y + d.vy * dt;
    const wasGround = d.ground;
    d.ground = false; d.ride = null;
    if (d.vy > 0) {
      const nb = ny + DH;
      let land = null;
      // solid + one-way planks
      const x0 = Math.floor(d.x / T), x1 = Math.floor((d.x + DW - .001) / T);
      for (let ty = Math.floor(bottom0 / T); ty <= Math.floor((nb - .001) / T) && land === null; ty++) {
        for (let tx = x0; tx <= x1; tx++) {
          const ch = tile(tx, ty);
          if ((blocks(tx, ty, ch) && ty * T >= bottom0 - 1) || (ch === '=' && bottom0 <= ty * T + 1) || (ch === 'U' && L.drum > 0 && bottom0 <= ty * T + 1) || ((ch === 'R' || ch === 'Y') && L.bridge[ch] > .5 && bottom0 <= ty * T + 1)) { land = ty * T; break; }
        }
      }
      // the partner's head is a platform
      if (other.dead <= 0 && bottom0 <= other.y + 1 && nb >= other.y && d.x + DW > other.x + 3 && d.x < other.x + DW - 3) {
        if (land === null || other.y < land) { land = other.y; d.ride = other; }
      }
      if (land !== null) {
        ny = land - DH; if (!wasGround && d.vy > 300) { d.sq = Math.min(.35, d.vy / 2200); SFX.land(); dust(d, 6); }
        d.vy = 0; d.ground = true;
      }
    } else if (d.vy < 0) {
      if (overlapTiles(d.x, ny, DW, DH, blocks)) { ny = (Math.floor(ny / T) + 1) * T + .01; d.vy = 0; }
    }
    // standing still on something?
    if (!d.ground && d.vy === 0) {
      if (overlapTiles(d.x, ny + 1, DW, DH, blocks)) d.ground = true;
    }
    d.y = ny;

    // hazards
    if (d.y > ROWS * T + 60) return die(d);
    if (overlapTiles(d.x + 3, d.y + 8, DW - 6, DH - 8, (tx, ty, ch) => ch === '^' && d.y + DH > ty * T + 14)) return die(d);

    // pickups
    L.coins.forEach(c => {
      if (c.got) return;
      if (d.x < c.x * T + 26 && d.x + DW > c.x * T + 6 && d.y < c.y * T + 26 && d.y + DH > c.y * T + 6) {
        c.got = true; lvStats.coins++; SFX.coin();
        for (let i = 0; i < 10; i++) particles.push({ x: c.x * T + 16, y: c.y * T + 16, vx: (Math.random() - .5) * 220, vy: (Math.random() - .8) * 220, life: .5, max: .5, c: '#FFE2A3', s: 3, g: 500 });
        floaters.push({ x: c.x * T + 16, y: c.y * T, t: 0, text: '+100' });
      }
    });
    L.checks.forEach(k => {
      if (k.on) return;
      if (d.x < k.x * T + T && d.x + DW > k.x * T && d.y + DH > k.y * T) {
        k.on = true; L.respawn = { x: k.x, y: k.y }; SFX.check();
        floaters.push({ x: k.x * T + 16, y: k.y * T - 10, t: 0, text: 'Checkpoint' });
      }
    });

    // animation state
    d.sq += (0 - d.sq) * Math.min(1, dt * 12);
    d.at += dt * (d.ground && Math.abs(d.vx) > 20 ? Math.abs(d.vx) / 140 : 1.2);
    d.state = !d.ground ? (d.glide ? 'glide' : d.vy < 0 ? 'jump' : 'fall') : Math.abs(d.vx) > 25 ? 'run' : 'idle';
    if (d.ground && Math.abs(d.vx) > 120 && Math.random() < dt * 10) dust(d, 1);
  }

  function bark(d) {
    d.cool = .45; SFX.bark(); kick(.18); buzz(12);
    const cx = d.x + DW / 2 + d.face * 10, cy = d.y + DH / 2;
    waves.push({ x: cx, y: cy, r: 8, life: .45 });
    const R = 70, hits = [];
    for (let ty = Math.floor((cy - R) / T); ty <= Math.floor((cy + R) / T); ty++)
      for (let tx = Math.floor((cx - R) / T); tx <= Math.floor((cx + R) / T); tx++) {
        const ch = tile(tx, ty);
        const dx = Math.max(tx * T - cx, 0, cx - (tx + 1) * T), dy = Math.max(ty * T - cy, 0, cy - (ty + 1) * T);
        if (dx * dx + dy * dy > R * R) continue;
        if (ch === 'x') hits.push([tx, ty]);
        if (ch === 'd') { L.drum = 6; L.drumSeen = true; SFX.drumHit(); waves.push({ x: tx * T + 16, y: ty * T + 16, r: 10, life: .7, gold: true }); }
      }
    if (hits.length) {
      // crumble the whole connected cracked wall
      const q = [...hits], seen = new Set();
      while (q.length) {
        const [x, y] = q.pop(); const k = x + ',' + y;
        if (seen.has(k) || tile(x, y) !== 'x') continue;
        seen.add(k); L.grid[y][x] = ' '; L.broken.push([x, y]);
        for (let i = 0; i < 8; i++) particles.push({ x: x * T + Math.random() * T, y: y * T + Math.random() * T, vx: (Math.random() - .5) * 300, vy: -Math.random() * 300, life: .9, max: .9, c: Math.random() < .5 ? '#8E5A3A' : '#C98A5A', s: 4, g: 900 });
        q.push([x + 1, y], [x - 1, y], [x, y + 1], [x, y - 1]);
      }
      SFX.crumble(); kick(.3); buzz(25); staticDirty = true;
    }
  }

  function dust(d, n) { for (let i = 0; i < n; i++) particles.push({ x: d.x + DW / 2 + (Math.random() - .5) * DW, y: d.y + DH, vx: (Math.random() - .5) * 90, vy: -Math.random() * 60, life: .35, max: .35, c: '#F1D3AA', s: 3 }); }
  function die(d) {
    if (d.dead > 0) return;
    d.dead = .75; lvStats.deaths++; SFX.die(); kick(.25); buzz(40);
    for (let i = 0; i < 18; i++) particles.push({ x: d.x + DW / 2, y: d.y + DH / 2, vx: (Math.random() - .5) * 360, vy: (Math.random() - .7) * 360, life: .7, max: .7, c: i % 2 ? (d.slot ? COLORS.p2 : COLORS.p1) : '#fff', s: 3, g: 600 });
  }
  function respawn(d) {
    const r = L.respawn;
    d.x = r.x * T + (d.slot ? 22 : -12); d.y = (r.y + 1) * T - DH - 4; d.vx = d.vy = 0; d.dead = 0; d.sq = .3;
    d.x = Math.max(0, d.x);
    for (let i = 0; i < 12; i++) particles.push({ x: d.x + DW / 2, y: d.y + DH / 2, vx: Math.cos(i) * 120, vy: Math.sin(i) * 120, life: .4, max: .4, c: d.slot ? COLORS.p2 : COLORS.p1, s: 3 });
  }

  function updateWorld(dt) {
    L.t += dt;
    // plates
    const pressed = {};
    Object.entries(L.plates).forEach(([ch, list]) => {
      pressed[ch] = list.map(p => dogs.some(d => d.dead <= 0 && d.ground && Math.abs(d.y + DH - (p.y + 1) * T) < 3 && d.x + DW > p.x * T + 4 && d.x < p.x * T + T - 4));
    });
    const any = ch => (pressed[ch] || []).some(Boolean);
    ['q', 'w', 'e'].forEach(ch => { if (any(ch) && !(L.pressed[ch] || []).some(Boolean)) SFX.door(); });
    if (pressed.v && pressed.v.length && pressed.v.every(Boolean) && !L.latched) { L.latched = true; SFX.latch(); kick(.35); buzz(30); floaters.push({ x: cam.x + VW / 2, y: 120, t: 0, text: 'Gate unlocked!', big: true }); }
    L.pressed = pressed;
    const ease = (v, on) => Math.max(0, Math.min(1, v + (on ? dt * 5 : -dt * 4)));
    L.open.Q = ease(L.open.Q, any('q')); L.open.W = ease(L.open.W, any('w')); L.open.E = ease(L.open.E, any('e')); L.open.V = ease(L.open.V, L.latched);
    L.bridge.R = ease(L.bridge.R, any('r')); L.bridge.Y = ease(L.bridge.Y, any('y'));
    if (L.drum > 0) { L.drum -= dt; if (L.drum <= 0) L.drum = 0; }

    // portal: both dogs inside
    const inPortal = d => d.dead <= 0 && L.portal.some(p => d.x + DW > p.x * T && d.x < p.x * T + T && d.y + DH > p.y * T && d.y < p.y * T + T);
    if (!L.ending) { if (dogs.every(inPortal)) { L.winT += dt; if (L.winT > .12) { L.ending = S.cinema ? 1.1 : .01; SFX.win(); } } else L.winT = 0; }

    // hints follow the pack
    const mx = midX() / T;
    const hs = L.src.hints;
    let idx = -1; hs.forEach(([x], i) => { if (mx >= x) idx = i; });
    if (idx !== L.hintIdx) { L.hintIdx = idx; if (idx >= 0) showHint(hs[idx][2], hs[idx][1]); }

    // camera
    let focus = midX();
    if (mode !== 'solo' && Math.abs(dogs[0].x - dogs[1].x) > VW - 60) {
      const alive = dogs.filter(d => d.dead <= 0);
      if (alive.length) focus = Math.min(...alive.map(d => d.x)) + VW * .35;   // keep the dog that's catching up in view
    }
    const lead = mode === 'solo' ? dogs[active].vx * .25 : (dogs[0].vx + dogs[1].vx) * .12;
    cam.lead = (cam.lead || 0) + (lead - (cam.lead || 0)) * Math.min(1, dt * 1.5);
    const target = clampCam(focus + cam.lead - VW / 2);
    cam.x += (target - cam.x) * Math.min(1, dt * (S.calm ? 3.2 : 6));
    shake = Math.max(0, shake - dt);
    particles = particles.filter(p => { p.life -= dt; p.x += p.vx * dt; p.y += p.vy * dt; if (p.g) p.vy += p.g * dt; return p.life > 0; });
    waves = waves.filter(w => (w.life -= dt) > 0 && (w.r += dt * 260));
    floaters = floaters.filter(f => (f.t += dt) < 1.2);
    L.coins.forEach(c => (c.t += dt));
    L.checks.forEach(k => (k.flag += ((k.on ? 1 : 0) - k.flag) * Math.min(1, dt * 4)));
  }

  /* ---------------- rendering ---------------- */
  let staticCanvas = null, staticDirty = true, back = null;
  const ground = ['#C2552F', '#9A3F22', '#6E2E18'];
  function buildStatic() {
    const c = document.createElement('canvas'); c.width = L.W * T; c.height = ROWS * T;
    const x = c.getContext('2d');
    x.imageSmoothingEnabled = false;
    for (let ty = 0; ty < ROWS; ty++) for (let tx = 0; tx < L.W; tx++) {
      const ch = L.grid[ty][tx], px = tx * T, py = ty * T;
      if (ch === '#') {
        const top = tile(tx, ty - 1) !== '#';
        const depth = Math.min(2, (() => { let n = 0; while (n < 3 && tile(tx, ty - n - 1) === '#') n++; return n; })());
        x.fillStyle = ground[depth]; x.fillRect(px, py, T, T);
        // bogolan marks
        x.fillStyle = 'rgba(241,211,170,.18)';
        if ((tx + ty) % 3 === 0) { x.fillRect(px + 6, py + 14, 4, 4); x.fillRect(px + 22, py + 14, 4, 4); }
        if ((tx * 7 + ty) % 4 === 1) { for (let k = 0; k < 4; k++) x.fillRect(px + 4 + k * 6, py + 22 + (k % 2) * 3, 4, 3); }
        if ((tx + ty * 3) % 5 === 2) { x.fillRect(px + 13, py + 6, 6, 2); x.fillRect(px + 15, py + 4, 2, 6); }
        x.fillStyle = 'rgba(0,0,0,.18)'; x.fillRect(px, py + T - 2, T, 2); x.fillRect(px + T - 2, py, 2, T);
        if (top) {
          x.fillStyle = '#F1D3AA'; x.fillRect(px, py, T, 6);
          x.fillStyle = '#E59A2F'; x.fillRect(px, py + 6, T, 3);
          x.fillStyle = '#13A881'; for (let k = 0; k < 4; k++) x.fillRect(px + 2 + k * 8 + (tx % 2) * 2, py - 4 + (k % 2) * 2, 2, 4 - (k % 2) * 2);
          x.fillStyle = '#fff8'; x.fillRect(px, py, T, 1);
        }
      } else if (ch === '=') {
        x.fillStyle = '#6E3F22'; x.fillRect(px, py, T, 10);
        x.fillStyle = '#A0643A'; x.fillRect(px, py, T, 3);
        const kc = ['#F4B63F', '#13A881', '#D2643F', '#0D0A2E'];
        for (let k = 0; k < 4; k++) { x.fillStyle = kc[(k + tx) % 4]; x.fillRect(px + k * 8, py + 5, 8, 3); }
        x.fillStyle = '#3A2010'; x.fillRect(px, py + 10, T, 2);
      } else if (ch === '^') {
        for (let k = 0; k < 4; k++) {
          x.fillStyle = '#F1E6D0'; x.beginPath(); x.moveTo(px + k * 8, py + T); x.lineTo(px + k * 8 + 4, py + 12); x.lineTo(px + k * 8 + 8, py + T); x.fill();
          x.fillStyle = '#B9A88A'; x.fillRect(px + k * 8 + 4, py + 18, 2, 12);
        }
      }
    }
    staticCanvas = c; staticDirty = false;
  }

  function buildBackdrop() {
    const [top, bottom] = L.src.sky;
    const w = VW * 2, layers = [];
    // far: sky + planet + stars
    const far = document.createElement('canvas'); far.width = VW; far.height = VH;
    let x = far.getContext('2d');
    const g = x.createLinearGradient(0, 0, 0, VH); g.addColorStop(0, '#07061C'); g.addColorStop(.55, top); g.addColorStop(1, bottom);
    x.fillStyle = g; x.fillRect(0, 0, VW, VH);
    for (let i = 0; i < 160; i++) { x.globalAlpha = Math.random() * .8 + .2; x.fillStyle = Math.random() < .15 ? '#F4B63F' : '#fff'; const s = Math.random() < .1 ? 2 : 1; x.fillRect(Math.random() * VW, Math.random() * VH * .7, s, s); }
    x.globalAlpha = 1;
    // kente-ringed planet
    const px = VW * (.72 - L.i * .12), py = VH * .26, R = 70 + L.i * 8;
    x.save(); x.translate(px, py); x.rotate(-.3);
    const ring = front => { ['#F4B63F', '#13A881', '#D2643F', '#2DB9DA'].forEach((c, k) => { x.strokeStyle = c; x.lineWidth = 6; x.beginPath(); x.ellipse(0, 0, R * 1.5 + k * 7, R * .32 + k * 1.6, 0, front ? 0 : Math.PI, front ? Math.PI : Math.PI * 2); x.stroke(); }); };
    ring(false);
    const pg = x.createRadialGradient(-R * .4, -R * .4, R * .1, 0, 0, R); pg.addColorStop(0, '#FFE2A3'); pg.addColorStop(.5, ['#D2643F', '#13A881', '#E2557E', '#E59A2F'][L.i % 4]); pg.addColorStop(1, '#1A0E2E');
    x.fillStyle = pg; x.beginPath(); x.arc(0, 0, R, 0, 7); x.fill();
    x.globalAlpha = .25; x.fillStyle = '#0D0A2E'; for (let k = -2; k <= 2; k++) x.fillRect(-R, k * R * .3, R * 2, R * .08); x.globalAlpha = 1;
    ring(true); x.restore();
    layers.push({ c: far, f: 0 });
    // mid: mesas + baobabs (silhouettes)
    const mid = document.createElement('canvas'); mid.width = w; mid.height = VH;
    x = mid.getContext('2d'); x.fillStyle = 'rgba(13,10,46,.55)';
    for (let i = 0; i < 9; i++) { const bx = i * w / 9 + Math.random() * 60, bw = 140 + Math.random() * 120, bh = 90 + Math.random() * 110; x.fillRect(bx, VH - 140 - bh, bw, bh + 140); x.fillRect(bx - 16, VH - 140 - bh + 10, bw + 32, 12); }
    layers.push({ c: mid, f: .15 });
    const near = document.createElement('canvas'); near.width = w; near.height = VH;
    x = near.getContext('2d'); x.fillStyle = 'rgba(7,6,28,.75)';
    for (let i = 0; i < 7; i++) {
      const bx = i * w / 7 + 40 + Math.random() * 80, by = VH - 110;
      x.fillRect(bx - 9, by - 70, 18, 90);                                      // baobab trunk
      x.fillRect(bx - 20, by - 10, 40, 30);
      [[-46, -96, 34, 10], [-30, -112, 26, 8], [12, -104, 40, 10], [20, -88, 30, 8], [-10, -120, 22, 10]].forEach(([dx, dy, ww, hh]) => x.fillRect(bx + dx, by + dy, ww, hh));
      x.fillRect(bx - 4, by - 118, 8, 50); x.fillRect(bx - 30, by - 100, 60, 6);
    }
    for (let i = 0; i < w; i += 6) x.fillRect(i, VH - 40 - Math.random() * 10, 3, 60);
    layers.push({ c: near, f: .35 });
    back = layers;
    // vignette
    const v = document.createElement('canvas'); v.width = VW; v.height = VH; x = v.getContext('2d');
    const vg = x.createRadialGradient(VW / 2, VH / 2, VH * .4, VW / 2, VH / 2, VW * .7); vg.addColorStop(0, 'rgba(0,0,0,0)'); vg.addColorStop(1, 'rgba(5,4,20,.55)');
    x.fillStyle = vg; x.fillRect(0, 0, VW, VH); back.vignette = v;
    back.motes = Array.from({ length: 34 }, () => ({ x: Math.random() * VW, y: Math.random() * VH, vx: -(.05 + Math.random() * .15), vy: -(.02 + Math.random() * .08), s: Math.random() < .3 ? 3 : 2, p: Math.random() * 6, c: Math.random() < .5 ? '#FFE2A3' : '#BFF3FF' }));
    const gr = document.createElement('canvas'); gr.width = VW + 64; gr.height = VH + 64; x = gr.getContext('2d');
    const id = x.createImageData(gr.width, gr.height);
    for (let i = 0; i < id.data.length; i += 4) { const n = Math.random() * 255; id.data[i] = id.data[i + 1] = id.data[i + 2] = n; id.data[i + 3] = 255; }
    x.putImageData(id, 0, 0); back.grain = gr;
  }

  function draw() {
    ctx.setTransform(scale, 0, 0, scale, 0, 0);
    ctx.imageSmoothingEnabled = false;
    if (!L) { ctx.fillStyle = '#07061C'; ctx.fillRect(0, 0, VW, VH); return; }
    if (staticDirty) buildStatic();
    const sx = shake > 0 && !REDUCE ? (Math.random() - .5) * 10 * shake * 4 : 0, sy = shake > 0 && !REDUCE ? (Math.random() - .5) * 10 * shake * 4 : 0;
    // backdrop
    back.forEach(l => {
      if (!l.f) { ctx.drawImage(l.c, 0, 0); return; }
      const off = -(cam.x * l.f) % l.c.width;
      ctx.drawImage(l.c, off, 0); ctx.drawImage(l.c, off + l.c.width, 0);
    });
    ctx.save();
    ctx.translate(-Math.round(cam.x) + sx, sy);
    const x0 = Math.floor(cam.x / T) - 1, x1 = x0 + VW / T + 3;
    ctx.drawImage(staticCanvas, Math.floor(cam.x), 0, VW + 2, VH, Math.floor(cam.x), 0, VW + 2, VH);
    const t = L.t;
    for (let ty = 0; ty < ROWS; ty++) for (let tx = Math.max(0, x0); tx < Math.min(L.W, x1); tx++) {
      const ch = L.grid[ty][tx], px = tx * T, py = ty * T;
      switch (ch) {
        case 'x': {
          ctx.fillStyle = '#7A5A48'; ctx.fillRect(px, py, T, T); ctx.fillStyle = '#5A3E30'; ctx.fillRect(px, py + T - 4, T, 4); ctx.fillRect(px + T - 4, py, 4, T);
          ctx.fillStyle = '#2A1810'; [[6, 4], [8, 8], [12, 10], [14, 14], [12, 18], [18, 20], [22, 24]].forEach(([a, b]) => ctx.fillRect(px + a, py + b, 3, 3));
          ctx.fillStyle = '#A07E68'; ctx.fillRect(px + 2, py + 2, T - 8, 2);
          break;
        }
        case 'Q': case 'W': case 'E': case 'V': {
          const o = L.open[ch]; if (o >= .98) break;
          const top = tile(tx, ty - 1) !== ch, h = T * (1 - o);
          ctx.globalAlpha = 1 - o * .6;
          ctx.fillStyle = '#4A2A16'; ctx.fillRect(px + 2, py, T - 4, h);
          ctx.fillStyle = COLORS.door[ch]; ctx.fillRect(px + 2, py + Math.max(0, h - 6), T - 4, Math.min(6, h));
          ctx.fillStyle = '#6E3F22'; ctx.fillRect(px + 6, py, 4, h); ctx.fillRect(px + T - 10, py, 4, h);
          if (top && ch === 'V') { ctx.fillStyle = COLORS.door.V; ctx.fillRect(px, py, T, 4); }
          if ((ty % 3) === 1) { ctx.fillStyle = COLORS.door[ch]; ctx.fillRect(px + 12, py + 10, 8, 8); ctx.fillStyle = '#0D0A2E'; ctx.fillRect(px + 15, py + 13, 2, 2); }
          ctx.globalAlpha = 1; break;
        }
        case 'R': case 'Y': case 'U': {
          const on = ch === 'U' ? (L.drum > 0 ? 1 : 0) : L.bridge[ch];
          const warn = ch === 'U' && L.drum > 0 && L.drum < 1.5 && Math.floor(L.drum * 8) % 2;
          ctx.globalAlpha = on ? (warn ? .4 : 1) : .22;
          ctx.fillStyle = ch === 'U' ? '#F4B63F' : COLORS.bridge[ch]; ctx.fillRect(px, py, T, 8);
          ctx.fillStyle = '#0D0A2E'; for (let k = 0; k < 4; k++) ctx.fillRect(px + k * 8 + 3, py + 3, 3, 3);
          if (!on) { ctx.strokeStyle = ctx.fillStyle = ch === 'U' ? '#F4B63F' : COLORS.bridge[ch]; ctx.setLineDash([4, 4]); ctx.strokeRect(px + .5, py + .5, T - 1, 8); ctx.setLineDash([]); }
          ctx.globalAlpha = 1; break;
        }
        case 'G': case 'T': {
          const col = ch === 'G' ? '244,182,63' : '45,185,218';
          ctx.fillStyle = `rgba(${col},.18)`; ctx.fillRect(px + 4, py, T - 8, T);
          for (let k = 0; k < 3; k++) { const a = .35 + .3 * Math.sin(t * 4 + k + ty); ctx.fillStyle = `rgba(${col},${a})`; ctx.fillRect(px + 8 + k * 7, py, 2, T); }
          if (tile(tx, ty - 1) !== ch) { ctx.fillStyle = `rgb(${col})`; ctx.fillRect(px + 2, py - 2, T - 4, 4); }
          if (tile(tx, ty + 1) !== ch) { ctx.fillStyle = `rgb(${col})`; ctx.fillRect(px + 2, py + T - 2, T - 4, 4); }
          break;
        }
        case 'u': {
          ctx.fillStyle = 'rgba(191,243,255,.07)'; ctx.fillRect(px, py, T, T);
          for (let k = 0; k < 2; k++) { const yy = (py + T - ((t * 90 + k * 16 + tx * 7) % T)); ctx.fillStyle = 'rgba(191,243,255,.45)'; ctx.fillRect(px + 6 + k * 14, yy, 2, 6); }
          break;
        }
        case 'q': case 'w': case 'e': case 'r': case 'y': case 'v': {
          const idx = L.plates[ch].findIndex(p => p.x === tx && p.y === ty);
          const on = (L.pressed[ch] || [])[idx] || (ch === 'v' && L.latched);
          ctx.fillStyle = '#2A1810'; ctx.fillRect(px + 2, py + T - 6, T - 4, 6);
          ctx.fillStyle = COLORS.plate[ch]; ctx.fillRect(px + 4, py + T - (on ? 6 : 10), T - 8, on ? 3 : 5);
          if (on) { ctx.globalAlpha = .35; ctx.fillRect(px - 2, py + T - 18, T + 4, 12); ctx.globalAlpha = 1; }
          break;
        }
        case 'd': {
          const on = L.drum > 0, b = on ? Math.sin(t * 20) * 1.5 : 0;
          ctx.fillStyle = '#6E3F22'; ctx.fillRect(px + 6, py + 6 + b, 20, 26);
          ctx.fillStyle = '#C8642E'; ctx.fillRect(px + 8, py + 10 + b, 16, 18);
          ctx.fillStyle = '#F1D3AA'; ctx.fillRect(px + 5, py + 4 + b, 22, 4); ctx.fillRect(px + 5, py + 28, 22, 3);
          ctx.fillStyle = '#F4B63F'; for (let k = 0; k < 4; k++) ctx.fillRect(px + 9 + k * 4, py + 12 + b + (k % 2) * 8, 2, 8);
          if (on) { ctx.strokeStyle = '#F4B63F'; ctx.lineWidth = 3; ctx.beginPath(); ctx.arc(px + 16, py - 8, 8, -Math.PI / 2, -Math.PI / 2 + Math.PI * 2 * (L.drum / 6)); ctx.stroke(); }
          else if (!L.drumSeen) { ctx.fillStyle = '#F4B63F'; ctx.globalAlpha = .5 + .5 * Math.sin(t * 5); ctx.fillRect(px + 14, py - 14, 4, 8); ctx.fillRect(px + 14, py - 4, 4, 3); ctx.globalAlpha = 1; }
          break;
        }
        case 'k': {
          const k = L.checks.find(c => c.x === tx && c.y === ty);
          ctx.fillStyle = '#3A2010'; ctx.fillRect(px + 14, py - 18, 4, 50);
          const fy = py + 20 - (k ? k.flag : 0) * 34;
          ['#F4B63F', '#13A881', '#D2643F'].forEach((c, i) => { ctx.fillStyle = c; ctx.fillRect(px + 18, fy + i * 4, 14 + Math.sin(t * 6 + i) * 2, 4); });
          break;
        }
        case 'O': {
          if (tile(tx - 1, ty) === 'O' || tile(tx, ty - 1) === 'O') break;
          const cx = px + T, cy = py + T;
          ctx.save(); ctx.translate(cx, cy);
          const glow = ctx.createRadialGradient(0, 0, 4, 0, 0, 46); glow.addColorStop(0, 'rgba(255,226,163,.9)'); glow.addColorStop(.5, 'rgba(244,182,63,.35)'); glow.addColorStop(1, 'rgba(244,182,63,0)');
          ctx.fillStyle = glow; ctx.beginPath(); ctx.arc(0, 0, 46, 0, 7); ctx.fill();
          ['#F4B63F', '#13A881', '#D2643F', '#2DB9DA', '#E2557E', '#F1D3AA'].forEach((c, i) => { ctx.strokeStyle = c; ctx.lineWidth = 5; ctx.beginPath(); const a = t * 1.6 + i * Math.PI / 3; ctx.arc(0, 0, 26, a, a + .8); ctx.stroke(); });
          ctx.restore(); break;
        }
      }
    }
    if (S.hints && state !== 'intro') drawMarkers(x0, x1);
    // coins
    L.coins.forEach(c => {
      if (c.got) return;
      const cx = c.x * T + 16, cy = c.y * T + 16 + Math.sin(c.t * 3) * 3, w = Math.abs(Math.cos(c.t * 3)) * 11 + 2;
      ctx.fillStyle = '#B67A10'; ctx.fillRect(cx - w, cy - 11, w * 2, 22);
      ctx.fillStyle = '#F4B63F'; ctx.fillRect(cx - w + 2, cy - 9, w * 2 - 4, 18);
      if (w > 7) { ctx.fillStyle = '#7A4E08'; ctx.font = 'bold 14px system-ui'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText('Ð', cx, cy + 1); }
    });
    // dogs
    dogs.forEach(d => drawDog(d));
    // fx
    waves.forEach(w => { ctx.strokeStyle = w.gold ? '#FFE2A3' : '#F4B63F'; ctx.globalAlpha = Math.max(0, w.life * 2); ctx.lineWidth = 4; ctx.beginPath(); ctx.arc(w.x, w.y, w.r, 0, 7); ctx.stroke(); });
    particles.forEach(p => { ctx.globalAlpha = Math.max(0, p.life / p.max); ctx.fillStyle = p.c; ctx.fillRect(p.x - p.s / 2, p.y - p.s / 2, p.s, p.s); });
    ctx.globalAlpha = 1;
    floaters.forEach(f => { ctx.globalAlpha = 1 - f.t / 1.2; ctx.fillStyle = '#FFE2A3'; ctx.font = `800 ${f.big ? 30 : 16}px "Bricolage Grotesque", system-ui`; ctx.textAlign = 'center'; ctx.fillText(f.text, f.x, f.y - f.t * 30); });
    ctx.globalAlpha = 1;
    ctx.restore();

    // off-screen partner arrows
    dogs.forEach(d => {
      const sxp = d.x - cam.x;
      if (d.dead > 0 || state === 'intro' || (sxp > -DW && sxp < VW)) return;
      const left = sxp < 0, ay = Math.max(30, Math.min(VH - 30, d.y));
      ctx.fillStyle = d.slot ? COLORS.p2 : COLORS.p1;
      ctx.beginPath(); if (left) { ctx.moveTo(8, ay); ctx.lineTo(24, ay - 12); ctx.lineTo(24, ay + 12); } else { ctx.moveTo(VW - 8, ay); ctx.lineTo(VW - 24, ay - 12); ctx.lineTo(VW - 24, ay + 12); } ctx.fill();
    });
    // drifting motes (calm, screen-space)
    if (S.quality === 'hd' && back.motes) {
      back.motes.forEach(m => {
        m.x += m.vx; m.y += m.vy + Math.sin(L.t * .6 + m.p) * .08;
        if (m.x < -10) m.x = VW + 10; if (m.x > VW + 10) m.x = -10; if (m.y < -10) m.y = VH + 10; if (m.y > VH + 10) m.y = -10;
        ctx.globalAlpha = .25 + .35 * Math.abs(Math.sin(L.t * .8 + m.p)); ctx.fillStyle = m.c; ctx.fillRect(m.x, m.y, m.s, m.s);
      });
      ctx.globalAlpha = 1;
    }
    if (back.vignette) ctx.drawImage(back.vignette, 0, 0);
    if (S.cinema && S.quality === 'hd' && back.grain) { ctx.globalAlpha = .05; ctx.drawImage(back.grain, -Math.random() * 64, -Math.random() * 64); ctx.globalAlpha = 1; }
    if (bars > .01) { const h = 46 * bars; ctx.fillStyle = '#000'; ctx.fillRect(0, 0, VW, h); ctx.fillRect(0, VH - h, VW, h); }
  }

  function drawDog(d) {
    if (d.dead > 0) return;
    const spr = DOA.frame(d.id, { state: d.state, t: d.at % 1, drum: d.slot === 0, cape: d.slot === 1, rim: d.slot ? COLORS.p2 : COLORS.p1 });
    const S = 1;                                        // 40px sprite on a 32px tile grid
    const cx = d.x + DW / 2, by = d.y + DH;
    // soft shadow
    ctx.globalAlpha = .3; ctx.fillStyle = '#000'; ctx.beginPath(); ctx.ellipse(cx, by + 1, 14, 4, 0, 0, 7); ctx.fill(); ctx.globalAlpha = 1;
    ctx.save();
    ctx.translate(cx, by + 1);
    const sq = d.sq, sxs = 1 + sq * .9, sys = 1 - sq;     // squash (+) / stretch (−)
    const lean = d.state === 'run' ? d.vx / SPEED * .06 : d.state === 'glide' ? .08 * d.face : 0;
    ctx.rotate(lean);
    ctx.scale(d.face * sxs * S, sys * S);
    ctx.drawImage(spr, -21, -40);
    ctx.restore();
    // player tag
    const active = mode === 'solo' && d.slot === window.__tpActive;
    ctx.fillStyle = d.slot ? COLORS.p2 : COLORS.p1;
    ctx.font = '800 11px system-ui'; ctx.textAlign = 'center';
    ctx.fillText(mode === 'solo' ? (active ? '▼' : '') : d.slot ? 'P2' : 'P1', cx, d.y - 16);
  }

  // little floating icons over puzzle pieces near the dogs (non-blocking, no text)
  function drawMarkers(x0, x1) {
    const near = (tx) => dogs.some(d => d.dead <= 0 && Math.abs((d.x + DW / 2) / T - tx) < 5.5);
    const bob = Math.sin(L.t * 3) * 2.5;
    const bubble = (tx, ty, icon, col) => {
      const bx = tx * T + T / 2, by = ty * T - 14 + bob;
      ctx.globalAlpha = .92; ctx.fillStyle = 'rgba(10,8,38,.85)'; ctx.strokeStyle = col; ctx.lineWidth = 2;
      ctx.beginPath(); ctx.roundRect ? ctx.roundRect(bx - 14, by - 13, 28, 24, 8) : ctx.rect(bx - 14, by - 13, 28, 24); ctx.fill(); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(bx - 5, by + 11); ctx.lineTo(bx, by + 17); ctx.lineTo(bx + 5, by + 11); ctx.fillStyle = col; ctx.fill();
      ctx.font = '14px system-ui, "Apple Color Emoji", "Segoe UI Emoji"'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillStyle = '#fff';
      ctx.fillText(icon, bx, by - 1); ctx.globalAlpha = 1;
    };
    for (let ty = 0; ty < ROWS; ty++) for (let tx = Math.max(0, x0); tx < Math.min(L.W, x1); tx++) {
      const ch = L.grid[ty][tx];
      if (!near(tx)) continue;
      if ('qwery'.includes(ch)) {
        const i = L.plates[ch].findIndex(p => p.x === tx && p.y === ty);
        if (!(L.pressed[ch] || [])[i]) bubble(tx, ty + .55, '⤓', COLORS.plate[ch]);
      } else if (ch === 'v' && !L.latched) bubble(tx, ty + .55, '⚿', COLORS.plate.v);
      else if (ch === 'x' && tile(tx, ty - 1) !== 'x' && has('bark')) bubble(tx, ty, '🥁', COLORS.p1);
      else if (ch === 'u' && tile(tx, ty + 1) !== 'u' && tile(tx - 1, ty) !== 'u' && has('glide')) bubble(tx + .5, ty, '🪂', COLORS.p2);
      else if ((ch === 'G' || ch === 'T') && tile(tx, ty - 1) !== ch) bubble(tx, ty, ch === 'G' ? 'P1' : 'P2', ch === 'G' ? COLORS.p1 : COLORS.p2);
    }
  }

  /* ---------------- loop ---------------- */
  let last = performance.now(), acc = 0;
  let bars = 0, barsTarget = 0, intro = null, lastDraw = 0;
  function frame(now) {
    const dt = Math.min(.05, (now - last) / 1000); last = now;
    requestAnimationFrame(frame);
    if (S.quality !== 'hd' && now - lastDraw < 31) return;      // battery saver: ~30 fps
    lastDraw = now;
    if (state === 'intro' && intro) {
      // cinematic fly-through: from the portal back to the pack
      intro.t += dt;
      const k = Math.min(1, intro.t / intro.dur), e = k < .5 ? 2 * k * k : 1 - Math.pow(-2 * k + 2, 2) / 2;
      cam.x = intro.from + (intro.to - intro.from) * e;
      L.t += dt; barsTarget = S.cinema ? 1 : 0;
      if (k >= 1) startPlay();
    }
    if (state === 'play' && net.role === 'guest') { readPads(); guestTick(dt); hud(); }
    else if (state === 'play') {
      readPads();
      if (mode === 'solo' && pads[0].swap && !pads.swapHeld) swap();
      pads.swapHeld = pads[0].swap;
      let scaleT = 1;
      if (L.ending) { L.ending -= dt; scaleT = .35; barsTarget = S.cinema ? 1 : 0; if (L.ending <= 0) { L.ending = 0; chapterDone(); } }
      else barsTarget = 0;
      acc += dt * scaleT;
      const STEP = 1 / 120;
      while (acc >= STEP && state === 'play') {
        const inp = [0, 1].map(s => L.ending ? NOIN : mode === 'solo' && s !== active ? NOIN : mode === 'online' ? (s === 0 ? controls(0) : net.remote) : controls(s));
        // the lower dog moves first so a rider follows its mount
        const order = dogs[0].y > dogs[1].y ? [0, 1] : [1, 0];
        order.forEach(i => stepDog(dogs[i], STEP, inp[i]));
        updateWorld(STEP);
        if (!L.ending) lvStats.time += STEP;
        acc -= STEP;
      }
      hud();
      if (net.role === 'host' && now - net.lastSnap > 50) { net.lastSnap = now; net.send(snapshot()); }
    }
    bars += (barsTarget - bars) * Math.min(1, dt * 3);
    draw();
  }

  /* ---------------- UI ---------------- */
  const ui = $('#tp-ui');
  const tipEl = $('#tp-tip'), tipText = $('#tp-tip-text'), tipIcon = $('#tp-tip-icon');
  const TIP_ICONS = { pack: '🐾', stack: '⇡', door: '◧', split: '⇆', glide: '🪂', bridge: '═', drum: '🥁', wind: '≋', latch: '⚿', boost: '✦', grip: '🐾', swap: '⇄' };
  const csrf = document.querySelector('meta[name="csrf"]')?.content || '';
  const esc = v => String(v ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const FLAGS = window.TP_FLAGS || {};
  let hintTimer = 0, current = 'title', backTo = 'title';
  // tips: open briefly at the top, then fold into a glowing button the players can tap to reread
  function showHint(text, icon = 'pack') {
    if (!S.hints || !text) return;
    tipText.textContent = text; tipIcon.textContent = TIP_ICONS[icon] || '💡';
    tipEl.hidden = false; tipEl.classList.add('open', 'fresh');
    clearTimeout(hintTimer); hintTimer = setTimeout(() => tipEl.classList.remove('open'), 4200);
    setTimeout(() => tipEl.classList.remove('fresh'), 1200);
  }
  tipEl.addEventListener('click', e => { e.stopPropagation(); const open = !tipEl.classList.contains('open'); tipEl.classList.toggle('open', open); clearTimeout(hintTimer); if (open) hintTimer = setTimeout(() => tipEl.classList.remove('open'), 6000); });
  const fmt = s => `${Math.floor(s / 60)}:${String(Math.floor(s % 60)).padStart(2, '0')}`;
  function hud() {
    $('[data-hud="chapter"]').textContent = `${L.src.sub} · ${L.src.name}`;
    $('[data-hud="time"]').textContent = fmt(run.time + lvStats.time);
    $('[data-hud="coins"]').textContent = run.coins + lvStats.coins;
    $('[data-hud="deaths"]').textContent = run.deaths + lvStats.deaths;
    const drumEl = $('[data-hud="drum"]');
    drumEl.hidden = !(L.drum > 0); if (L.drum > 0) drumEl.textContent = `Sky bridge ${L.drum.toFixed(1)}s`;
  }
  function screen(name) {
    if (name && name !== current && !['intro'].includes(name)) backTo = current && current !== name ? current : backTo;
    current = name;
    $$('.tp-screen').forEach(el => (el.hidden = el.dataset.screen !== name));
    ui.hidden = !name;
    ui.classList.toggle('see-through', name === 'intro');
    root.classList.toggle('is-playing', !name);
    root.classList.toggle('is-intro', name === 'intro');
    if (name) ui.scrollTop = 0;
  }

  /* ----- players (sign up before playing) ----- */
  let profile = store.get('tp-profile', { team: '', p1: '', p2: '', guest: false });
  let xState = { configured: false, players: {} };
  const cleanHandle = v => String(v || '').trim().replace(/^@/, '').replace(/^https?:\/\/(www\.)?(x|twitter)\.com\//i, '').split(/[/?#\s]/)[0];
  const validHandle = h => /^[A-Za-z0-9_]{1,15}$/.test(h);
  function paintPlayers() {
    const f = $('#tp-players');
    f.team.value = profile.team || '';
    ['p1', 'p2'].forEach(slot => {
      const box = $(`[data-xslot="${slot}"]`, f), me = xState.players[slot];
      box.hidden = slot === 'p2' && mode !== 'coop';
      f[slot].value = me ? me.username : profile[slot] || '';
      f[slot].readOnly = !!me;
      $('.tp-xbtn', box).hidden = !xState.configured || !!me;
      const who = $('.tp-x-who', box);
      who.hidden = !me;
      if (me) who.innerHTML = `${me.avatar ? `<img src="${esc(me.avatar)}" alt="" width="20" height="20" referrerpolicy="no-referrer">` : ''} Signed in as <b>${esc(me.name)}</b> <i class="tp-tick">✓</i> · <a href="api/x-auth.php?logout=${slot}">switch</a>`;
      const av = $('.tp-avatar', box), h = cleanHandle(f[slot].value);
      av.style.backgroundImage = validHandle(h) ? `url("${me && me.avatar ? me.avatar : 'https://unavatar.io/x/' + h}")` : '';
    });
    $('#tp-players-msg').textContent = '';
  }
  function playersSummary() {
    const el = $('#tp-who'); if (!el) return;
    if (profile.guest || !profile.p1) { el.innerHTML = `Playing as guests · <button type="button" class="tp-link" data-act="players">add names</button>`; return; }
    const names = [profile.p1, mode === 'coop' ? profile.p2 : ''].filter(Boolean).map(h => '@' + esc(h)).join(' + ');
    el.innerHTML = `${FLAGS[profile.team] || '🌍'} Team ${esc(profile.team)} · ${names} · <button type="button" class="tp-link" data-act="players">change</button>`;
  }
  function savePlayers(guest) {
    const f = $('#tp-players'), msg = $('#tp-players-msg');
    if (guest) { profile.guest = true; store.set('tp-profile', profile); return true; }
    const p1 = cleanHandle(f.p1.value), p2 = cleanHandle(f.p2.value);
    if (!f.team.value) { msg.textContent = 'Pick the nation team you play for.'; f.team.focus(); return false; }
    if (!validHandle(p1)) { msg.textContent = "Add Player 1's X handle (letters, numbers and _)."; f.p1.focus(); return false; }
    if (mode === 'coop' && !validHandle(p2)) { msg.textContent = "Add Player 2's X handle, or switch to Solo."; f.p2.focus(); return false; }
    profile = { team: f.team.value, p1, p2: mode === 'coop' ? p2 : profile.p2, guest: false };
    store.set('tp-profile', profile);
    return true;
  }
  $('#tp-players').addEventListener('input', e => { if (e.target.name === 'p1' || e.target.name === 'p2') { const av = $(`[data-xslot="${e.target.name}"] .tp-avatar`), h = cleanHandle(e.target.value); av.style.backgroundImage = validHandle(h) ? `url("https://unavatar.io/x/${h}")` : ''; } });
  $('#tp-players').addEventListener('submit', e => { e.preventDefault(); if (savePlayers(false)) { if (mode === 'online') openLobby(); else { renderPicker(); screen('pick'); } } });
  // remember where we were when leaving for X sign-in
  root.addEventListener('click', e => { if (!e.target.closest('a[href^="api/x-auth.php"]')) return; const f = $('#tp-players'); profile.team = f.team.value; profile.p1 = cleanHandle(f.p1.value); profile.p2 = cleanHandle(f.p2.value); store.set('tp-profile', profile); try { sessionStorage.setItem('tp-flow', JSON.stringify({ screen: 'players', mode })); } catch {} });

  /* ----- dog picker ----- */
  function renderPicker() {
    const grid = $('#tp-roster');
    grid.innerHTML = '';
    DOA.roster.forEach(c => {
      const b = document.createElement('button');
      b.type = 'button'; b.className = 'tp-pick'; b.dataset.id = c.id;
      b.append(DOA.portrait(c.id, 160));
      const n = document.createElement('span'); n.innerHTML = `<b>${c.name}</b><small>${c.flag} ${c.title}</small>`; b.append(n);
      const tag = document.createElement('i'); tag.className = 'tp-tag'; b.append(tag);
      b.addEventListener('click', () => {
        const slot = mode === 'online' ? net.slot : Number($('#tp-roster').dataset.slot || 0);
        if (picks[1 - slot] === c.id) { if (mode === 'online') return; picks[1 - slot] = picks[slot]; }
        picks[slot] = c.id; store.set('tp-picks', picks);
        if (mode === 'coop') $('#tp-roster').dataset.slot = String(1 - slot);
        if (mode === 'online') net.send({ t: 'picks', picks });
        syncPicker();
      });
      grid.append(b);
    });
    syncPicker(); playersSummary();
  }
  function syncPicker() {
    const slot = Number($('#tp-roster').dataset.slot || 0);
    $$('.tp-pick').forEach(b => {
      const s = picks.indexOf(b.dataset.id);
      b.classList.toggle('p1', s === 0); b.classList.toggle('p2', s === 1);
      b.querySelector('.tp-tag').textContent = s === 0 ? 'P1 · Drum' : s === 1 ? 'P2 · Cape' : '';
    });
    $$('[data-slot-btn]').forEach(b => b.setAttribute('aria-pressed', String(Number(b.dataset.slotBtn) === slot)));
    [0, 1].forEach(s => {
      const c = DOA.byId[picks[s]], el = $(`[data-pick-name="${s}"]`);
      let who = profile.guest ? '' : s === 0 ? profile.p1 : mode === 'coop' ? profile.p2 : profile.p1;
      if (mode === 'online') who = s === net.slot ? (profile.guest ? '' : profile.p1) : (net.peer.handle || '');
      if (el) el.textContent = c.name + (who ? ` · @${who}` : mode === 'online' && s !== net.slot ? ` · ${net.peer.name || 'partner'}` : '');
    });
    const host = mode !== 'online' || net.role === 'host';
    $$('[data-screen="pick"] [data-act="start"], [data-screen="pick"] [data-act="chapters"]').forEach(b => (b.hidden = !host));
    $('#tp-pick-wait').hidden = host;
  }

  function chapters() {
    const unlocked = store.get('tp-unlocked', 1);
    const list = $('#tp-chapters'); list.innerHTML = '';
    LEVELS.forEach((lv, i) => {
      const b = document.createElement('button'); b.type = 'button'; b.className = 'tp-ch';
      b.disabled = i >= unlocked;
      b.innerHTML = `<small>${lv.sub}</small><b>${lv.name}</b><span>${i >= unlocked ? 'Locked' : lv.coins + ' coins'}</span>`;
      b.style.setProperty('--a', lv.sky[0]); b.style.setProperty('--b', lv.sky[1]);
      b.addEventListener('click', () => startRun(i, true));
      list.append(b);
    });
  }

  function setTouchMode() {
    pad.dataset.mode = mode;
    $('#tp-touch-solo').hidden = mode === 'coop';
    $$('.tp-cluster[data-who="0"], .tp-cluster[data-who="1"]').forEach(c => (c.hidden = mode !== 'coop'));
    $$('[data-btn="swap"]').forEach(b => (b.hidden = mode !== 'solo'));
    const tag = $('#tp-me-tag'); if (tag) { tag.hidden = mode !== 'online'; tag.textContent = net.slot ? 'You: P2 · Cape' : 'You: P1 · Drum'; tag.className = 'tp-me-tag ' + (net.slot ? 'p2t' : 'p1t'); }
  }

  /* ----- run flow ----- */
  function startRun(from = 0, isPractice = false) {
    audio(); practice = isPractice; chapter = from;
    run = { time: 0, coins: 0, deaths: 0, levels: 0 };
    active = 0; window.__tpActive = 0;
    begin();
  }
  function begin() {
    if (net.role === 'host') net.send({ t: 'begin', chapter, picks, practice, run });
    loadLevel(chapter);
    setTouchMode();
    $('#tp-intro-sub').textContent = L.src.sub; $('#tp-intro-name').textContent = L.src.name;
    const startX = clampCam(midX() - VW / 2), endX = clampCam(L.W * T - VW);
    intro = { t: 0, dur: S.cinema && !REDUCE ? 3.4 : .6, from: S.cinema ? endX : startX, to: startX };
    cam.x = intro.from;
    screen('intro'); state = 'intro';
    music(true);
  }
  function paintSkills() {
    const bar = $('#tp-skills'); if (!bar) return;
    bar.innerHTML = Object.entries(SKILLS).filter(([k]) => has(k)).map(([k, v]) => `<button type="button" class="tp-skill" data-skill="${k}" title="${esc(v.name)}"><span aria-hidden="true">${v.icon}</span><b class="sr">${esc(v.name)}</b></button>`).join('');
  }
  $('#tp-skills').addEventListener('click', e => { const b = e.target.closest('[data-skill]'); if (!b) return; const v = SKILLS[b.dataset.skill]; showHint(`${v.name} (${v.who}): ${v.text}`, b.dataset.skill === 'bark' ? 'drum' : b.dataset.skill); });
  function startPlay() {
    paintSkills();
    intro = null; screen(null); state = 'play'; last = performance.now(); acc = 0;
    L.hintIdx = -1;
  }
  function chapterDone() {
    if (net.role === 'host') net.send({ t: 'done', chapter, run: { ...run }, lv: { ...lvStats } });
    state = 'done';
    run.time += lvStats.time; run.coins += lvStats.coins; run.deaths += lvStats.deaths; run.levels++;
    const unlocked = store.get('tp-unlocked', 1); if (chapter + 2 > unlocked) store.set('tp-unlocked', Math.min(LEVELS.length, chapter + 2));
    $('#tp-done-title').textContent = `${L.src.name} cleared`;
    $('#tp-done-stats').innerHTML = `<div><b>${fmt(lvStats.time)}</b><span>time</span></div><div><b>${lvStats.coins}/${L.src.coins}</b><span>coins</span></div><div><b>${lvStats.deaths}</b><span>falls</span></div>`;
    const nu = Object.entries(SKILLS).find(([, v]) => v.from === chapter + 1);
    const un = $('#tp-unlock');
    if (nu && chapter + 1 < LEVELS.length) {
      un.hidden = false;
      un.innerHTML = `<span class="tp-unlock-icon" aria-hidden="true">${nu[1].icon}</span><span><small>New skill unlocked · ${esc(nu[1].who)}</small><b>${esc(nu[1].name)}</b><span>${esc(nu[1].text)}</span></span>`;
      setTimeout(() => SFX.check(), 400);
    } else un.hidden = true;
    const lastCh = chapter >= LEVELS.length - 1 || practice;
    $('#tp-next').hidden = net.role === 'guest'; $('#tp-wait').hidden = net.role !== 'guest';
    $('#tp-next').textContent = lastCh ? 'See your score' : 'Next chapter';
    screen('done');
  }
  $('#tp-next').addEventListener('click', () => {
    if (practice || chapter >= LEVELS.length - 1) return finish();
    chapter++; begin();
  });
  function score(r) {
    const time = Math.round(r.time);
    const bonus = r.levels >= LEVELS.length ? Math.max(0, 900 - time) * 5 : 0;
    return Math.max(0, r.levels * 1000 + r.coins * 100 + bonus - r.deaths * 25);
  }
  let lastRun = null;
  function finish() {
    if (net.role === 'host') net.send({ t: 'over', run: { ...run } });
    state = 'over'; music(false);
    const sc = score(run);
    lastRun = { ...run, score: sc, picks: [...picks], mode, practice };
    $('#tp-final-score').textContent = sc.toLocaleString();
    $('#tp-final-stats').innerHTML = `<div><b>${run.levels}/${LEVELS.length}</b><span>chapters</span></div><div><b>${fmt(run.time)}</b><span>time</span></div><div><b>${run.coins}</b><span>coins</span></div><div><b>${run.deaths}</b><span>falls</span></div>`;
    const dogsUsed = mode === 'coop' ? [picks[0], picks[1]] : [picks[0], picks[1]];
    $('#tp-duo').innerHTML = ''; dogsUsed.forEach(id => $('#tp-duo').append(DOA.portrait(id, 96)));
    const p = dogsUsed.map(id => DOA.byId[id]);
    const share = `We cleared ${run.levels} chapters of Two Paws on @Barkmediafrica with ${p[0].name} + ${p[1].name}: ${sc.toLocaleString()} points${profile.team && !profile.guest ? ' for Team ' + profile.team : ''}. Ubuntu wins.`;
    $('#tp-share').href = 'https://x.com/intent/post?text=' + encodeURIComponent(share) + '&url=' + encodeURIComponent(location.origin + location.pathname);
    $('#tp-over-board').innerHTML = '';
    const status = $('#tp-post-status'), guestForm = $('#tp-guest-form');
    guestForm.hidden = true;
    if (net.role === 'guest') status.innerHTML = '<span class="tp-spin" aria-hidden="true"></span> Your partner\'s device is posting your team score…';
    else if (practice) status.textContent = 'Practice run: start a full run from the menu to post a score.';
    else if (run.levels < 1) status.textContent = 'Clear at least one chapter to post a score.';
    else if (profile.guest || !profile.p1 || (mode === 'coop' && !profile.p2)) { status.textContent = 'Add your names to put this score on the leaderboard.'; guestForm.hidden = false; guestForm.team.value = profile.team || ''; guestForm.p1.value = profile.p1 || ''; guestForm.p2.value = profile.p2 || ''; guestForm.querySelector('[data-xslot="p2"]').hidden = mode === 'solo'; }
    else postRun();
    screen('over');
  }

  /* ----- leaderboard ----- */
  const API = 'api/leaderboard.php';
  let board = null, boardTab = 'teams', highlight = null;
  const local = () => store.get('tp-local-board', []);
  function localBoard() {
    const runs = local().sort((a, b) => b.score - a.score), by = {};
    runs.forEach(r => (by[r.team] = by[r.team] || []).push(r));
    const teams = Object.entries(by).map(([team, list]) => { const top = list.slice(0, 3), ppl = new Set(); list.forEach(r => ['p1', 'p2'].forEach(k => r[k] && r[k].handle && ppl.add(r[k].handle.toLowerCase()))); return { team, flag: FLAGS[team] || '🌍', power: Math.round(top.reduce((a, r) => a + r.score, 0) / top.length), best: list[0].score, runs: list.length, players: ppl.size, duo: [list[0].p1, list[0].p2] }; }).sort((a, b) => b.power - a.power);
    return { ok: true, runs: runs.slice(0, 25), teams, total: runs.length, offline: true };
  }
  async function getBoard() {
    try { const r = await fetch(API, { cache: 'no-store' }); const d = await r.json(); if (!d.ok) throw 0; return d; } catch { return localBoard(); }
  }
  const person = pp => {
    if (!pp || !pp.handle) return '';
    const letter = esc(pp.handle[0].toUpperCase());
    const av = pp.avatar ? `<img src="${esc(pp.avatar)}" alt="" width="28" height="28" loading="lazy" referrerpolicy="no-referrer" onerror="this.outerHTML='<span class=lb-av>${letter}</span>'">` : `<span class="lb-av">${letter}</span>`;
    return `<a class="lb-person" href="https://x.com/${esc(pp.handle)}" target="_blank" rel="noopener">${av}<span>@${esc(pp.handle)}${pp.verified ? ' <i class="tp-tick" title="Signed in with X">✓</i>' : ''}</span></a>`;
  };
  function boardHTML(d, tab, limit = 25) {
    const note = d.offline ? '<p class="lb-offline">Showing scores saved on this device; the live board is not reachable right now.</p>' : '';
    if (tab === 'teams') return note + (d.teams.length ? `<ol class="lb-list">${d.teams.slice(0, limit).map((t, i) => `
      <li class="lb-row ${i < 3 ? 'top' + (i + 1) : ''} ${!profile.guest && t.team === profile.team ? 'is-you' : ''}">
        <span class="lb-rank">${i + 1}</span>
        <span class="lb-team"><span class="lb-flag">${t.flag}</span><b>${esc(t.team)}</b><small>${t.runs} run${t.runs === 1 ? '' : 's'} · ${t.players} player${t.players === 1 ? '' : 's'}</small></span>
        <span class="lb-duo">${person(t.duo[0])}${person(t.duo[1])}</span>
        <span class="lb-score"><b>${t.power.toLocaleString()}</b><small>team power</small></span>
      </li>`).join('')}</ol>` : '<p class="tp-sub">No scores yet. Be the first duo to put your nation on the board.</p>');
    return note + (d.runs.length ? `<ol class="lb-list">${d.runs.slice(0, limit).map((r, i) => `
      <li class="lb-row ${i < 3 ? 'top' + (i + 1) : ''} ${highlight && highlight.at === r.at && highlight.score === r.score ? 'is-you' : ''}">
        <span class="lb-rank">${i + 1}</span>
        <span class="lb-duo">${person(r.p1)}${person(r.p2)}</span>
        <span class="lb-team sm"><span class="lb-flag">${FLAGS[r.team] || '🌍'}</span><small>${esc(r.team)} · ${r.levels}/4 · ${fmt(r.time)}</small></span>
        <span class="lb-score"><b>${r.score.toLocaleString()}</b><small>${r.coins} coins</small></span>
      </li>`).join('')}</ol>` : '<p class="tp-sub">No runs posted yet.</p>');
  }
  function renderBoard() { $('#tp-board-body').innerHTML = board ? boardHTML(board, boardTab) : '<p class="tp-sub">Loading…</p>'; $$('[data-lb-tab]').forEach(x => x.setAttribute('aria-selected', String(x.dataset.lbTab === boardTab))); }
  $$('[data-lb-tab]').forEach(b => b.addEventListener('click', () => { boardTab = b.dataset.lbTab; renderBoard(); }));
  async function openBoard() { screen('board'); renderBoard(); board = await getBoard(); renderBoard(); }

  async function postRun() {
    const status = $('#tp-post-status');
    status.innerHTML = '<span class="tp-spin" aria-hidden="true"></span> Posting your score…';
    const fd = new FormData();
    const p2h = lastRun.mode === 'coop' ? profile.p2 : lastRun.mode === 'online' ? (validHandle(net.peer.handle || '') ? net.peer.handle : '') : '';
    Object.entries({ csrf, team: profile.team, p1: profile.p1, p2: p2h, mode: p2h ? 'coop' : 'solo', c1: lastRun.picks[0], c2: lastRun.picks[1], levels: lastRun.levels, coins: lastRun.coins, deaths: lastRun.deaths, time: lastRun.time.toFixed(2) }).forEach(([k, v]) => fd.set(k, v));
    try {
      const r = await fetch(API, { method: 'POST', body: fd, credentials: 'same-origin' });
      const d = await r.json();
      if (!d.ok) throw new Error(d.message || 'Could not post');
      board = d; highlight = d.runs[d.rank - 1] || null;
      const teamRank = d.teams.findIndex(t => t.team === profile.team) + 1;
      status.innerHTML = `Posted! <b>#${d.rank}</b> overall · ${FLAGS[profile.team] || ''} Team ${esc(profile.team)} is <b>#${teamRank}</b>`;
      if (net.role === 'host') net.send({ t: 'posted', html: status.innerHTML, board: { ...d, runs: d.runs.slice(0, 5) }, hl: highlight });
    } catch (e) {
      if (e && e.message && !/Failed to fetch|NetworkError|JSON|Load failed/i.test(e.message)) { status.textContent = e.message; return; }
      const avatar = h => h ? 'https://unavatar.io/x/' + encodeURIComponent(h) : '';
      const runRec = { score: lastRun.score, team: profile.team, mode: lastRun.mode, p1: { handle: profile.p1, avatar: avatar(profile.p1) }, p2: lastRun.mode === 'coop' ? { handle: profile.p2, avatar: avatar(profile.p2) } : { handle: '' }, levels: lastRun.levels, coins: lastRun.coins, deaths: lastRun.deaths, time: lastRun.time, at: new Date().toISOString() };
      const all = local(); all.push(runRec); store.set('tp-local-board', all.slice(-200));
      board = localBoard(); highlight = runRec;
      status.textContent = 'Saved on this device (the live board is offline).';
    }
    boardTab = 'runs';
    $('#tp-over-board').innerHTML = boardHTML(board, 'runs', 5);
  }
  $('#tp-guest-form').addEventListener('submit', e => {
    e.preventDefault();
    const f = e.target, p1 = cleanHandle(f.p1.value), p2 = cleanHandle(f.p2.value), msg = $('#tp-post-status');
    if (!f.team.value) { msg.textContent = 'Pick your nation team.'; return; }
    if (!validHandle(p1) || (lastRun.mode === 'coop' && !validHandle(p2))) { msg.textContent = 'Add valid X handles (letters, numbers and _).'; return; }
    profile = { team: f.team.value, p1, p2, guest: false }; store.set('tp-profile', profile);
    f.hidden = true; postRun();
  });

  /* ----- settings ----- */
  function applySettings() {
    root.style.setProperty('--btn', { s: '52px', m: '62px', l: '74px' }[S.touchSize] || '62px');
    root.style.setProperty('--btn-alpha', S.touchAlpha);
    root.classList.toggle('lefty', !!S.lefty);
    applyVolumes(); fitCanvas();
    if (state === 'play' || state === 'intro') { if (S.music && !padNodes.length) music(true); if (!S.music) music(false); }
    $('[data-act="mute"]').setAttribute('aria-pressed', String(!S.music && !S.sfx));
  }
  function paintSettings() {
    $$('[data-set]').forEach(el => {
      const k = el.dataset.set;
      if (el.type === 'checkbox') el.checked = !!S[k];
      else if (el.type === 'range') el.value = Math.round(S[k] * 100);
      else el.value = S[k];
    });
  }
  $('#tp-settings').addEventListener('input', e => {
    const el = e.target.closest('[data-set]'); if (!el) return;
    const k = el.dataset.set;
    S[k] = el.type === 'checkbox' ? el.checked : el.type === 'range' ? Number(el.value) / 100 : el.value;
    if (k === 'calm' && S.calm) { S.shake = false; paintSettings(); }
    saveSettings();
    if (k === 'sfx') tone(660, .12, 'sine', .05);
  });
  $('[data-act="reset-settings"]').addEventListener('click', () => { Object.assign(S, DEFAULTS); paintSettings(); saveSettings(); });

  function pause(fromNet) { if (state !== 'play') return; state = 'pause'; screen('pause'); keys.clear(); if (!fromNet) net.send({ t: 'pause' }); }
  function resume(fromNet) { if (state !== 'pause') return; screen(null); state = 'play'; last = performance.now(); if (!fromNet) net.send({ t: 'resume' }); }
  function swap() { if (mode !== 'solo') return; active = 1 - active; window.__tpActive = active; tone(520, .08, 'sine', .04); showHint(`Now playing ${DOA.byId[picks[active]].name} (${active ? 'Cape dog' : 'Drum dog'})`, 'swap'); }

  // buttons
  root.addEventListener('click', e => {
    const b = e.target.closest('[data-act]'); if (!b) return;
    const a = b.dataset.act;
    audio();
    if (a === 'play') screen('mode');
    if (a === 'online') { mode = 'online'; $('#tp-mode-label').textContent = 'Online · each on your own device'; paintPlayers(); screen('players'); }
    if (a === 'coop' || a === 'solo') { mode = a; $('#tp-mode-label').textContent = a === 'coop' ? 'Co-op · two players, one screen' : 'Solo · one player, swap dogs'; $('#tp-roster').dataset.slot = '0'; $$('[data-slot-btn="1"]').forEach(x => (x.hidden = a === 'solo')); paintPlayers(); screen('players'); }
    if (a === 'players') { paintPlayers(); screen('players'); }
    if (a === 'mode') screen('mode');
    if (a === 'guest') { savePlayers(true); if (mode === 'online') openLobby(); else { renderPicker(); screen('pick'); } }
    if (a === 'how') screen('how');
    if (a === 'board') openBoard();
    if (a === 'settings') { paintSettings(); screen('settings'); }
    if (a === 'back') screen(state === 'pause' ? 'pause' : backTo && backTo !== current ? backTo : 'title');
    if (a === 'title') { if (net.role) netLeave(); state = 'title'; music(false); screen('title'); }
    if (a === 'create-room') createRoom();
    if (a === 'cancel-link') { netLeave(); openLobby(); }
    if (a === 'invite') invite(b.dataset.to, b.dataset.name);
    if (a === 'accept') acceptInvite();
    if (a === 'decline') declineInvite();
    if (a === 'start') startRun(0, false);
    if (a === 'chapters') { chapters(); screen('chapters'); }
    if (a === 'resume') resume();
    if (a === 'restart') { lvStats = { time: 0, coins: 0, deaths: 0 }; begin(); }
    if (a === 'quit') { run.time += lvStats.time; run.coins += lvStats.coins; run.deaths += lvStats.deaths; finish(); }
    if (a === 'pause') pause();
    if (a === 'mute') { const off = S.music || S.sfx; if (off) { S._m = S.music; S._s = S.sfx; S.music = 0; S.sfx = 0; } else { S.music = S._m || DEFAULTS.music; S.sfx = S._s || DEFAULTS.sfx; } saveSettings(); }
    if (a === 'full') {
      const el = document.documentElement;
      if (document.fullscreenElement || document.webkitFullscreenElement) (document.exitFullscreen || document.webkitExitFullscreen).call(document);
      else { const req = el.requestFullscreen || el.webkitRequestFullscreen; if (req) { const pr = req.call(el); pr && pr.then && pr.then(() => window.screen.orientation?.lock?.('landscape').catch(() => {})).catch(() => {}); } }
    }
    if (a === 'again') startRun(0, false);
  });
  $$('[data-slot-btn]').forEach(b => b.addEventListener('click', () => { $('#tp-roster').dataset.slot = b.dataset.slotBtn; syncPicker(); }));
  document.addEventListener('visibilitychange', () => { if (document.hidden) pause(); });
  applySettings();

  // X sign-in status, and coming back from X
  fetch('api/x-auth.php?status', { cache: 'no-store' }).then(r => r.json()).then(d => { xState = d; if (current === 'players') paintPlayers(); }).catch(() => {});
  try {
    const flow = JSON.parse(sessionStorage.getItem('tp-flow') || 'null');
    const xp = new URLSearchParams(location.search).get('x');
    if (flow && xp) { sessionStorage.removeItem('tp-flow'); mode = flow.mode || 'coop'; setTimeout(() => { $('[data-act="' + mode + '"]').click(); const m = { ok: 'Signed in with X ✓', failed: 'X sign-in did not finish. Type your handle instead.', cancelled: 'X sign-in was cancelled.', expired: 'That sign-in expired. Try again.', off: 'X sign-in is not switched on yet. Type your handle.' }[xp]; if (m) $('#tp-players-msg').textContent = m; }, 300); history.replaceState(null, '', location.pathname); }
  } catch {}
  if (location.hash === '#board') setTimeout(openBoard, 200);

  /* ---------------- online co-op ----------------
     Lobby + invites through api/room.php, then a direct WebRTC data channel.
     The host's device runs the game; the guest sends its controls and draws the host's snapshots. */
  const ICE = { iceServers: [{ urls: ['stun:stun.l.google.com:19302', 'stun:stun1.l.google.com:19302'] }, { urls: 'stun:stun.cloudflare.com:3478' }] };
  const myId = (() => { let v = store.get('tp-id', ''); if (!/^[a-f0-9]{16}$/.test(v)) { v = [...crypto.getRandomValues(new Uint8Array(8))].map(b => b.toString(16).padStart(2, '0')).join(''); store.set('tp-id', v); } return v; })();
  const netMsg = t => { const el = $('#tp-net-msg'); if (el) el.textContent = t || ''; };
  const myName = () => (!profile.guest && profile.p1 ? '@' + profile.p1 : 'Guest ' + myId.slice(0, 4).toUpperCase());
  async function api(act, data = {}) {
    const fd = new FormData(); fd.set('csrf', csrf); fd.set('id', myId); fd.set('act', act);
    Object.entries(data).forEach(([k, v]) => fd.set(k, v));
    try { const r = await fetch('api/room.php', { method: 'POST', body: fd, credentials: 'same-origin' }); return await r.json(); }
    catch { return { ok: false, message: 'Online play needs the site running on your server.' }; }
  }
  let pendingInvite = null, helloBusy = false;
  async function hello() {
    if (document.hidden || helloBusy) return;
    helloBusy = true;
    const d = await api('hello', { name: myName(), team: profile.team || '', busy: net.role || state === 'play' ? 1 : '' });
    helloBusy = false;
    if (!d.ok) { if (current === 'online') netMsg(d.message); return; }
    if (current === 'online') paintLobby(d);
    const inv = (d.invites || [])[0];
    if (inv && !net.role && (!pendingInvite || pendingInvite.room !== inv.room) && state !== 'play') {
      pendingInvite = inv;
      $('#tp-invite-text').innerHTML = `<b>${esc(inv.name)}</b>${inv.team ? ' · ' + (FLAGS[inv.team] || '') + ' ' + esc(inv.team) : ''} wants to team up`;
      $('#tp-invite').hidden = false; tone(880, .15, 'sine', .05); buzz(30);
    }
  }
  setInterval(() => { if (current === 'online' || (!net.role && state !== 'play')) hello(); }, 4000);
  addEventListener('pagehide', () => { try { const fd = new FormData(); fd.set('csrf', csrf); fd.set('id', myId); fd.set('act', 'bye'); navigator.sendBeacon('api/room.php', fd); } catch {} });

  function paintLobby(d) {
    $('#tp-online-count').textContent = d.others.length ? `${d.others.length} online` : '';
    $('#tp-lobby-list').innerHTML = d.others.length ? d.others.map(o => `
      <li><span class="tp-av-dot" aria-hidden="true">${esc((o.name.replace('@', '')[0] || '?').toUpperCase())}</span>
        <span class="tp-lname"><b>${esc(o.name)}</b><small>${o.flag} ${esc(o.team || 'No team yet')}${o.busy ? ' · playing' : ''}</small></span>
        <button type="button" class="btn btn-gold btn-sm" data-act="invite" data-to="${esc(o.id)}" data-name="${esc(o.name)}" ${o.busy ? 'disabled' : ''}>Team up</button></li>`).join('')
      : '<li class="tp-lempty">Nobody else is here right now. Share a room code, or ask a friend to open Two Paws.</li>';
  }
  function openLobby() {
    netLeave(true);
    $('#tp-me-name').textContent = myName();
    $('#tp-my-code').hidden = true; netMsg('');
    screen('online'); hello();
  }

  function stopTimers() { net.timers.forEach(clearInterval); net.timers = []; }
  function netLeave(silent) {
    stopTimers();
    if (net.ch && net.ch.readyState === 'open' && !silent) { try { net.ch.send(JSON.stringify({ t: 'bye' })); } catch {} }
    try { net.ch && net.ch.close(); } catch {} try { net.pc && net.pc.close(); } catch {}
    if (net.room) api('close', { room: net.room });
    Object.assign(net, { role: null, pc: null, ch: null, room: null, peer: {}, remote: { ...NOIN }, target: null, send() {} });
    root.classList.remove('is-guest', 'is-online');
  }
  function linkScreen(text) { $('#tp-link-text').textContent = text; screen('link'); }
  const waitIce = pc => new Promise(res => { if (pc.iceGatheringState === 'complete') return res(); const t = setTimeout(res, 2500); pc.addEventListener('icegatheringstatechange', () => { if (pc.iceGatheringState === 'complete') { clearTimeout(t); res(); } }); });

  function makePC() {
    const pc = new RTCPeerConnection(ICE);
    pc.addEventListener('connectionstatechange', () => { if (['failed', 'disconnected', 'closed'].includes(pc.connectionState) && net.pc === pc && net.ch && net.ch.readyState !== 'open') dropped("Couldn't connect directly. Some networks block device-to-device play: try another Wi-Fi or mobile data."); });
    return pc;
  }
  function wire(ch, role) {
    net.ch = ch;
    ch.onopen = () => {
      stopTimers();
      net.role = role; net.slot = role === 'host' ? 0 : 1; mode = 'online';
      root.classList.add('is-online'); root.classList.toggle('is-guest', role === 'guest');
      net.send = m => { if (ch.readyState === 'open') { try { ch.send(JSON.stringify(m)); } catch {} } };
      net.send({ t: 'hi', name: myName(), handle: profile.guest ? '' : profile.p1, team: profile.team || '', pick: picks[net.slot] });
      api('close', { room: net.room }); net.room = null;
      $('#tp-mode-label').textContent = 'Online · each on your own device';
      $('#tp-roster').dataset.slot = String(net.slot);
      renderPicker(); screen('pick'); SFX.check(); buzz(40);
    };
    ch.onmessage = e => { let m; try { m = JSON.parse(e.data); } catch { return; } onNet(m); };
    ch.onclose = () => { if (net.ch === ch && net.role) dropped('Your partner left the game.'); };
  }
  function dropped(text) {
    const wasPlaying = state === 'play' || state === 'pause' || state === 'intro';
    netLeave(true); mode = 'coop';
    state = 'title'; music(false); screen('title');
    showToast(text);
    void wasPlaying;
  }
  function showToast(text) { const t = $('#tp-toast'); t.textContent = text; t.hidden = false; clearTimeout(t._h); t._h = setTimeout(() => (t.hidden = true), 5000); }

  // host side
  async function hostRoom(code, label) {
    net.room = code; net.role = null;
    const pc = makePC(); net.pc = pc;
    const ch = pc.createDataChannel('tp', { ordered: true });
    wire(ch, 'host');
    let offered = false, started = Date.now();
    linkScreen(label);
    net.timers.push(setInterval(async () => {
      const d = await api('poll', { room: code });
      if (!d.ok) { dropped(d.message || 'The room closed.'); return; }
      const r = d.room;
      if (r.declined) { netLeave(true); openLobby(); netMsg('They said not now. Try again later.'); return; }
      if (r.guest && !offered) {
        offered = true; started = Date.now();
        linkScreen(`Connecting to ${r.guestName || 'your partner'}…`);
        await pc.setLocalDescription(await pc.createOffer()); await waitIce(pc);
        api('signal', { room: code, kind: 'offer', sdp: JSON.stringify(pc.localDescription) });
      }
      if (r.answer && !pc.currentRemoteDescription) { try { await pc.setRemoteDescription(JSON.parse(r.answer)); } catch {} }
      if (offered && Date.now() - started > 25000 && (!net.ch || net.ch.readyState !== 'open')) dropped("Couldn't connect directly. Some networks block device-to-device play: try another Wi-Fi or mobile data.");
    }, 1500));
  }
  async function invite(to, name) {
    const d = await api('invite', { to }); if (!d.ok) { netMsg(d.message); return; }
    hostRoom(d.room, `Waiting for ${name} to accept…`);
  }
  async function createRoom() {
    const d = await api('create'); if (!d.ok) { netMsg(d.message); return; }
    $('#tp-my-code').hidden = false; $('#tp-my-code').innerHTML = `Your code: <b>${d.room}</b>`;
    hostRoom(d.room, `Share this code with your partner: ${d.room}`);
    $('#tp-link-code').textContent = d.room; $('#tp-link-code').hidden = false;
  }
  // guest side
  async function joinRoom(code) {
    const d = await api('join', { room: code }); if (!d.ok) { netMsg(d.message); return; }
    net.room = d.room;
    const pc = makePC(); net.pc = pc;
    pc.ondatachannel = e => wire(e.channel, 'guest');
    linkScreen(`Connecting to ${d.hostName || 'your partner'}…`);
    let answered = false; const started = Date.now();
    net.timers.push(setInterval(async () => {
      const r = await api('poll', { room: d.room });
      if (!r.ok) { dropped(r.message || 'The room closed.'); return; }
      if (r.room.offer && !answered) {
        answered = true;
        await pc.setRemoteDescription(JSON.parse(r.room.offer));
        await pc.setLocalDescription(await pc.createAnswer()); await waitIce(pc);
        api('signal', { room: d.room, kind: 'answer', sdp: JSON.stringify(pc.localDescription) });
      }
      if (Date.now() - started > 30000 && (!net.ch || net.ch.readyState !== 'open')) dropped("Couldn't connect directly. Some networks block device-to-device play: try another Wi-Fi or mobile data.");
    }, 1500));
  }
  function acceptInvite() { $('#tp-invite').hidden = true; if (!pendingInvite) return; mode = 'online'; joinRoom(pendingInvite.room); pendingInvite = null; }
  function declineInvite() { $('#tp-invite').hidden = true; if (pendingInvite) api('decline', { room: pendingInvite.room }); pendingInvite = null; }
  $('#tp-join-form').addEventListener('submit', e => { e.preventDefault(); const c = e.target.code.value.trim().toUpperCase(); if (c.length !== 4) { netMsg('Room codes have 4 letters.'); return; } joinRoom(c); });

  // messages
  function onNet(m) {
    switch (m.t) {
      case 'hi': net.peer = { name: m.name, handle: m.handle, team: m.team }; if (m.pick) { if (picks[1 - net.slot] !== m.pick) { picks[1 - net.slot] = m.pick; if (picks[net.slot] === m.pick) picks[net.slot] = DOA.roster.find(c => c.id !== m.pick).id; } } if (current === 'pick') renderPicker(); if (net.role === 'host') net.send({ t: 'picks', picks }); showToast(`Teamed up with ${m.name}!`); break;
      case 'picks': if (net.role === 'guest') picks = m.picks; else { picks[1] = m.picks[1]; if (picks[0] === picks[1]) picks[0] = DOA.roster.find(c => c.id !== picks[1]).id; net.send({ t: 'picks', picks }); } if (current === 'pick') syncPicker(); break;
      case 'in': net.remote = { left: !!m.l, right: !!m.r, jump: !!m.j, power: !!m.p }; break;
      case 'begin': if (net.role === 'guest') { picks = m.picks; chapter = m.chapter; practice = m.practice; run = m.run; active = 0; audio(); begin(); } break;
      case 's': net.target = m; break;
      case 'tip': showHint(m.text, m.icon); break;
      case 'done': if (net.role === 'guest') { run = m.run; lvStats = m.lv; chapter = m.chapter; chapterDone(); } break;
      case 'over': if (net.role === 'guest') { run = m.run; finish(); } break;
      case 'posted': if (net.role === 'guest') { $('#tp-post-status').innerHTML = m.html; board = m.board; highlight = m.hl; $('#tp-over-board').innerHTML = boardHTML(board, 'runs', 5); } break;
      case 'pause': pause(true); break;
      case 'resume': resume(true); break;
      case 'bye': dropped('Your partner left the game.'); break;
    }
  }
  function snapshot() {
    const r1 = v => Math.round(v * 10) / 10;
    const fx = net.fx.splice(0);
    return { t: 's', d: dogs.map(d => [r1(d.x), r1(d.y), r1(d.vx), d.face, d.state, Math.round(d.at * 100) / 100, d.dead > 0 ? 1 : 0, Math.round(d.sq * 100) / 100]),
      o: [L.open.Q, L.open.W, L.open.E, L.open.V].map(v => Math.round(v * 100) / 100), b: [L.bridge.R, L.bridge.Y].map(v => Math.round(v * 100) / 100),
      dr: Math.round(L.drum * 10) / 10, ds: L.drumSeen ? 1 : 0, la: L.latched ? 1 : 0, c: L.coins.map(c => (c.got ? 1 : 0)).join(''), k: L.checks.map(k => (k.on ? 1 : 0)).join(''),
      br: L.broken, pr: L.pressed, st: [Math.round(lvStats.time * 10) / 10, lvStats.coins, lvStats.deaths], en: L.ending ? 1 : 0, fx };
  }
  // the guest: send controls, follow the host's world
  function guestTick(dt) {
    const c = controls(1), key = (c.left ? 1 : 0) + (c.right ? 2 : 0) + (c.jump ? 4 : 0) + (c.power ? 8 : 0);
    net.inT += dt;
    if (key !== net.lastIn || net.inT > .12) { net.lastIn = key; net.inT = 0; net.send({ t: 'in', l: c.left ? 1 : 0, r: c.right ? 1 : 0, j: c.jump ? 1 : 0, p: c.power ? 1 : 0 }); }
    L.t += dt;
    const m = net.target;
    if (m) {
      m.d.forEach((a, i) => {
        const d = dogs[i]; const far = Math.abs(d.x - a[0]) > 120 || Math.abs(d.y - a[1]) > 120;
        d.x = far ? a[0] : d.x + (a[0] - d.x) * Math.min(1, dt * 18); d.y = far ? a[1] : d.y + (a[1] - d.y) * Math.min(1, dt * 18);
        d.vx = a[2]; d.face = a[3]; d.state = a[4]; d.at = a[5]; d.dead = a[6] ? 1 : 0; d.sq = a[7];
      });
      [L.open.Q, L.open.W, L.open.E, L.open.V] = m.o; [L.bridge.R, L.bridge.Y] = m.b;
      L.drum = m.dr; L.drumSeen = !!m.ds; L.latched = !!m.la; L.pressed = m.pr || {}; L.ending = m.en ? 1 : 0;
      [...m.c].forEach((v, i) => { const c2 = L.coins[i]; if (c2 && v === '1' && !c2.got) { c2.got = true; for (let k = 0; k < 8; k++) particles.push({ x: c2.x * T + 16, y: c2.y * T + 16, vx: (Math.random() - .5) * 200, vy: (Math.random() - .8) * 200, life: .5, max: .5, c: '#FFE2A3', s: 3, g: 500 }); } });
      [...m.k].forEach((v, i) => { if (L.checks[i]) L.checks[i].on = v === '1'; });
      (m.br || []).forEach(([x, y]) => { if (L.grid[y][x] === 'x') { L.grid[y][x] = ' '; staticDirty = true; for (let k = 0; k < 6; k++) particles.push({ x: x * T + Math.random() * T, y: y * T + Math.random() * T, vx: (Math.random() - .5) * 300, vy: -Math.random() * 300, life: .8, max: .8, c: '#8E5A3A', s: 4, g: 900 }); } });
      lvStats = { time: m.st[0], coins: m.st[1], deaths: m.st[2] };
      (m.fx || []).forEach(n => SFX[n] && SFX[n]());
      m.fx = [];
    }
    // camera + effects, as on the host
    const focus = (dogs[0].x + dogs[1].x + DW) / 2;
    cam.x += (clampCam(focus - VW / 2) - cam.x) * Math.min(1, dt * (S.calm ? 3.2 : 6));
    particles = particles.filter(p => { p.life -= dt; p.x += p.vx * dt; p.y += p.vy * dt; if (p.g) p.vy += p.g * dt; return p.life > 0; });
    L.checks.forEach(k => (k.flag += ((k.on ? 1 : 0) - k.flag) * Math.min(1, dt * 4)));
    L.coins.forEach(c => (c.t += dt));
    const mx = focus / T, hs = L.src.hints; let idx = -1; hs.forEach(([x], i) => { if (mx >= x) idx = i; });
    if (idx !== L.hintIdx) { L.hintIdx = idx; if (idx >= 0) showHint(hs[idx][2], hs[idx][1]); }
  }
  // host: relay sound effects so both devices hear the same thing
  Object.keys(SFX).forEach(k => { const f = SFX[k]; SFX[k] = (...a) => { if (net.role === 'host') net.fx.push(k); return f(...a); }; });

  // title screen dogs dance on the canvas behind the menu
  loadLevel(0);
  state = 'title'; screen('title');
  (function attract() {
    if (state === 'title' || state === 'pick' || state === 'how' || state === 'chapters' || state === 'over') {
      L.t += 1 / 60; cam.x = (Math.sin(L.t * .05) * .5 + .5) * (L.W * T - VW);
      dogs.forEach((d, i) => {
        d.state = 'run'; d.at += .03; d.face = 1; d.x = cam.x + VW * (.42 + i * .12);
        const tx = Math.floor((d.x + DW / 2) / T); let top = 14;
        for (let y = 1; y < ROWS; y++) { const ch = tile(tx, y); if ((ch === '#' || ch === '=') && tile(tx, y - 1) !== '#') { top = y; if (y >= 9) break; } }
        d.y = top * T - DH - Math.abs(Math.sin(L.t * 3 + i)) * 26;
      });
    }
    setTimeout(attract, 16);
  })();
  requestAnimationFrame(frame);

  window.TwoPaws = { score, LEVELS, settings: S, debug: () => ({ dogs, L, cam, state, mode, profile }) };
})();
