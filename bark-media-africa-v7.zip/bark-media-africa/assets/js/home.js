/* Homepage extras: live X timeline (lazy), feature-card art, Dogecoin pulse */
(() => {
  const $ = (s, r = document) => r.querySelector(s);
  const REDUCE = matchMedia('(prefers-reduced-motion: reduce)').matches;

  // X timeline: load the official widget only when the section is near the screen
  const xe = $('#x-embed');
  if (xe) {
    const io = new IntersectionObserver(([e]) => {
      if (!e.isIntersecting) return; io.disconnect();
      const s = document.createElement('script'); s.src = 'https://platform.twitter.com/widgets.js'; s.async = true; s.charset = 'utf-8';
      document.body.append(s);
      // if X renders, hide our fallback
      const check = setInterval(() => { if (xe.querySelector('iframe')) { xe.classList.add('loaded'); clearInterval(check); } }, 500);
      setTimeout(() => clearInterval(check), 15000);
    }, { rootMargin: '400px' });
    io.observe(xe);
  }

  // Game card: the pack runs across a little savanna strip
  const dc = $('#feat-dogs');
  if (dc && window.DOA) {
    const x = dc.getContext('2d'); x.imageSmoothingEnabled = false;
    const ids = DOA.roster.map(c => c.id), rims = ['#F4B63F', '#2DB9DA', '#F4B63F', '#2DB9DA'];
    let t = 0, raf = 0;
    const draw = () => {
      t += 1 / 60;
      x.clearRect(0, 0, 640, 300);
      x.fillStyle = '#C2552F'; x.fillRect(0, 240, 640, 60); x.fillStyle = '#F1D3AA'; x.fillRect(0, 236, 640, 6);
      for (let i = 0; i < 640; i += 16) { x.fillStyle = '#13A881'; x.fillRect((i - (t * 120) % 16 + 640) % 640, 230, 3, 6); }
      ids.forEach((id, i) => {
        const hop = Math.abs(Math.sin(t * 5 + i * 1.3)) * (i % 2 ? 26 : 10);
        const spr = DOA.frame(id, { state: hop > 18 ? 'jump' : 'run', t: (t * 2 + i * .25) % 1, rim: rims[i], cape: i === 1, drum: i === 0 });
        x.drawImage(spr, 70 + i * 135, 236 - 80 - hop, 80, 80);
      });
      if (!REDUCE) raf = requestAnimationFrame(draw);
    };
    new IntersectionObserver(([e]) => { if (e.isIntersecting) { if (!raf) draw(); } else { cancelAnimationFrame(raf); raf = 0; } }).observe(dc);
  }

  // Web3 card: the pack's nations, networked
  const nc = $('#feat-net');
  if (nc) {
    const x = nc.getContext('2d');
    const N = [['Lagos', 205, 150, 1], ['Abuja', 250, 120, 1], ['Accra', 150, 165, 1], ['Kampala', 395, 150, 1], ['Dar es Salaam', 430, 205, 1], ['Addis Ababa', 455, 95, 1], ['Johannesburg', 360, 268, 1], ['Nairobi', 445, 160, 0], ['Kigali', 380, 185, 0], ['Cairo', 400, 30, 0], ['Dakar', 70, 110, 0], ['Douala', 255, 185, 0]];
    N.forEach(n => (n[2] = Math.round(n[2] * .74 + 18)));
    const L = [[1, 0], [1, 2], [1, 3], [1, 5], [1, 6], [3, 4], [3, 7], [4, 6], [5, 7], [7, 8], [8, 3], [1, 9], [2, 10], [0, 11], [11, 6]];
    let t = 0, raf = 0;
    const draw = () => {
      t += 1 / 60; x.clearRect(0, 0, 640, 300);
      x.save(); x.translate(60, 0);
      L.forEach(([a, b], i) => {
        const A = N[a], B = N[b], gold = A[3] && B[3];
        x.strokeStyle = gold ? 'rgba(244,182,63,.55)' : 'rgba(45,185,218,.3)'; x.lineWidth = 1.5;
        x.beginPath(); x.moveTo(A[1], A[2]); x.quadraticCurveTo((A[1] + B[1]) / 2, (A[2] + B[2]) / 2 - 20, B[1], B[2]); x.stroke();
        const u = (t * .35 + i * .17) % 1, mx = (A[1] + B[1]) / 2, my = (A[2] + B[2]) / 2 - 20;
        const px = (1 - u) ** 2 * A[1] + 2 * (1 - u) * u * mx + u * u * B[1], py = (1 - u) ** 2 * A[2] + 2 * (1 - u) * u * my + u * u * B[2];
        x.fillStyle = '#FFE2A3'; x.globalAlpha = Math.sin(u * Math.PI); x.beginPath(); x.arc(px, py, 2.4, 0, 7); x.fill(); x.globalAlpha = 1;
      });
      N.forEach(([name, nx, ny, bma], i) => {
        const pulse = .5 + .5 * Math.sin(t * 2 + i);
        x.fillStyle = bma ? '#F4B63F' : '#2DB9DA'; x.beginPath(); x.arc(nx, ny, bma ? 5 : 3.5, 0, 7); x.fill();
        if (bma) { x.strokeStyle = `rgba(244,182,63,${.25 + pulse * .4})`; x.lineWidth = 1.5; x.beginPath(); x.arc(nx, ny, 10 + pulse * 4, 0, 7); x.stroke(); }
        x.fillStyle = 'rgba(245,238,225,.75)'; x.font = '600 11px system-ui'; x.fillText(name, nx + 9, ny - 7);
      });
      x.restore();
      if (!REDUCE) raf = requestAnimationFrame(draw);
    };
    new IntersectionObserver(([e]) => { if (e.isIntersecting) { if (!raf) draw(); } else { cancelAnimationFrame(raf); raf = 0; } }).observe(nc);
  }

  // live pulse pills
  const h = $('[data-home-pulse="height"]'), p = $('[data-home-pulse="price"]');
  if (h) fetch('https://api.blockcypher.com/v1/doge/main').then(r => r.json()).then(d => (h.textContent = '#' + d.height.toLocaleString())).catch(() => (h.textContent = 'live'));
  if (p) fetch('https://api.coingecko.com/api/v3/simple/price?ids=dogecoin&vs_currencies=usd').then(r => r.json()).then(d => (p.textContent = '$' + d.dogecoin.usd.toFixed(4))).catch(() => (p.textContent = '—'));
})();
