/* =================================================================
   Dogs of Africa (DOA) — playable pack for "Two Paws"
   Full-body pixel characters built from the community PFPs.
   Every frame is drawn procedurally on a 40×40 pixel grid, outlined,
   then scaled up crisp, so the dogs can run, leap, squash and stretch.
   window.DOA = { roster, byId, frame(id, pose), portrait(id, size, bg) }
   ================================================================= */
(() => {
  const OUT = '#0A0814';

  const roster = [
    {
      id: 'rose', name: 'Rosé', title: 'The Heartbeat', nation: 'Ghana', flag: '🇬🇭',
      bio: 'Grey coat, rose patches, tinted shades. Keeps the pack calm and the timing perfect.',
      bg: '#FED0EC', fur: ['#3C3F3E', '#2A2C2C', '#575B59'], muzzle: '#4A4D4C', ear: '#F26A7E',
      patch: ['#F26A7E', '#FF9FAE'], eyewear: 'tint', hat: 'brim', outfit: null,
    },
    {
      id: 'jollof', name: "Cap'n Jollof", title: 'The Raider', nation: 'Nigeria', flag: '🇳🇬',
      bio: 'Skull bandana, sun goggles, black mask. First across every gap, last to leave a fight.',
      bg: '#FEE253', fur: ['#232325', '#141416', '#3A3A3D'], muzzle: '#1A1A1C', ear: '#2E2E31',
      patch: null, eyewear: 'goggles', hat: 'bandana', outfit: 'mask',
    },
    {
      id: 'prism', name: 'Prism', title: 'The Signal', nation: 'Kenya', flag: '🇰🇪',
      bio: 'Rainbow visor that reads the chain in real time. Spots every hidden path.',
      bg: '#8CFFA4', fur: ['#2C2926', '#1A1816', '#433E39'], muzzle: '#35312D', ear: '#3B3631',
      patch: null, eyewear: 'visor', hat: null, outfit: null,
    },
    {
      id: 'chairman', name: 'The Chairman', title: 'The Deal Closer', nation: 'South Africa', flag: '🇿🇦',
      bio: 'Black suit, red tie, side-eye. Never runs, only arrives.',
      bg: '#F6E39F', fur: ['#7A5F47', '#5A4431', '#A07F60'], muzzle: '#C9A77D', ear: '#4A3726',
      patch: null, eyewear: 'sideeye', hat: null, outfit: 'suit',
    },
  ];
  const byId = Object.fromEntries(roster.map(c => [c.id, c]));

  /* ---------- tiny pixel canvas ---------- */
  const G = 40;
  function grid() { return { px: new Array(G * G).fill(null) }; }
  const set = (g, x, y, c) => { x = Math.round(x); y = Math.round(y); if (x >= 0 && y >= 0 && x < G && y < G && c) g.px[y * G + x] = c; };
  const rect = (g, x, y, w, h, c) => { for (let j = 0; j < h; j++) for (let i = 0; i < w; i++) set(g, x + i, y + j, c); };
  const ellipse = (g, cx, cy, rx, ry, c, shade) => {
    for (let y = Math.floor(cy - ry); y <= Math.ceil(cy + ry); y++)
      for (let x = Math.floor(cx - rx); x <= Math.ceil(cx + rx); x++) {
        const d = ((x - cx) / rx) ** 2 + ((y - cy) / ry) ** 2;
        if (d <= 1) set(g, x, y, shade && y > cy + ry * .35 ? shade : c);
      }
  };
  const tri = (g, x0, y0, x1, y1, x2, y2, c) => {
    const minX = Math.min(x0, x1, x2), maxX = Math.max(x0, x1, x2), minY = Math.min(y0, y1, y2), maxY = Math.max(y0, y1, y2);
    const s = (ax, ay, bx, by, px, py) => (bx - ax) * (py - ay) - (by - ay) * (px - ax);
    for (let y = minY; y <= maxY; y++) for (let x = minX; x <= maxX; x++) {
      const a = s(x0, y0, x1, y1, x + .5, y + .5), b = s(x1, y1, x2, y2, x + .5, y + .5), d = s(x2, y2, x0, y0, x + .5, y + .5);
      if ((a >= 0 && b >= 0 && d >= 0) || (a <= 0 && b <= 0 && d <= 0)) set(g, x, y, c);
    }
  };
  const outline = (g, col = OUT) => {
    const add = [];
    for (let y = 0; y < G; y++) for (let x = 0; x < G; x++) {
      if (g.px[y * G + x]) continue;
      const n = [[1, 0], [-1, 0], [0, 1], [0, -1]].some(([dx, dy]) => { const X = x + dx, Y = y + dy; return X >= 0 && Y >= 0 && X < G && Y < G && g.px[Y * G + X] && (col !== OUT || g.px[Y * G + X] !== OUT); });
      if (n) add.push(y * G + x);
    }
    add.forEach(i => (g.px[i] = col));
  };
  function toCanvas(g) {
    const c = document.createElement('canvas'); c.width = c.height = G;
    const x = c.getContext('2d'), img = x.createImageData(G, G);
    g.px.forEach((col, i) => {
      if (!col) return;
      const n = parseInt(col.slice(1), 16);
      img.data.set([(n >> 16) & 255, (n >> 8) & 255, n & 255, 255], i * 4);
    });
    x.putImageData(img, 0, 0);
    return c;
  }

  /* ---------- body parts ---------- */
  function legs(g, c, pose, front) {
    const [F, S] = c.fur;
    const t = pose.t || 0, run = pose.state === 'run', air = pose.state === 'jump' || pose.state === 'fall' || pose.state === 'glide';
    const xs = front ? [24, 28] : [11, 15];
    xs.forEach((x0, k) => {
      let swing = 0, lift = 0;
      if (run) { const ph = Math.sin((t + k * .5 + (front ? .25 : 0)) * Math.PI * 2); swing = Math.round(ph * 2.4); lift = ph > .3 ? 1 : 0; }
      if (air) { swing = front ? 2 : -2; lift = 1; }
      const col = k === 0 ? S : F;                          // far leg darker
      const sleeve = front && c.outfit === 'suit';
      for (let y = 29; y < 37 - lift; y++) {
        const off = Math.round(swing * (y - 29) / 8);
        rect(g, x0 + off, y, 3, 1, sleeve && y < 33 ? (k === 0 ? '#0B0B0E' : '#1A1A20') : col);
      }
      const off = swing;
      rect(g, x0 + off, 37 - lift, 4, 2, k === 0 ? S : c.fur[2]);   // paw
      if (sleeve) rect(g, x0 + Math.round(swing * 4 / 8), 33, 3, 1, '#F2F2F2');
    });
  }

  function tail(g, c, pose) {
    const [F, S, L] = c.fur;
    const wag = Math.sin((pose.t || 0) * Math.PI * 2 * (pose.state === 'idle' ? 1 : 2)) * 2;
    const pts = [[9, 23], [7, 21], [6, 18], [6 + wag * .3, 15], [7 + wag * .6, 12], [9 + wag, 10]];
    pts.forEach(([x, y], i) => {
      const col = c.patch && i >= 4 ? (i % 2 ? c.patch[0] : c.patch[1]) : i > 3 ? L : F;
      rect(g, x - 1, y - 1, 3, 3, col);
    });
    if (c.patch) { set(g, pts[5][0], pts[5][1] - 2, c.patch[1]); set(g, pts[4][0] - 1, pts[4][1], c.patch[0]); }
    void S;
  }

  function body(g, c, pose) {
    const [F, S, L] = c.fur;
    if (c.outfit === 'suit') {
      ellipse(g, 19, 25, 11, 6, '#1A1A20', '#0B0B0E');
      rect(g, 10, 21, 18, 1, '#2A2A33');                       // shoulder highlight
      ellipse(g, 26, 22, 5, 6, '#1A1A20');                      // chest
      tri(g, 25, 17, 31, 17, 28, 25, '#F2F2F2');                // shirt V
      rect(g, 27, 18, 2, 1, '#E8233A'); rect(g, 27, 19, 3, 5, '#E8233A'); rect(g, 28, 24, 1, 1, '#B0142A'); // tie
      rect(g, 24, 18, 1, 6, '#0B0B0E'); rect(g, 31, 18, 1, 6, '#0B0B0E');                                     // lapels
      return;
    }
    ellipse(g, 19, 25, 11, 6, F, S);
    rect(g, 11, 20, 14, 1, L);                                  // back highlight
    ellipse(g, 26, 22, 5, 6, F, S);                             // chest
    if (c.outfit === 'mask') ellipse(g, 27, 22, 4, 4, '#101012');
    if (c.patch) { rect(g, 14, 22, 3, 2, c.patch[0]); rect(g, 15, 24, 2, 1, c.patch[1]); }
  }

  function head(g, c, pose) {
    const [F, S, L] = c.fur;
    const bob = pose.state === 'run' ? Math.round(Math.abs(Math.sin((pose.t || 0) * Math.PI * 2))) : 0;
    const flop = pose.state === 'fall' || pose.state === 'glide' ? -1 : pose.state === 'jump' ? 1 : 0;
    const y0 = 1 - bob;
    // ears
    if (c.id === 'chairman') {
      rect(g, 19, y0 + 3 + flop, 6, 5, c.ear); rect(g, 33, y0 + 3 + flop, 6, 5, c.ear);
      rect(g, 19, y0 + 8 + flop, 3, 2, c.ear); rect(g, 36, y0 + 8 + flop, 3, 2, c.ear);
      rect(g, 20, y0 + 4 + flop, 3, 1, '#6A5038'); rect(g, 35, y0 + 4 + flop, 3, 1, '#6A5038');
    } else {
      tri(g, 20, y0 + 9, 23, y0 - 1 + flop, 27, y0 + 7, F);
      tri(g, 29, y0 + 7, 33, y0 - 1 + flop, 36, y0 + 9, F);
      tri(g, 22, y0 + 7, 23, y0 + 2 + flop, 25, y0 + 7, c.patch ? c.patch[0] : c.ear);
      tri(g, 31, y0 + 7, 33, y0 + 2 + flop, 34, y0 + 7, c.ear);
      if (c.patch) { set(g, 23, y0 + 4 + flop, c.patch[1]); set(g, 22, y0 + 6, c.patch[1]); }
    }
    // skull
    rect(g, 21, y0 + 6, 15, 12, F);
    rect(g, 22, y0 + 5, 13, 1, F);
    rect(g, 22, y0 + 18, 13, 1, S);
    rect(g, 22, y0 + 6, 13, 1, L);
    if (c.id === 'chairman') { rect(g, 19, y0 + 3 + flop, 5, 4, c.ear); rect(g, 34, y0 + 3 + flop, 5, 4, c.ear); rect(g, 20, y0 + 4 + flop, 3, 1, '#6A5038'); rect(g, 35, y0 + 4 + flop, 3, 1, '#6A5038'); }
    // muzzle + face markings
    if (c.id === 'chairman') {
      rect(g, 24, y0 + 9, 3, 1, c.muzzle); rect(g, 31, y0 + 9, 3, 1, c.muzzle);     // brow spots
      rect(g, 24, y0 + 13, 10, 5, c.muzzle); rect(g, 25, y0 + 18, 8, 1, c.muzzle);
    } else {
      rect(g, 24, y0 + 14, 10, 4, c.muzzle); rect(g, 25, y0 + 18, 8, 1, c.outfit === 'mask' ? '#101012' : c.muzzle);
    }
    if (c.outfit === 'mask') { rect(g, 22, y0 + 14, 13, 5, '#101012'); rect(g, 23, y0 + 14, 11, 1, '#26262A'); }
    // nose + mouth
    rect(g, 28, y0 + 14, 2, 1, '#0A0814'); set(g, 29, y0 + 16, '#2A1A1A');
    if (c.patch) { rect(g, 21, y0 + 11, 2, 3, c.patch[0]); set(g, 21, y0 + 12, c.patch[1]); }

    // eyewear
    const ey = y0 + 10;
    if (c.eyewear === 'tint') {
      rect(g, 22, ey, 14, 1, '#583E41');
      rect(g, 23, ey + 1, 5, 3, '#9A586A'); rect(g, 30, ey + 1, 5, 3, '#9A586A');
      rect(g, 24, ey + 2, 2, 1, '#F7C9D6'); rect(g, 31, ey + 2, 2, 1, '#F7C9D6');
      rect(g, 28, ey + 1, 2, 1, '#583E41');
    } else if (c.eyewear === 'goggles') {
      rect(g, 20, ey, 2, 3, '#5A5F66');
      rect(g, 22, ey, 15, 4, '#E8E8E0');
      rect(g, 23, ey + 1, 6, 2, '#FFE250'); rect(g, 30, ey + 1, 6, 2, '#FFE250');
      rect(g, 24, ey + 1, 2, 1, '#FEF3A7'); rect(g, 31, ey + 1, 2, 1, '#FEF3A7');
    } else if (c.eyewear === 'visor') {
      rect(g, 20, ey, 2, 3, '#5A5F66');
      rect(g, 22, ey - 1, 15, 5, '#DFE6EA');
      const rb = ['#19C3FF', '#2F6BFF', '#8A3BFF', '#FF2FD0', '#FF2F2F', '#FF8A1F', '#FFD21F'];
      rb.forEach((col, i) => { rect(g, 23 + i * 2, ey, 2, 2, col); rect(g, 23 + i * 2, ey + 2, 2, 1, rb[(i + 2) % rb.length]); });
    } else if (c.eyewear === 'sideeye') {
      rect(g, 24, ey, 4, 3, '#F2EEE6'); rect(g, 30, ey, 4, 3, '#F2EEE6');
      rect(g, 26, ey + 1, 2, 2, '#0A0814'); rect(g, 32, ey + 1, 2, 2, '#0A0814');
      rect(g, 24, ey - 1, 4, 1, S); rect(g, 30, ey - 1, 4, 1, S);              // heavy lids
    }
    // headwear
    if (c.hat === 'brim') {
      rect(g, 19, y0 + 6, 19, 2, '#151515'); rect(g, 20, y0 + 6, 17, 1, '#2A2A2A');
    } else if (c.hat === 'bandana') {
      rect(g, 21, y0 + 1, 15, 8, '#151517'); rect(g, 23, y0, 11, 1, '#151517'); rect(g, 22, y0 + 1, 13, 1, '#2A2A2E');
      rect(g, 29, y0 + 2, 4, 2, '#F4F4F4'); set(g, 30, y0 + 3, '#151517'); rect(g, 30, y0 + 4, 2, 1, '#F4F4F4'); // skull
      set(g, 28, y0 + 5, '#F4F4F4'); set(g, 33, y0 + 5, '#F4F4F4');
      const kw = Math.round(Math.sin((pose.t || 0) * Math.PI * 4));                                           // knot tails flutter
      rect(g, 18, y0 + 5 + kw, 3, 2, '#151517'); rect(g, 16, y0 + 4 - kw, 2, 2, '#151517');
    }
  }

  /* ---------- extra props by game role ---------- */
  function props(g, pose) {
    if (pose.drum) {                                            // P1: talking drum on the back
      rect(g, 13, 15, 6, 5, '#C8642E'); rect(g, 13, 15, 6, 1, '#F1D3AA'); rect(g, 13, 19, 6, 1, '#F1D3AA');
      set(g, 15, 17, '#6E3F22'); set(g, 17, 17, '#6E3F22');
    }
    if (pose.cape) {                                            // P2: sky cape in kente
      const flap = pose.state === 'glide' ? 4 : pose.state === 'fall' ? 2 : 0;
      const cols = ['#F4B63F', '#13A881', '#D2643F', '#2DB9DA'];
      for (let i = 0; i < 9; i++) rect(g, 10 + i * 1.5, 18 - flap + Math.round(Math.sin(i * .8 + (pose.t || 0) * 6) * (flap ? 1 : 0)) - (i < 3 ? 0 : 1), 2, 3 + Math.round(flap / 2), cols[i % 4]);
    }
  }

  /* ---------- public: frame / portrait ---------- */
  const cache = new Map();
  function frame(id, pose = {}) {
    const c = byId[id] || roster[0];
    const st = pose.state || 'idle';
    const step = st === 'run' ? Math.floor(((pose.t || 0) % 1) * 8) / 8 : st === 'idle' ? Math.floor(((pose.t || 0) % 1) * 4) / 4 : Math.floor(((pose.t || 0) % 1) * 4) / 4;
    const key = `${id}|${st}|${step}|${pose.drum ? 1 : 0}|${pose.cape ? 1 : 0}|${pose.rim || ''}`;
    if (cache.has(key)) return cache.get(key);
    const p = { ...pose, t: step };
    const g = grid();
    legs(g, c, p, false);
    tail(g, c, p);
    props(g, { ...p, drum: false, cape: p.cape });
    body(g, c, p);
    legs(g, c, p, true);
    head(g, c, p);
    if (p.drum) props(g, { ...p, cape: false });
    outline(g);
    if (p.rim) outline(g, p.rim);                                // sticker rim so dark coats pop on the night sky
    const cv = toCanvas(g);
    cache.set(key, cv);
    return cv;
  }

  /** HD portrait card art: big crisp sprite on the PFP colour, with a soft halo. */
  function portrait(id, size = 240, opts = {}) {
    const c = byId[id] || roster[0];
    const cv = document.createElement('canvas'); cv.width = cv.height = size;
    const x = cv.getContext('2d');
    x.fillStyle = opts.bg || c.bg; x.fillRect(0, 0, size, size);
    const halo = x.createRadialGradient(size * .5, size * .45, 0, size * .5, size * .45, size * .6);
    halo.addColorStop(0, 'rgba(255,255,255,.45)'); halo.addColorStop(1, 'rgba(255,255,255,0)');
    x.fillStyle = halo; x.fillRect(0, 0, size, size);
    x.fillStyle = 'rgba(0,0,0,.18)'; x.beginPath(); x.ellipse(size * .5, size * .9, size * .32, size * .05, 0, 0, 7); x.fill();
    x.imageSmoothingEnabled = false;
    const s = Math.floor(size * .95 / G);
    const spr = frame(id, { state: 'idle', t: 0, ...(opts.pose || {}) });
    x.drawImage(spr, Math.round((size - G * s) / 2), Math.round(size * .92 - G * s), G * s, G * s);
    return cv;
  }

  window.DOA = { roster, byId, frame, portrait, GRID: G };
})();
