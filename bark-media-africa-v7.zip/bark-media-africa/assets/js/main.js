(() => {
  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => [...r.querySelectorAll(s)];
  const reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;
  const root = document.documentElement;

  requestAnimationFrame(() => root.classList.add('ready'));

  /* ---- Mobile menu ---- */
  const btn = $('#menu-btn'), nav = $('#main-nav');
  if (btn && nav) {
    const set = open => { btn.setAttribute('aria-expanded', open); nav.classList.toggle('open', open); };
    btn.addEventListener('click', () => set(btn.getAttribute('aria-expanded') !== 'true'));
    document.addEventListener('keydown', e => { if (e.key === 'Escape') set(false); });
    nav.addEventListener('click', e => { if (e.target.closest('a')) set(false); });
  }

  /* ---- Rotating greeting ---- */
  const g = $('#greeting');
  if (g && !reduce) {
    const list = JSON.parse(g.dataset.greetings || '[]');
    const w = $('.g-word', g), l = $('.g-lang', g);
    let i = list.length - 1;
    setInterval(() => {
      g.classList.add('swap');
      setTimeout(() => {
        i = (i + 1) % list.length;
        w.textContent = list[i][0]; l.textContent = list[i][1];
        g.classList.remove('swap');
      }, 350);
    }, 2600);
  }

  /* ---- 3D tilt cards (pointer only) ---- */
  if (!reduce && matchMedia('(hover: hover)').matches) {
    $$('[data-tilt]').forEach(card => {
      const inner = $('.tilt-inner', card);
      card.addEventListener('pointermove', e => {
        const r = card.getBoundingClientRect();
        const x = (e.clientX - r.left) / r.width, y = (e.clientY - r.top) / r.height;
        inner.style.setProperty('--ry', `${(x - .5) * 14}deg`);
        inner.style.setProperty('--rx', `${(.5 - y) * 12}deg`);
        inner.style.setProperty('--mx', `${x * 100}%`);
        inner.style.setProperty('--my', `${y * 100}%`);
      });
      card.addEventListener('pointerleave', () => {
        inner.style.setProperty('--rx', '0deg'); inner.style.setProperty('--ry', '0deg');
      });
    });
  }

  /* ---- Nation bars animate when visible ---- */
  const nl = $('.nation-list');
  if (nl) {
    const io = new IntersectionObserver(es => es.forEach(en => {
      if (en.isIntersecting) { nl.classList.add('in-view'); io.disconnect(); }
    }), { threshold: .3 });
    io.observe(nl);
  }

  /* ---- Events filter ---- */
  const chips = $$('.chip');
  chips.forEach(chip => chip.addEventListener('click', () => {
    chips.forEach(c => c.setAttribute('aria-pressed', c === chip));
    const f = chip.dataset.filter;
    let shown = 0;
    $$('#timeline li').forEach(li => {
      const ok = f === 'All' || li.dataset.type === f;
      li.hidden = !ok; if (ok) shown++;
    });
    const empty = $('#events-empty'); if (empty) empty.hidden = shown > 0;
  }));

  /* ---- AJAX forms (join + newsletter) ---- */
  const csrf = $('meta[name="csrf"]')?.content || '';
  const validEmail = v => /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(v);

  $$('form[data-api]').forEach(form => {
    form.addEventListener('submit', async e => {
      e.preventDefault();
      const msg = $('.form-msg', form);
      const submit = $('button[type="submit"]', form);
      const email = $('input[type="email"]', form);
      const say = (text, ok) => { msg.textContent = text; msg.className = msg.className.replace(/\b(ok|err)\b/g, '').trim() + (ok ? ' ok' : ' err'); };

      $$('[aria-invalid]', form).forEach(el => el.removeAttribute('aria-invalid'));
      const first = $('#fn', form);
      if (first && !first.value.trim()) { first.setAttribute('aria-invalid', 'true'); first.focus(); return say('Enter your first name.', false); }
      if (!validEmail(email.value.trim())) { email.setAttribute('aria-invalid', 'true'); email.focus(); return say('Enter a valid email address, like name@email.com.', false); }

      const label = submit.textContent;
      submit.disabled = true; submit.textContent = form.id === 'join-form' ? 'Sending…' : 'Subscribing…';
      const fd = new FormData(form);
      if (!fd.get('csrf')) fd.set('csrf', csrf);

      try {
        const res = await fetch(form.dataset.api, { method: 'POST', body: fd, headers: { 'X-Requested-With': 'fetch' }, credentials: 'same-origin' });
        const data = await res.json();
        say(data.message, data.ok);
        if (data.ok) {
          form.reset();
          if (form.id === 'join-form') { submit.textContent = 'Application sent'; return; }
        }
      } catch {
        say('Could not reach the server. Check your connection and try again.', false);
      }
      submit.disabled = false; submit.textContent = label;
    });
  });
})();

/* ---------- v2: scroll animations, counters, ticker ---------- */
(() => {
  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => [...r.querySelectorAll(s)];
  const reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;

  /* Reveal on scroll */
  const rev = $$('[data-reveal]');
  if (reduce || !('IntersectionObserver' in window)) rev.forEach(el => el.classList.add('revealed'));
  else {
    const io = new IntersectionObserver(es => es.forEach(e => {
      if (e.isIntersecting) { e.target.classList.add('revealed'); io.unobserve(e.target); }
    }), { threshold: .15, rootMargin: '0px 0px -40px 0px' });
    rev.forEach(el => io.observe(el));
  }

  /* Count-up stats ("250+" → counts to 250, keeps the "+") */
  $$('[data-count]').forEach(el => {
    const m = el.dataset.count.match(/^(\D*)([\d,]+)(.*)$/);
    if (!m || reduce) return;
    const end = parseInt(m[2].replace(/,/g, ''), 10);
    el.textContent = m[1] + '0' + m[3];
    const start = performance.now() + 600, dur = 1600;
    const tick = now => {
      const t = Math.min(Math.max((now - start) / dur, 0), 1);
      el.textContent = m[1] + Math.round(end * (1 - Math.pow(1 - t, 3))).toLocaleString() + m[3];
      if (t < 1) requestAnimationFrame(tick);
    };
    requestAnimationFrame(tick);
  });

  /* Scroll-linked: gallery parallax + steps line drawing */
  const par = $$('[data-parallax]'), steps = $('#steps');
  if (!reduce && (par.length || steps)) {
    let ticking = false;
    const update = () => {
      const vh = innerHeight;
      par.forEach(img => {
        const r = img.parentElement.getBoundingClientRect();
        if (r.bottom < 0 || r.top > vh) return;
        const p = (r.top + r.height / 2 - vh / 2) / vh;
        img.style.transform = `translateY(${p * parseFloat(img.dataset.parallax) * 100}%)`;
      });
      if (steps) {
        const r = steps.getBoundingClientRect();
        const p = Math.min(Math.max((vh * .85 - r.top) / (r.height + vh * .3), 0), 1);
        steps.style.setProperty('--draw', 1 - p);
      }
      ticking = false;
    };
    addEventListener('scroll', () => { if (!ticking) { ticking = true; requestAnimationFrame(update); } }, { passive: true });
    update();
  }

  /* Product image tilt */
  const media = $('[data-tilt-media]');
  if (media && !reduce && matchMedia('(hover: hover)').matches) {
    const stage = $('.pd-stage', media);
    media.addEventListener('pointermove', e => {
      const r = media.getBoundingClientRect();
      stage.style.setProperty('--ry', `${((e.clientX - r.left) / r.width - .5) * 12}deg`);
      stage.style.setProperty('--rx', `${(.5 - (e.clientY - r.top) / r.height) * 10}deg`);
    });
    media.addEventListener('pointerleave', () => { stage.style.setProperty('--rx', '0deg'); stage.style.setProperty('--ry', '0deg'); });
  }

  /* Live crypto ticker (CoinGecko public API); keeps community lines if it fails */
  const track = $('#ticker-track');
  if (track) {
    const base = track.innerHTML;
    const fill = extra => { track.innerHTML = extra + base; track.innerHTML += track.innerHTML; };
    fill('');
    fetch('https://api.coingecko.com/api/v3/simple/price?ids=dogecoin,bitcoin,ethereum,solana&vs_currencies=usd&include_24hr_change=true')
      .then(r => (r.ok ? r.json() : Promise.reject()))
      .then(d => {
        const names = { dogecoin: 'DOGE', bitcoin: 'BTC', ethereum: 'ETH', solana: 'SOL' };
        const html = Object.entries(names).filter(([id]) => d[id]).map(([id, sym]) => {
          const p = d[id].usd, ch = d[id].usd_24h_change || 0;
          const price = p < 1 ? p.toFixed(4) : p.toLocaleString(undefined, { maximumFractionDigits: 2 });
          return `<span class="tk"><b>${sym}</b> $${price} <span class="${ch >= 0 ? 'up' : 'down'}">${ch >= 0 ? '▲' : '▼'} ${Math.abs(ch).toFixed(1)}%</span></span>`;
        }).join('');
        if (html) fill(html);
      })
      .catch(() => {});
  }
})();
