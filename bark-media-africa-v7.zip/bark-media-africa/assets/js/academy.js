/* Web3 Academy: module notes in a sheet, progress, glossary search, comparison tabs, quiz, checklist */
(() => {
  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => [...r.querySelectorAll(s)];
  const store = { get(k, d) { try { const v = localStorage.getItem(k); return v ? JSON.parse(v) : d; } catch { return d; } }, set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch {} } };
  const TOTAL = $$('.ac-card').length;

  /* ---------- progress ---------- */
  let done = new Set(store.get('ac-done', []));
  function paintProgress() {
    $$('.ac-card').forEach(c => c.classList.toggle('is-done', done.has(Number(c.dataset.module))));
    const n = done.size;
    $$('[data-progress-text]').forEach(el => (el.textContent = `${n}/${TOTAL}`));
    $$('[data-progress-bar]').forEach(el => (el.style.width = (n / TOTAL * 100) + '%'));
  }

  /* ---------- module sheet ---------- */
  const dlg = $('#ac-dialog'), body = $('#ac-dialog-body');
  document.documentElement.classList.add('ac-js');
  let cur = 1;
  function open(n) {
    cur = Math.max(1, Math.min(TOTAL, n));
    const note = $(`[data-note="${cur}"]`);
    body.innerHTML = note.innerHTML;
    $('h3', body).id = 'ac-dialog-title';
    const mark = $('[data-mark]', dlg);
    mark.textContent = done.has(cur) ? 'Done ✓ (undo)' : 'Mark as done';
    mark.classList.toggle('is-done', done.has(cur));
    $('.ac-prev', dlg).disabled = cur === 1;
    $('.ac-next', dlg).disabled = cur === TOTAL;
    if (!dlg.open) { dlg.showModal ? dlg.showModal() : dlg.setAttribute('open', ''); document.documentElement.classList.add('no-scroll'); }
    dlg.querySelector('.ac-dialog-inner').scrollTop = 0;
    try { history.replaceState(null, '', '#module-' + cur); } catch {}
  }
  function close() { dlg.close ? dlg.close() : dlg.removeAttribute('open'); }
  dlg.addEventListener('close', () => { document.documentElement.classList.remove('no-scroll'); try { history.replaceState(null, '', location.pathname + '#modules'); } catch {} });
  $$('.ac-card').forEach(c => c.addEventListener('click', () => open(Number(c.dataset.module))));
  $$('[data-close]', dlg).forEach(b => b.addEventListener('click', close));
  dlg.addEventListener('click', e => { if (e.target === dlg) close(); });
  $$('[data-step]', dlg).forEach(b => b.addEventListener('click', () => open(cur + Number(b.dataset.step))));
  $('[data-mark]', dlg).addEventListener('click', () => {
    done.has(cur) ? done.delete(cur) : done.add(cur);
    store.set('ac-done', [...done]); paintProgress();
    if (done.has(cur) && cur < TOTAL) open(cur + 1); else open(cur);
  });
  // swipe between modules on phones
  let sx = null;
  dlg.addEventListener('touchstart', e => { sx = e.touches[0].clientX; }, { passive: true });
  dlg.addEventListener('touchend', e => { if (sx === null) return; const dx = e.changedTouches[0].clientX - sx; if (Math.abs(dx) > 70) open(cur + (dx < 0 ? 1 : -1)); sx = null; });
  const m = location.hash.match(/^#module-(\d+)/); if (m) setTimeout(() => open(Number(m[1])), 300);
  paintProgress();

  /* ---------- glossary ---------- */
  const gs = $('#ac-gsearch');
  gs && gs.addEventListener('input', () => {
    const q = gs.value.trim().toLowerCase(); let shown = 0;
    $$('.ac-term').forEach(t => { const ok = !q || t.textContent.toLowerCase().includes(q); t.hidden = !ok; if (ok) shown++; });
    $('#ac-gempty').hidden = shown > 0;
  });

  /* ---------- comparison tabs ---------- */
  const tabs = $$('.ac-tabs [role="tab"]');
  tabs.forEach(t => t.addEventListener('click', () => {
    tabs.forEach(x => { x.setAttribute('aria-selected', String(x === t)); $('#' + x.getAttribute('aria-controls')).hidden = x !== t; });
  }));

  /* ---------- quiz ---------- */
  const quiz = $('#ac-quiz');
  if (quiz) {
    const qs = $$('.ac-q', quiz), next = $('[data-next]', quiz), dots = $$('.ac-dots i', quiz), result = $('.ac-result', quiz);
    let i = 0, score = 0, answered = false;
    const show = k => { qs.forEach((q, j) => (q.hidden = j !== k)); dots.forEach((d, j) => d.classList.toggle('cur', j === k)); answered = false; next.disabled = true; next.textContent = k === qs.length - 1 ? 'See my score' : 'Next question'; };
    qs.forEach((q, k) => $$('.ac-opt', q).forEach(b => b.addEventListener('click', () => {
      if (answered) return; answered = true;
      const right = Number(q.dataset.ans), pick = Number(b.dataset.opt);
      $$('.ac-opt', q).forEach(o => { const n = Number(o.dataset.opt); o.classList.toggle('right', n === right); o.disabled = true; });
      if (pick !== right) b.classList.add('wrong'); else score++;
      dots[k].classList.add(pick === right ? 'ok' : 'no');
      $('.ac-why', q).hidden = false; next.disabled = false;
    })));
    next.addEventListener('click', () => {
      if (i < qs.length - 1) { i++; show(i); return; }
      qs.forEach(q => (q.hidden = true)); $('.ac-quiz-foot', quiz).hidden = true; result.hidden = false;
      $('[data-score]', result).textContent = score;
      const pct = score / qs.length;
      $('[data-verdict]', result).textContent = pct >= .7 ? 'Great work: that clears the 70% graduation mark.' : 'Good start. Revisit the modules you missed and try again.';
      const best = store.get('ac-quiz-best', 0); if (score > best) store.set('ac-quiz-best', score);
    });
    $('[data-retry]', result).addEventListener('click', () => {
      i = 0; score = 0; result.hidden = true; $('.ac-quiz-foot', quiz).hidden = false;
      dots.forEach(d => d.classList.remove('ok', 'no'));
      qs.forEach(q => { $('.ac-why', q).hidden = true; $$('.ac-opt', q).forEach(o => { o.disabled = false; o.classList.remove('right', 'wrong'); }); });
      show(0);
    });
    show(0);
  }

  /* ---------- checklist ---------- */
  const checked = new Set(store.get('ac-check', []));
  $$('[data-check]').forEach(c => {
    c.checked = checked.has(Number(c.dataset.check));
    c.addEventListener('change', () => { c.checked ? checked.add(Number(c.dataset.check)) : checked.delete(Number(c.dataset.check)); store.set('ac-check', [...checked]); });
  });

  /* ---------- highlight the section you're reading ---------- */
  const links = $$('.ac-jump-links a');
  const io = new IntersectionObserver(es => es.forEach(e => {
    if (!e.isIntersecting) return;
    links.forEach(a => {
      const on = a.getAttribute('href') === '#' + e.target.id; a.classList.toggle('on', on);
      if (on && a.parentElement.scrollWidth > a.parentElement.clientWidth) a.parentElement.scrollTo({ left: a.offsetLeft - 20, behavior: 'smooth' });
    });
  }), { rootMargin: '-45% 0px -50% 0px' });
  links.forEach(a => { const t = document.querySelector(a.getAttribute('href')); t && io.observe(t); });
})();
