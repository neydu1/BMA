/* =================================================================
   BMA Afro-Cosmos
   • #cosmos  — fixed night sky on every page: nebula in kente colours,
                three parallax star layers, shooting stars, a kente-ringed
                planet and a constellation of African capitals networked
                together (data "packets" travel the links)
   • kente-shutter page transitions between pages
   • smooth wheel scrolling (mouse only; touch stays native)
   • scroll progress line in the header, cursor glow, auto reveals
   ================================================================= */
(() => {
  const root = document.documentElement;
  const REDUCE = matchMedia('(prefers-reduced-motion: reduce)').matches;
  const FINE = matchMedia('(pointer: fine)').matches;

  /* ---------------- Header dropdowns ---------------- */
  const items = [...document.querySelectorAll('.nav-item.has-drop')];
  const closeAll = except => items.forEach(it => { if (it !== except) { it.classList.remove('open'); it.querySelector('.nav-top')?.setAttribute('aria-expanded', 'false'); } });
  items.forEach(it => {
    const btn = it.querySelector('.nav-top');
    btn.addEventListener('click', e => {
      e.stopPropagation();
      const open = !it.classList.contains('open');
      closeAll(it); it.classList.toggle('open', open); btn.setAttribute('aria-expanded', String(open));
    });
    it.addEventListener('keydown', e => { if (e.key === 'Escape') { closeAll(); btn.focus(); } });
    it.addEventListener('focusout', e => { if (!it.contains(e.relatedTarget) && innerWidth > 960) { it.classList.remove('open'); btn.setAttribute('aria-expanded', 'false'); } });
  });
  document.addEventListener('click', e => { if (!e.target.closest('.nav-item, #menu-btn')) closeAll(); });
  // open the current section's accordion when the phone menu opens
  document.getElementById('menu-btn')?.addEventListener('click', () => { const cur = document.querySelector('.nav-item.is-current.has-drop'); if (cur && innerWidth <= 960) { cur.classList.add('open'); cur.querySelector('.nav-top').setAttribute('aria-expanded', 'true'); } });

  // lock page scroll while the phone menu is open
  const mbtn = document.getElementById('menu-btn');
  if (mbtn) new MutationObserver(() => root.classList.toggle('nav-open', mbtn.getAttribute('aria-expanded') === 'true')).observe(mbtn, { attributes: true, attributeFilter: ['aria-expanded'] });
  addEventListener('resize', () => { if (innerWidth > 960 && mbtn && mbtn.getAttribute('aria-expanded') === 'true') mbtn.click(); });

  // keep any open dropdown inside the screen
  const keepOnScreen = it => {
    const d = it.querySelector('.nav-drop'); if (!d || innerWidth <= 960) return;
    d.style.marginLeft = '0px';
    const r = d.getBoundingClientRect();
    if (r.right > innerWidth - 8) d.style.marginLeft = (innerWidth - 8 - r.right) + 'px';
    else if (r.left < 8) d.style.marginLeft = (8 - r.left) + 'px';
  };
  items.forEach(it => { it.addEventListener('mouseenter', () => keepOnScreen(it)); it.querySelector('.nav-top').addEventListener('click', () => keepOnScreen(it)); });

  /* back to top */
  const top = document.createElement('a'); top.href = '#top'; top.className = 'to-top'; top.setAttribute('aria-label', 'Back to top'); top.textContent = '↑';
  document.body.appendChild(top);
  addEventListener('scroll', () => top.classList.toggle('show', scrollY > innerHeight * 1.2), { passive: true });

  /* ---------------- Smooth wheel scroll ---------------- */
  if (FINE && !REDUCE) {
    let target = scrollY, current = scrollY, raf = 0, ours = false;
    const max = () => document.documentElement.scrollHeight - innerHeight;
    const step = () => {
      current += (target - current) * 0.12;
      if (Math.abs(target - current) < 0.5) current = target;
      ours = true; scrollTo(0, current);
      raf = current !== target ? requestAnimationFrame(step) : 0;
    };
    const scrollable = el => {
      for (; el && el !== document.body; el = el.parentElement) {
        const s = getComputedStyle(el);
        if (/(auto|scroll)/.test(s.overflowY) && el.scrollHeight > el.clientHeight) return true;
        if (el.dataset && el.dataset.nativeScroll !== undefined) return true;
      }
      return false;
    };
    addEventListener('wheel', e => {
      if (e.ctrlKey || scrollable(e.target) || e.target.closest('.nav-drop, .main-nav.open') || root.classList.contains('no-scroll') || document.body.classList.contains('no-scroll') || root.classList.contains('sn-lock')) return;
      e.preventDefault();
      const d = e.deltaMode === 1 ? e.deltaY * 16 : e.deltaMode === 2 ? e.deltaY * innerHeight : e.deltaY;
      if (!raf) current = scrollY;
      target = Math.max(0, Math.min(max(), target + d));
      if (!raf) raf = requestAnimationFrame(step);
    }, { passive: false });
    addEventListener('scroll', () => { if (ours) { ours = false; return; } if (!raf) target = current = scrollY; }, { passive: true });
    window.BMA_scrollTo = y => { current = scrollY; target = Math.max(0, Math.min(max(), y)); if (!raf) raf = requestAnimationFrame(step); };
  }
  // in-page anchors glide too
  document.addEventListener('click', e => {
    const a = e.target.closest('a[href^="#"]');
    if (!a || a.getAttribute('href').length < 2) return;
    const el = document.querySelector(a.getAttribute('href'));
    if (!el) return;
    e.preventDefault();
    const y = el.getBoundingClientRect().top + scrollY - 80;
    window.BMA_scrollTo ? window.BMA_scrollTo(y) : scrollTo({ top: y, behavior: REDUCE ? 'auto' : 'smooth' });
  });

  /* ---------------- Progress + cursor glow ---------------- */
  const header = document.querySelector('.site-header');
  const prog = () => { const m = document.documentElement.scrollHeight - innerHeight; header && header.style.setProperty('--progress', m > 0 ? (scrollY / m).toFixed(4) : 0); };
  addEventListener('scroll', prog, { passive: true }); prog();
  if (FINE && !REDUCE) {
    const glow = document.createElement('div'); glow.className = 'cursor-glow'; document.body.appendChild(glow);
    addEventListener('pointermove', e => { glow.style.setProperty('--cx', e.clientX + 'px'); glow.style.setProperty('--cy', e.clientY + 'px'); }, { passive: true });
  }

  /* ---------------- Auto reveal common blocks ---------------- */
  document.querySelectorAll('.section-head, .grid > *, .feature, .nw-card, .milestones li, .timeline li, .faq, .w3-card, .doa-card')
    .forEach((el, i) => { if (!el.hasAttribute('data-reveal') && !el.closest('[data-reveal]')) { el.setAttribute('data-reveal', ''); el.style.setProperty('--d', (i % 4) * 90 + 'ms'); } });

  /* ---------------- The sky ---------------- */
  const canvas = document.getElementById('cosmos');
  if (!canvas || !canvas.getContext) return;
  const ctx = canvas.getContext('2d');
  const DPR = Math.min(devicePixelRatio || 1, FINE ? 1.5 : 1.25);
  let W = 0, H = 0, docH = 1;

  // African capitals [lng, lat, name, bmaMembers?]
  const CITIES = [
    [7.49, 9.06, 'Abuja', 1], [3.38, 6.52, 'Lagos', 1], [-0.19, 5.6, 'Accra', 1], [-17.45, 14.69, 'Dakar'], [-4.03, 5.36, 'Abidjan'],
    [-8, 12.65, 'Bamako'], [31.24, 30.04, 'Cairo'], [-6.84, 34.02, 'Rabat'], [3.06, 36.75, 'Algiers'], [10.18, 36.8, 'Tunis'],
    [13.19, 32.89, 'Tripoli'], [32.53, 15.5, 'Khartoum'], [38.74, 9.03, 'Addis Ababa', 1], [36.82, -1.29, 'Nairobi'], [32.58, 0.35, 'Kampala', 1],
    [30.06, -1.95, 'Kigali'], [39.21, -6.79, 'Dar es Salaam', 1], [15.27, -4.44, 'Kinshasa'], [13.23, -8.84, 'Luanda'], [28.28, -15.41, 'Lusaka'],
    [31.05, -17.83, 'Harare'], [28.05, -26.2, 'Johannesburg', 1], [18.42, -33.92, 'Cape Town', 1], [9.7, 4.05, 'Douala'], [47.52, -18.88, 'Antananarivo'],
    [32.57, -25.97, 'Maputo'], [17.08, -22.56, 'Windhoek'], [45.32, 2.05, 'Mogadishu'], [2.11, 13.51, 'Niamey'], [15.04, 12.13, "N'Djamena"],
  ];
  const AFRICA = [[-17.5,14.7],[-16.5,19.5],[-17,21],[-13,27.5],[-9.8,29.5],[-6,35.8],[0,35.9],[10,37.2],[11,33],[20,30.5],[25,31.7],[32.3,31.3],[34,27.8],[35,24],[38.5,18],[43.3,12.6],[51.2,11.8],[49,6],[47,4],[42,-1],[39.5,-6],[40.5,-10.5],[40.5,-15],[35.5,-22],[32.9,-26],[31,-29.8],[27.5,-33.5],[20,-34.8],[18.4,-34],[17.2,-29],[14.5,-22.5],[11.8,-17],[13.5,-11],[12.2,-6],[9.5,-1],[9.6,3.8],[6,4.3],[2.5,6.3],[-2,4.8],[-7.5,4.4],[-11.5,6.9],[-13.3,9],[-15,11],[-16.8,12.5]];

  // links: each city to its 2 nearest + everything BMA to the Abuja hub
  const d2 = (a, b) => (a[0] - b[0]) ** 2 + (a[1] - b[1]) ** 2;
  const LINKS = [];
  const seen = new Set();
  const addLink = (i, j) => { const k = i < j ? i + '-' + j : j + '-' + i; if (i !== j && !seen.has(k)) { seen.add(k); LINKS.push([i, j]); } };
  CITIES.forEach((c, i) => CITIES.map((o, j) => [j, d2(c, o)]).sort((a, b) => a[1] - b[1]).slice(1, 3).forEach(([j]) => addLink(i, j)));
  CITIES.forEach((c, i) => { if (c[3]) addLink(0, i); });

  let stars = [], packets = [], shooting = [], nebula = null, planet = null, moon = null;
  const rand = (a, b) => a + Math.random() * (b - a);

  function makeNebula() {
    const c = document.createElement('canvas'); c.width = Math.ceil(W / 2); c.height = Math.ceil(H / 2);
    const x = c.getContext('2d');
    const blobs = [
      [.82, .18, .55, 'rgba(58,51,160,.55)'], [.15, .65, .45, 'rgba(210,100,63,.28)'], [.65, .85, .4, 'rgba(19,168,129,.22)'],
      [.35, .2, .3, 'rgba(226,85,126,.16)'], [.95, .6, .35, 'rgba(45,185,218,.16)'], [.5, .5, .25, 'rgba(244,182,63,.08)'],
    ];
    blobs.forEach(([bx, by, r, col]) => {
      const g = x.createRadialGradient(bx * c.width, by * c.height, 0, bx * c.width, by * c.height, r * Math.max(c.width, c.height));
      g.addColorStop(0, col); g.addColorStop(1, 'rgba(0,0,0,0)');
      x.fillStyle = g; x.fillRect(0, 0, c.width, c.height);
    });
    return c;
  }

  // Planet with Ndebele-style banding and a kente ring, pre-rendered once
  function makePlanet(R) {
    const S = R * 3.4, c = document.createElement('canvas'); c.width = c.height = Math.ceil(S);
    const x = c.getContext('2d'), m = S / 2;
    const ring = (front) => {
      x.save(); x.translate(m, m); x.rotate(-.35); x.scale(1, .28);
      const cols = ['#F4B63F', '#0D0A2E', '#13A881', '#F4B63F', '#D2643F', '#0D0A2E', '#2DB9DA'];
      for (let k = 0; k < 7; k++) {
        x.beginPath(); x.lineWidth = R * .07; x.strokeStyle = cols[k]; x.globalAlpha = .85;
        x.arc(0, 0, R * (1.35 + k * .075), front ? 0 : Math.PI, front ? Math.PI : Math.PI * 2); x.stroke();
      }
      x.restore(); x.globalAlpha = 1;
    };
    ring(false);
    x.save(); x.beginPath(); x.arc(m, m, R, 0, Math.PI * 2); x.clip();
    const g = x.createLinearGradient(m - R, m - R, m + R, m + R);
    g.addColorStop(0, '#E59A2F'); g.addColorStop(.5, '#D2643F'); g.addColorStop(1, '#4A2914');
    x.fillStyle = g; x.fillRect(m - R, m - R, R * 2, R * 2);
    // Ndebele bands: stripes of triangles and steps
    const band = (y, h, col, alt) => {
      x.fillStyle = col; x.fillRect(m - R, y, R * 2, h);
      x.fillStyle = alt;
      for (let px = m - R; px < m + R; px += h * 1.2) { x.beginPath(); x.moveTo(px, y + h); x.lineTo(px + h * .6, y); x.lineTo(px + h * 1.2, y + h); x.fill(); }
    };
    band(m - R * .55, R * .14, '#0D0A2E', '#F4B63F');
    band(m - R * .05, R * .1, '#F1D3AA', '#2DB9DA');
    band(m + R * .35, R * .16, '#13A881', '#0D0A2E');
    x.fillStyle = 'rgba(241,211,170,.5)';
    for (let i = 0; i < 40; i++) { x.beginPath(); x.arc(m - R + Math.random() * R * 2, m - R * .3 + Math.random() * R * .25, R * .015, 0, 7); x.fill(); }
    // night side shading
    const sh = x.createRadialGradient(m - R * .45, m - R * .45, R * .2, m, m, R * 1.1);
    sh.addColorStop(0, 'rgba(255,240,200,.25)'); sh.addColorStop(.55, 'rgba(0,0,0,0)'); sh.addColorStop(1, 'rgba(5,4,20,.85)');
    x.fillStyle = sh; x.fillRect(m - R, m - R, R * 2, R * 2);
    x.restore();
    // atmosphere
    const at = x.createRadialGradient(m, m, R * .95, m, m, R * 1.18);
    at.addColorStop(0, 'rgba(244,182,63,.35)'); at.addColorStop(1, 'rgba(244,182,63,0)');
    x.fillStyle = at; x.beginPath(); x.arc(m, m, R * 1.18, 0, 7); x.fill();
    ring(true);
    return c;
  }
  function makeMoon(R) {
    const c = document.createElement('canvas'); c.width = c.height = Math.ceil(R * 2.6);
    const x = c.getContext('2d'), m = c.width / 2;
    const g = x.createRadialGradient(m - R * .4, m - R * .4, R * .1, m, m, R);
    g.addColorStop(0, '#E8F6F8'); g.addColorStop(.6, '#2DB9DA'); g.addColorStop(1, '#0B3C55');
    x.fillStyle = g; x.beginPath(); x.arc(m, m, R, 0, 7); x.fill();
    x.strokeStyle = 'rgba(13,10,46,.45)'; x.lineWidth = R * .08;            // Adinkrahene circles
    [.35, .6].forEach(k => { x.beginPath(); x.arc(m + R * .1, m + R * .1, R * k, 0, 7); x.stroke(); });
    return c;
  }

  function resize() {
    W = innerWidth; H = innerHeight;
    canvas.width = Math.round(W * DPR); canvas.height = Math.round(H * DPR);
    ctx.setTransform(DPR, 0, 0, DPR, 0, 0);
    docH = Math.max(document.documentElement.scrollHeight - H, 1);
    const n = Math.round(Math.min(W * H / 4200, 420));
    stars = Array.from({ length: n }, () => ({ x: Math.random() * W, y: Math.random() * H * 1.6, z: Math.random() < .6 ? .15 : Math.random() < .7 ? .35 : .7, r: rand(.3, 1.4), tw: rand(0, 6.28), c: Math.random() < .12 ? '#F4B63F' : Math.random() < .1 ? '#2DB9DA' : '#EDE8FF' }));
    nebula = makeNebula();
    planet = makePlanet(Math.min(W, H) * (W < 760 ? .16 : .13));
    moon = makeMoon(Math.min(W, H) * .028);
  }

  // where the constellation sits
  const mapBox = () => {
    const mobile = W < 760;
    const size = mobile ? Math.min(W * .95, H * .6) : Math.min(H * .78, W * .42);
    return { x: mobile ? (W - size) / 2 : W - size - W * .04, y: mobile ? H * .06 : (H - size) / 2 + 20, s: size, mobile };
  };
  const proj = (lng, lat, b) => [b.x + (lng + 19) / 72 * b.s, b.y + (38 - lat) / 74 * b.s];

  let last = performance.now(), acc = 0, t = 0, sp = 0;
  const FPS = FINE ? 60 : 30;

  function draw(dt) {
    t += dt;
    const sy = scrollY;
    sp = sy / docH;
    ctx.clearRect(0, 0, W, H);
    // nebula drifts slowly
    ctx.globalAlpha = 1;
    ctx.drawImage(nebula, -20 + Math.sin(t * .03) * 20, -sy * .02 % 40 - 20, W + 40, H + 40);

    // stars, three depths
    for (const s of stars) {
      let y = (s.y - sy * s.z) % (H * 1.6); if (y < 0) y += H * 1.6; if (y > H) continue;
      const a = .35 + .65 * Math.abs(Math.sin(t * (.6 + s.z) + s.tw));
      ctx.globalAlpha = a * (s.z > .5 ? 1 : .7); ctx.fillStyle = s.c;
      ctx.beginPath(); ctx.arc(s.x, y, s.r * (s.z > .5 ? 1.3 : 1), 0, 6.283); ctx.fill();
    }
    ctx.globalAlpha = 1;

    // planet + moon (drift with scroll)
    if (planet) {
      const mobile = W < 760;
      const px = mobile ? -planet.width * .35 : W * .02 - planet.width * .2;
      const py = H * (mobile ? .72 : .62) - sp * H * .5 - planet.height / 2;
      ctx.globalAlpha = mobile ? .55 : .9;
      ctx.drawImage(planet, px, py);
      const ma = t * .15;
      ctx.drawImage(moon, px + planet.width / 2 + Math.cos(ma) * planet.width * .55 - moon.width / 2, py + planet.height / 2 + Math.sin(ma) * planet.width * .14 - moon.height / 2);
      ctx.globalAlpha = 1;
    }

    // constellation of nations
    const b = mapBox();
    const fade = b.mobile ? .28 : Math.max(.25, .75 - sp * .6);
    ctx.save();
    ctx.translate(0, -sp * H * .25);
    // coastline as dotted constellation
    ctx.globalAlpha = fade * .5; ctx.fillStyle = '#F1D3AA';
    for (let i = 0; i < AFRICA.length; i++) {
      const a = AFRICA[i], c = AFRICA[(i + 1) % AFRICA.length];
      const [x1, y1] = proj(a[0], a[1], b), [x2, y2] = proj(c[0], c[1], b);
      const steps = Math.max(1, Math.round(Math.hypot(x2 - x1, y2 - y1) / 7));
      for (let k = 0; k < steps; k++) { ctx.fillRect(x1 + (x2 - x1) * k / steps - .7, y1 + (y2 - y1) * k / steps - .7, 1.4, 1.4); }
    }
    // links
    const P = CITIES.map(c => proj(c[0], c[1], b));
    ctx.lineWidth = 1;
    LINKS.forEach(([i, j]) => {
      const hub = CITIES[i][3] && CITIES[j][3];
      ctx.globalAlpha = fade * (hub ? .55 : .22);
      ctx.strokeStyle = hub ? '#F4B63F' : '#2DB9DA';
      ctx.beginPath(); ctx.moveTo(P[i][0], P[i][1]);
      const mx = (P[i][0] + P[j][0]) / 2, my = (P[i][1] + P[j][1]) / 2 - Math.hypot(P[j][0] - P[i][0], P[j][1] - P[i][1]) * .15;
      ctx.quadraticCurveTo(mx, my, P[j][0], P[j][1]); ctx.stroke();
    });
    // packets
    if (!REDUCE && Math.random() < dt * 4 && packets.length < 24) {
      const L = LINKS[(Math.random() * LINKS.length) | 0];
      packets.push({ L: Math.random() < .5 ? L : [L[1], L[0]], p: 0, v: rand(.25, .6) });
    }
    packets = packets.filter(k => (k.p += dt * k.v) < 1);
    packets.forEach(k => {
      const [i, j] = k.L, u = k.p;
      const mx = (P[i][0] + P[j][0]) / 2, my = (P[i][1] + P[j][1]) / 2 - Math.hypot(P[j][0] - P[i][0], P[j][1] - P[i][1]) * .15;
      const x = (1 - u) ** 2 * P[i][0] + 2 * (1 - u) * u * mx + u * u * P[j][0];
      const y = (1 - u) ** 2 * P[i][1] + 2 * (1 - u) * u * my + u * u * P[j][1];
      ctx.globalAlpha = fade * Math.sin(u * Math.PI); ctx.fillStyle = '#FFE2A3';
      ctx.beginPath(); ctx.arc(x, y, 2.2, 0, 6.283); ctx.fill();
    });
    // nodes: Nsoromma-style star rings
    CITIES.forEach((c, i) => {
      const [x, y] = P[i], bma = c[3], pulse = .5 + .5 * Math.sin(t * 2 + i);
      ctx.globalAlpha = fade * (bma ? 1 : .6);
      ctx.strokeStyle = bma ? '#F4B63F' : '#2DB9DA'; ctx.fillStyle = ctx.strokeStyle;
      ctx.beginPath(); ctx.arc(x, y, bma ? 3.2 : 2, 0, 6.283); ctx.fill();
      if (bma) {
        ctx.lineWidth = 1.2; ctx.globalAlpha = fade * (.3 + .5 * pulse);
        ctx.beginPath(); ctx.arc(x, y, 7 + pulse * 3, 0, 6.283); ctx.stroke();
        ctx.globalAlpha = fade * .8;
        for (let r = 0; r < 8; r++) { const a = r * Math.PI / 4 + t * .3; ctx.fillRect(x + Math.cos(a) * 11 - .8, y + Math.sin(a) * 11 - .8, 1.6, 1.6); }
      }
    });
    ctx.restore();

    // shooting stars
    if (!REDUCE && Math.random() < dt * .15) shooting.push({ x: rand(W * .2, W), y: rand(0, H * .4), l: 0 });
    shooting = shooting.filter(s => (s.l += dt) < 1);
    shooting.forEach(s => {
      const k = s.l, x = s.x - k * 520, y = s.y + k * 220;
      const g = ctx.createLinearGradient(x, y, x + 90, y - 38);
      g.addColorStop(0, 'rgba(255,226,163,.9)'); g.addColorStop(1, 'rgba(255,226,163,0)');
      ctx.globalAlpha = Math.sin(k * Math.PI); ctx.strokeStyle = g; ctx.lineWidth = 1.6;
      ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x + 90, y - 38); ctx.stroke();
    });
    ctx.globalAlpha = 1;
  }

  let raf = 0;
  const frame = now => {
    const dt = Math.min((now - last) / 1000, .1); last = now; acc += dt;
    if (acc >= 1 / FPS - .002) { draw(acc); acc = 0; }
    raf = requestAnimationFrame(frame);
  };
  resize();
  let rt; addEventListener('resize', () => { clearTimeout(rt); rt = setTimeout(resize, 150); });
  addEventListener('load', () => { docH = Math.max(document.documentElement.scrollHeight - H, 1); });
  if (REDUCE) { draw(0); addEventListener('scroll', () => draw(0), { passive: true }); return; }
  const start = () => { if (!raf) { last = performance.now(); raf = requestAnimationFrame(frame); } };
  const stop = () => { cancelAnimationFrame(raf); raf = 0; };
  document.addEventListener('visibilitychange', () => (document.hidden ? stop() : start()));
  start();
})();
