/* Two Paws chapters. Tile key:
   # ground   = one-way plank   ^ thorns   c Doge coin   k checkpoint   O portal   1/2 spawns
   x cracked stone (Drum dog barks it)   d talking drum -> U sky bridge for 6s   u rising wind (Cape dog glides up)
   G gold light (Drum dog only)   T teal light (Cape dog only)
   q/w/e plates hold Q/W/E doors open   r/y plates raise R/Y bridges   v latch plates: all held at once opens V for good
   hints: [column, icon, text] */
window.BMA_LEVELS = [
 {
  "id": "savanna-moon",
  "name": "Savanna Moon",
  "sub": "Chapter 1",
  "sky": [
   "#2A1B5E",
   "#C2552F"
  ],
  "rows": [
   "                                                                  #",
   "                                                                  #",
   "                                ########                          #",
   "                                ########                          #",
   "                                ########                          #",
   "                                ########                          #",
   "                                ########                          #",
   "                                   T                              #",
   "                        cc       c T c                            #",
   "              c                    T                              #",
   "       c                ##      ########     ccc          c       #",
   "      c c    ###        ##         G                     c c      #",
   "           #####  ccc   QQ   ==    G c                        OO  #",
   "  1 2      #####        QQ kq      G                r k       OO  #",
   "###########################################RRRRRRR#################",
   "###########################################       #################",
   "###########################################^^^^^^^#################"
  ],
  "par": 120,
  "hints": [
   [
    1,
    "pack",
    "Two paws, one goal. Both dogs must reach the portal."
   ],
   [
    19,
    "stack",
    "Too high alone. One dog jumps on the other’s head to climb."
   ],
   [
    26,
    "door",
    "Step on the plate to open the door for your partner."
   ],
   [
    30,
    "split",
    "Gold lights let the Drum dog through. Teal lights let the Cape dog through."
   ],
   [
    41,
    "glide",
    "Only the Cape dog can glide that gap. Hold jump in the air."
   ],
   [
    50,
    "bridge",
    "Plate down = bridge up. Hold it while your partner crosses."
   ]
  ],
  "coins": 18
 },
 {
  "id": "kente-nebula",
  "name": "Kente Nebula",
  "sub": "Chapter 2",
  "sky": [
   "#0E2A4A",
   "#13A881"
  ],
  "rows": [
   "        #                               ####     #                                 V       #",
   "        #                  uu           ####     #                                 V       #",
   "        #                  uu           ####     #          uuu                    V       #",
   "        #                  uc           ####     #          uuu                    V       #",
   "        #                  cu           ####     #          uuc  c                 V       #",
   "        #                  uu c         ####     #          ucu y                  V       #",
   "        #                  uu  q        ####     #          uuu====                V       #",
   "        #                  uu####       ####     #          uuu                    V       #",
   "        #   c              uu####       ####     #          uuu              c     V       #",
   "        #    d             uu####       ####     #      c   uuu               v    V       #",
   "      c x   ##             uu####      c####     #    c   c uuu             ####   V       #",
   "     c  x   ##    cc       uuQQQQ        WW      x          uuu          cc ####   V       #",
   "        x   ##   c  c      uuQQQQ        WW c    x          uuu             ####   V  OO   #",
   "  1 2   x   ##          k  uuQQQQ  k  w  WW  w   x          uuu     k  v    ####   V  OO   #",
   "###############UUUUUUUU#############################YYYYYYYY################################",
   "###############        #############################        ################################",
   "###############^^^^^^^^#############################^^^^^^^^################################"
  ],
  "par": 240,
  "hints": [
   [
    1,
    "drum",
    "New skill: Talking Drum. Bark to crack the stone."
   ],
   [
    10,
    "stack",
    "Lift your partner onto the ledge, then bark at the drum."
   ],
   [
    14,
    "bridge",
    "The sky bridge lasts 6 seconds. Run!"
   ],
   [
    25,
    "wind",
    "Cape dog: glide into the rising wind."
   ],
   [
    36,
    "door",
    "Hold the door for each other."
   ],
   [
    47,
    "drum",
    "Crack the stone again."
   ],
   [
    50,
    "glide",
    "Cape dog: glide over, ride the wind, raise the bridge."
   ],
   [
    69,
    "latch",
    "One dog lifts the other onto the high plate. Then both plates at once."
   ]
  ],
  "coins": 21
 },
 {
  "id": "baobab-station",
  "name": "Baobab Station",
  "sub": "Chapter 3",
  "sky": [
   "#3B1638",
   "#E59A2F"
  ],
  "rows": [
   "                  #####       #########                V       #",
   "                  #####       #########                V       #",
   "                  #####       #########                V       #",
   "                    T             Q                    V       #",
   "                    T  cc         Q c  c               V       #",
   "                    T             Q  w                 V       #",
   "                 ########################              V       #",
   "                    G     x           W                V       #",
   "                    G     x           W                V       #",
   "                    G     x           W                V       #",
   "                    G     x           W         cc     V       #",
   "             ==     G  cc x  c        W                V       #",
   "      ccc           G     x           W                V  OO   #",
   "  1 2               G     x       q   W    k  v ^^  v  V  OO   #",
   "################################################################",
   "################################################################",
   "################################################################"
  ],
  "par": 150,
  "hints": [
   [
    1,
    "boost",
    "New skill: Sky Boost. Cape dog, tap jump again in mid-air to reach the high lane."
   ],
   [
    17,
    "split",
    "Split up: each dog takes its own lane."
   ],
   [
    24,
    "drum",
    "Drum dog: bark through the cracked wall."
   ],
   [
    30,
    "door",
    "Down below, a plate opens the upper door. Up top, a plate opens the lower door."
   ],
   [
    44,
    "latch",
    "The great gate opens only when BOTH latch plates are held at once."
   ]
  ],
  "coins": 12
 },
 {
  "id": "sahara-rings",
  "name": "Sahara Rings",
  "sub": "Finale",
  "sky": [
   "#4A1E10",
   "#F4B63F"
  ],
  "rows": [
   "        ##                  W                                                          V       #",
   "        ##                  W    uu                                                    V       #",
   "        ##                  W    uc                    ######## #                      V       #",
   "        ##                  W    cu                    ######## #     c                V       #",
   "        ##                  W    uu c                  ######## #  ########            V       #",
   "        ##                  W    uu  q                 ######## # c########            V       #",
   "        ##                  W    uu####                ######## #  ########            V       #",
   "        ##                  W    uu####                   T     #  ########            V       #",
   "        ##                  W    uu####      c            T c   #c ########            V       #",
   "        ##   d              W    uu####     c c           T     #  ########            V       #",
   "        xx  ##              W    uu####                ######## #  ########       cc   V       #",
   "     cc xx  ##    c c     c W c  uuQQQQ                   G     #  EEEEEEEE            V       #",
   "        xx  ##  c     c     W    uuQQQQ             ==    G c      EEEEEEEE            V  OO   #",
   "  1 2   xx  ##          kw  W  w uuQQQQ k          r      G        EEEEEEEE e k v ^^ v V  OO   #",
   "###############UUUUUUUU###################RRRRRRR###############################################",
   "###############        ###################       ###############################################",
   "###############^^^^^^^^###################^^^^^^^###############################################"
  ],
  "par": 300,
  "hints": [
   [
    1,
    "pack",
    "Everything you learned, one run. Ubuntu: I am because we are."
   ],
   [
    26,
    "door",
    "Hold the door for each other."
   ],
   [
    31,
    "wind",
    "Ride the wind, Cape dog."
   ],
   [
    50,
    "glide",
    "Glide, press, cross."
   ],
   [
    52,
    "split",
    "Split lanes, meet again."
   ],
   [
    63,
    "grip",
    "New skill: Paw Grip. Drum dog, jump between the walls to climb the shaft."
   ],
   [
    75,
    "door",
    "Open the base door for your partner."
   ],
   [
    79,
    "latch",
    "Latch the gate together and go home."
   ]
  ],
  "coins": 21
 }
];
