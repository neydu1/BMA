/* BMA Web3 Hub: wallet connect (MyDoge / EVM / watch-only), Dogecoin chain pulse,
   signed Pack Council votes, scam link checker. */
(() => {
  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => [...r.querySelectorAll(s)];
  const csrf = $('meta[name="csrf"]')?.content || '';
  const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const store = { get(k, d) { try { const v = localStorage.getItem(k); return v ? JSON.parse(v) : d; } catch { return d; } }, set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch {} }, del(k) { try { localStorage.removeItem(k); } catch {} } };
  const short = a => a ? a.slice(0, 6) + '…' + a.slice(-4) : '';
  const getJSON = (u, ms = 9000) => Promise.race([fetch(u).then(r => (r.ok ? r.json() : Promise.reject(r.status))), new Promise((_, j) => setTimeout(() => j('timeout'), ms))]);

  let price = null;
  const priceP = getJSON('https://api.coingecko.com/api/v3/simple/price?ids=dogecoin&vs_currencies=usd&include_24hr_change=true')
    .then(d => (price = d.dogecoin)).catch(() => null);

  /* ---------------- wallet ---------------- */
  const W = { chain: '', address: '', watch: false };
  const box = $('.w3-wallet');
  const say = (t, ok) => { const m = $('[data-w3="msg"]'); if (m) { m.textContent = t; m.className = 'form-msg ' + (ok ? 'ok' : t ? 'err' : ''); } };
  const isDoge = a => /^[DA9][1-9A-HJ-NP-Za-km-z]{25,34}$/.test(a);

  async function showAccount() {
    if (!box) return;
    $('[data-w3="account"]').hidden = !W.address;
    $('[data-w3="buttons"]').hidden = !!W.address && !W.watch;
    $('[data-w3="watch"]').hidden = !!W.address;
    if (!W.address) return;
    $('[data-w3="addr"]').textContent = short(W.address);
    $('[data-w3="addr"]').title = W.address;
    $('.w3-dot').classList.toggle('watch', W.watch);
    const links = W.chain === 'doge'
      ? `<a class="text-link" href="https://dogechain.info/address/${esc(W.address)}" target="_blank" rel="noopener">View on explorer</a><a class="text-link" href="https://market.doginaldogs.com" target="_blank" rel="noopener">Doginal Dogs market</a>`
      : `<a class="text-link" href="https://etherscan.io/address/${esc(W.address)}" target="_blank" rel="noopener">View on Etherscan</a>`;
    $('[data-w3="links"]').innerHTML = links + (W.watch ? '<span class="muted small">Watch-only: connect a wallet to sign votes.</span>' : '');
    $('[data-w3="bal"]').textContent = '…'; $('[data-w3="usd"]').textContent = '…';
    try {
      if (W.chain === 'doge') {
        const d = await getJSON(`https://api.blockcypher.com/v1/doge/main/addrs/${W.address}/balance`);
        const doge = (d.final_balance || 0) / 1e8;
        $('[data-w3="bal"]').textContent = doge.toLocaleString(undefined, { maximumFractionDigits: 2 }) + ' Ð';
        await priceP;
        $('[data-w3="usd"]').textContent = price ? '$' + (doge * price.usd).toLocaleString(undefined, { maximumFractionDigits: 2 }) : '—';
      } else {
        const hex = await window.ethereum.request({ method: 'eth_getBalance', params: [W.address, 'latest'] });
        $('[data-w3="bal"]').textContent = (parseInt(hex, 16) / 1e18).toLocaleString(undefined, { maximumFractionDigits: 4 }) + ' ETH';
        $('[data-w3="usd"]').textContent = 'EVM wallet';
      }
    } catch { $('[data-w3="bal"]').textContent = 'Unavailable'; $('[data-w3="usd"]').textContent = '—'; }
    window.dispatchEvent(new CustomEvent('w3:wallet', { detail: { ...W } }));
  }

  async function connect(kind) {
    say('');
    try {
      if (kind === 'doge') {
        if (!window.doge) { say('MyDoge wallet not found. Install the MyDoge extension or open this page in the MyDoge app, or paste an address to watch.', false); return; }
        const r = await window.doge.connect();
        if (!r || r.approved === false || !r.address) throw new Error('Connection was not approved.');
        Object.assign(W, { chain: 'doge', address: r.address, watch: false });
      } else {
        if (!window.ethereum) { say('No EVM wallet found. Install MetaMask (or another EVM wallet) and refresh.', false); return; }
        const [a] = await window.ethereum.request({ method: 'eth_requestAccounts' });
        Object.assign(W, { chain: 'evm', address: a, watch: false });
      }
      store.set('w3-wallet', { chain: W.chain, address: W.address, watch: false });
      say('Wallet connected.', true);
      showAccount();
    } catch (e) { say(e && e.message ? e.message : 'Could not connect.', false); }
  }

  if (box) {
    $$('[data-connect]').forEach(b => b.addEventListener('click', () => connect(b.dataset.connect)));
    $('[data-w3="watch"]').addEventListener('submit', e => {
      e.preventDefault();
      const a = $('#w3-addr').value.trim();
      if (!isDoge(a)) { say('That does not look like a Dogecoin address. They start with D and are 34 characters.', false); return; }
      Object.assign(W, { chain: 'doge', address: a, watch: true });
      store.set('w3-wallet', { ...W }); say(''); showAccount();
    });
    $('[data-w3="disconnect"]').addEventListener('click', () => { Object.assign(W, { chain: '', address: '', watch: false }); store.del('w3-wallet'); showAccount(); window.dispatchEvent(new CustomEvent('w3:wallet', { detail: { ...W } })); });
    const saved = store.get('w3-wallet', null);
    if (saved && saved.address) { Object.assign(W, saved, { watch: saved.watch || true }); showAccount(); }   // reconnect later to sign
  }

  async function sign(message) {
    if (!W.address || W.watch) return null;
    if (W.chain === 'doge' && window.doge?.requestSignedMessage) {
      const r = await window.doge.requestSignedMessage({ message });
      return r && (r.signedMessage || r.signature) || null;
    }
    if (W.chain === 'evm' && window.ethereum) {
      const hex = '0x' + [...new TextEncoder().encode(message)].map(b => b.toString(16).padStart(2, '0')).join('');
      return await window.ethereum.request({ method: 'personal_sign', params: [hex, W.address] });
    }
    return null;
  }

  /* ---------------- chain pulse ---------------- */
  const pulse = $('.w3-pulse');
  if (pulse) {
    let first = null, lastTime = null;
    const set = (k, v) => { const el = $(`[data-pulse="${k}"]`); if (el) el.textContent = v; };
    const ago = () => { if (!lastTime) return; const s = Math.max(0, Math.round((Date.now() - lastTime) / 1000)); set('ago', s < 60 ? `${s}s ago` : `${Math.floor(s / 60)}m ${s % 60}s ago`); };
    const tick = async () => {
      try {
        const d = await getJSON('https://api.blockcypher.com/v1/doge/main');
        if (first === null) first = d.height;
        if (lastTime && d.height > Number($('[data-pulse="height"]').dataset.h || 0)) pulse.classList.remove('beat'), void pulse.offsetWidth, pulse.classList.add('beat');
        $('[data-pulse="height"]').dataset.h = d.height;
        set('height', d.height.toLocaleString());
        set('mempool', (d.unconfirmed_count ?? 0).toLocaleString());
        lastTime = Date.parse(d.time); ago();
        const n = d.height - first;
        set('since', n > 0 ? `You've witnessed ${n} new block${n === 1 ? '' : 's'} since you landed. Wow.` : 'Blocks land about once a minute. This page counts the ones you witness.');
      } catch { if (!lastTime) { set('height', '—'); set('ago', '—'); set('mempool', '—'); set('since', "Couldn't reach the Dogecoin network just now. Retrying every 30 seconds."); } }
    };
    priceP.then(p => { if (p) set('price', `$${p.usd.toFixed(4)} ${p.usd_24h_change >= 0 ? '▲' : '▼'}${Math.abs(p.usd_24h_change).toFixed(1)}%`); else set('price', '—'); });
    tick(); setInterval(tick, 30000); setInterval(ago, 1000);
  }

  /* ---------------- Pack Council ---------------- */
  const props = $$('[data-prop]');
  if (props.length) {
    const paint = d => {
      if (!d || !d.tallies) return;
      props.forEach(card => {
        const id = card.dataset.prop, t = d.tallies[id]; if (!t) return;
        const mine = d.mine ? d.mine[id] : undefined;
        $$('.w3-opt', card).forEach(b => {
          const i = Number(b.dataset.opt), n = t.counts[i] || 0, pct = t.total ? Math.round(n / t.total * 100) : 0;
          b.style.setProperty('--p', pct + '%');
          $('.w3-pct', b).textContent = t.total ? pct + '%' : '';
          b.classList.toggle('mine', mine === i);
          b.classList.toggle('voted', mine !== undefined);
        });
        $('[data-prop-meta]', card).textContent = `${t.total} vote${t.total === 1 ? '' : 's'} · ${t.signed} wallet-signed`;
      });
    };
    fetch('api/vote.php', { cache: 'no-store' }).then(r => r.json()).then(paint).catch(() => {});
    props.forEach(card => $$('.w3-opt', card).forEach(b => b.addEventListener('click', async () => {
      const msg = $('.form-msg', card);
      if (b.classList.contains('voted')) { msg.textContent = 'You already voted on this one.'; msg.className = 'form-msg err'; return; }
      const id = card.dataset.prop, opt = Number(b.dataset.opt), label = $('.w3-label', b).textContent;
      const fd = new FormData(); fd.set('csrf', csrf); fd.set('proposal', id); fd.set('option', opt);
      try {
        if (W.address && !W.watch) {
          msg.textContent = 'Check your wallet to sign (free, no transaction)…'; msg.className = 'form-msg';
          const message = `BMA Pack Council\nProposal: ${id}\nChoice: ${label}\nWallet: ${W.address}\nTime: ${new Date().toISOString()}`;
          const sig = await sign(message);
          if (sig) { fd.set('address', W.address); fd.set('signature', sig); fd.set('chain', W.chain); }
        }
        const r = await fetch('api/vote.php', { method: 'POST', body: fd, credentials: 'same-origin' });
        const d = await r.json();
        paint(d);
        msg.textContent = d.message || ''; msg.className = 'form-msg ' + (d.ok ? 'ok' : 'err');
      } catch (e) { msg.textContent = e && e.message ? e.message : 'Could not reach the server.'; msg.className = 'form-msg err'; }
    })));
  }

  /* ---------------- scam check ---------------- */
  const sf = $('#scam-form');
  if (sf) {
    const OFFICIAL = { 'x.com': ['/barkmediafrica'], 'twitter.com': ['/barkmediafrica'], 't.me': ['/barkmediaafrica'], 'doginaldogs.com': ['*'], 'market.doginaldogs.com': ['*'], [location.hostname]: ['*'] };
    sf.addEventListener('submit', e => {
      e.preventDefault();
      const out = $('#scam-out'); let u;
      try { u = new URL($('#scam-url').value.trim().replace(/^(?!https?:\/\/)/, 'https://')); } catch { out.className = 'w3-verdict bad'; out.textContent = 'That is not a valid link.'; return; }
      const host = u.hostname.replace(/^www\./, '').toLowerCase();
      const rule = OFFICIAL[host];
      const ok = rule && (rule[0] === '*' || rule.some(p => u.pathname.toLowerCase().startsWith(p)));
      const lookalike = !ok && /(d[o0]g[i1l]n[a4]l|bark.?media|barkmediaf?r?ica)/i.test(host);
      out.className = 'w3-verdict ' + (ok ? 'good' : 'bad');
      out.textContent = ok ? `✓ ${host} is an official address.` : lookalike ? `⚠ ${host} imitates an official name but is NOT ours. Do not connect a wallet or enter anything there.` : `✕ ${host} is not an official BMA or Doginal Dogs address. Be careful.`;
    });
  }
})();
