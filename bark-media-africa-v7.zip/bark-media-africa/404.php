<?php
http_response_code(404);
$pageTitle = 'Page not found';
require __DIR__ . '/includes/header.php';
?>
<?= page_banner('Page not found', "That link doesn't match any page. Head back home or check today's Spaces.") ?>
<section class="section"><div class="wrap btn-row"><a class="btn btn-gold" href="index.php">Go home</a><a class="btn btn-ghost-dark" href="spaces.php">See Spaces</a></div></section>
<?php require __DIR__ . '/includes/footer.php'; ?>
