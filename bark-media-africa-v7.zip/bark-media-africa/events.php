<?php
$pageTitle = 'Events';
$pageDesc = 'Spaces, AMAs, workshops and meetups hosted by the Bark Media Africa community.';
require __DIR__ . '/includes/header.php';
$sorted = $EVENTS;
usort($sorted, fn($a, $b) => strtotime($b['date']) - strtotime($a['date']));
$types = array_merge(['All'], array_values(array_unique(array_column($EVENTS, 'type'))));
$upcoming = array_values(array_filter($EVENTS, fn($e) => strtotime($e['date']) > time()));
usort($upcoming, fn($a, $b) => strtotime($a['date']) - strtotime($b['date']));
$extraScripts = '<script>(()=>{const x=document.getElementById("x-embed");if(!x)return;const io=new IntersectionObserver(([e])=>{if(!e.isIntersecting)return;io.disconnect();const s=document.createElement("script");s.src="https://platform.twitter.com/widgets.js";s.async=true;document.body.append(s);const t=setInterval(()=>{if(x.querySelector("iframe")){x.classList.add("loaded");clearInterval(t)}},500);setTimeout(()=>clearInterval(t),15000)},{rootMargin:"400px"});io.observe(x)})();</script>';
?>
<?= page_banner('Events', 'What\'s coming up, what we run every week, and everything the community has hosted.') ?>

<section class="section ev-upcoming" id="upcoming">
  <div class="wrap ev-up-grid">
    <div>
      <p class="eyebrow">Coming up</p>
      <h2>Next on the calendar</h2>
      <?php if ($upcoming): ?>
        <ol class="ev-next">
          <?php foreach ($upcoming as $ev): $d = strtotime($ev['date']); ?>
            <li>
              <time datetime="<?= e($ev['date']) ?>"><b><?= date('j', $d) ?></b><?= date('M', $d) ?><small><?= date('D g:i a', $d) ?> WAT</small></time>
              <div><span class="tag"><?= e($ev['type']) ?></span><h3><?= e($ev['title']) ?></h3><p class="muted"><?= e($ev['summary']) ?></p>
                <a class="text-link" href="<?= e($ev['link']) ?>" target="_blank" rel="noopener">Set a reminder on X</a></div>
            </li>
          <?php endforeach; ?>
        </ol>
      <?php else: ?>
        <p class="ev-none">New dates are announced first on <a class="text-link" href="<?= e($SITE['xUrl']) ?>" target="_blank" rel="noopener"><?= e($SITE['handle']) ?></a>. The live feed here shows the latest.</p>
      <?php endif; ?>
      <h3 class="ev-reg-h">Every week</h3>
      <div class="ev-regular">
        <?php foreach ($REGULAR as $r): ?>
          <a class="ev-reg" href="<?= e($r['link']) ?>" <?= strpos($r['link'], 'http') === 0 ? 'target="_blank" rel="noopener"' : '' ?>>
            <span class="tag"><?= e($r['type']) ?></span><b><?= e($r['title']) ?></b><small><?= e($r['when']) ?></small><span class="muted"><?= e($r['body']) ?></span>
          </a>
        <?php endforeach; ?>
      </div>
    </div>
    <div class="x-embed" id="x-embed">
      <a class="twitter-timeline" data-theme="dark" data-chrome="noheader nofooter transparent" data-height="620" href="https://twitter.com/<?= e(ltrim($SITE['handle'], '@')) ?>?ref_src=twsrc%5Etfw">Posts by <?= e($SITE['handle']) ?></a>
      <div class="x-fallback"><div><p>Live posts and event announcements from <?= e($SITE['handle']) ?> load here.</p><a class="btn btn-gold" href="<?= e($SITE['xUrl']) ?>" target="_blank" rel="noopener">Open <?= e($SITE['handle']) ?> on X</a></div></div>
    </div>
  </div>
</section>

<section class="section">
  <div class="wrap">
    <div class="section-head"><p class="eyebrow">Past events</p><h2>From the timeline</h2></div>

    <div class="chips" role="group" aria-label="Filter events by type">
      <?php foreach ($types as $i => $t): ?>
        <button class="chip" type="button" aria-pressed="<?= $i === 0 ? 'true' : 'false' ?>" data-filter="<?= e($t) ?>"><?= e($t) ?></button>
      <?php endforeach; ?>
    </div>
    <ol class="timeline" id="timeline">
      <?php foreach ($sorted as $ev): $d = strtotime($ev['date']); ?>
        <li data-type="<?= e($ev['type']) ?>">
          <time datetime="<?= e($ev['date']) ?>"><b><?= date('j', $d) ?></b><span><?= date('M Y', $d) ?></span></time>
          <article class="event">
            <div class="event-meta"><span class="tag"><?= e($ev['type']) ?></span><span class="muted"><?= date('D, g:i a', $d) ?> WAT</span></div>
            <h3><?= e($ev['title']) ?></h3>
            <p><?= e($ev['summary']) ?></p>
            <p class="muted small">Host: <?= e($ev['host']) ?><?= $ev['guests'] ? ', with ' . e($ev['guests']) : '' ?><?= $ev['listeners'] ? ', ' . number_format($ev['listeners']) . ' listeners' : '' ?></p>
            <a class="text-link" href="<?= e($ev['link']) ?>" target="_blank" rel="noopener">View on X</a>
          </article>
        </li>
      <?php endforeach; ?>
    </ol>
    <div class="empty" id="events-empty" hidden>No events of this type yet.</div>
  </div>
</section>

<?= newsletter_block('events') ?>
<?php require __DIR__ . '/includes/footer.php'; ?>
