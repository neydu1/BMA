<?php
$pageTitle = 'Checkout';
$bodyClass = 'checkout-page';
require __DIR__ . '/includes/header.php';
$states = ['Abuja (FCT)','Abia','Adamawa','Akwa Ibom','Anambra','Bauchi','Bayelsa','Benue','Borno','Cross River','Delta','Ebonyi','Edo','Ekiti','Enugu','Gombe','Imo','Jigawa','Kaduna','Kano','Katsina','Kebbi','Kogi','Kwara','Lagos','Nasarawa','Niger','Ogun','Ondo','Osun','Oyo','Plateau','Rivers','Sokoto','Taraba','Yobe','Zamfara'];
?>
<section class="section checkout">
  <div class="wrap">
    <h1 class="checkout-title">Checkout</h1>
    <?php if (isset($_GET['cancelled'])): ?>
      <p class="notice">Payment was cancelled, so you haven't been charged. Your cart is still here when you're ready.</p>
    <?php endif; ?>

    <div class="empty big" id="checkout-empty" hidden>
      <h2>Your cart is empty</h2>
      <p>Add a tee, a bottle or a sticker pack and come back here to pay.</p>
      <a class="btn btn-gold" href="shop.php">Browse the shop</a>
    </div>

    <form class="checkout-grid" id="checkout-form" novalidate>
      <div class="co-main">
        <div class="co-hidden">
          <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
          <input type="text" name="website" class="hp" tabindex="-1" autocomplete="off" aria-hidden="true">
        </div>

        <section class="co-block" aria-labelledby="co-contact-h">
          <h2 id="co-contact-h">Contact</h2>
          <div class="co-fields">
            <div class="co-field full"><label for="co-name">Full name</label><input id="co-name" name="name" autocomplete="name" required></div>
            <div class="co-field"><label for="co-email">Email for your receipt</label><input id="co-email" name="email" type="email" autocomplete="email" required></div>
            <div class="co-field"><label for="co-phone">Phone (WhatsApp preferred)</label><input id="co-phone" name="phone" type="tel" autocomplete="tel" placeholder="080..." required></div>
          </div>
        </section>

        <section class="co-block" aria-labelledby="co-delivery-h">
          <h2 id="co-delivery-h">Delivery</h2>
          <div class="ship-options" role="radiogroup" aria-labelledby="co-delivery-h">
            <?php $i = 0; foreach ($SHIPPING as $key => $s): ?>
              <label class="ship">
                <input type="radio" name="shipping" value="<?= e($key) ?>" data-price="<?= (int) $s['price'] ?>" <?= $i++ === 0 ? 'checked' : '' ?>>
                <span class="ship-body"><b><?= e($s['label']) ?></b><small><?= e($s['eta']) ?></small></span>
                <span class="ship-price"><?= $s['price'] ? money($s['price']) : 'Free' ?></span>
              </label>
            <?php endforeach; ?>
          </div>
          <div class="co-fields" id="address-fields">
            <div class="co-field full"><label for="co-address">Street address</label><input id="co-address" name="address" autocomplete="street-address"></div>
            <div class="co-field"><label for="co-city">City / area</label><input id="co-city" name="city" autocomplete="address-level2"></div>
            <div class="co-field"><label for="co-state">State</label>
              <select id="co-state" name="state"><?php foreach ($states as $st): ?><option><?= e($st) ?></option><?php endforeach; ?><option>Outside Nigeria</option></select></div>
            <div class="co-field full" id="country-field" hidden><label for="co-country">Country</label><input id="co-country" name="country" value="Nigeria" autocomplete="country-name"></div>
          </div>
          <div class="co-fields">
            <div class="co-field full"><label for="co-note">Delivery note (optional)</label><textarea id="co-note" name="note" rows="2" placeholder="Landmark, gate code, best time to call"></textarea></div>
          </div>
        </section>
      </div>

      <aside class="co-summary">
        <h2>Order summary</h2>
        <div class="co-lines" data-co-lines></div>
        <dl class="co-totals">
          <div><dt>Subtotal</dt><dd data-co-subtotal>₦0</dd></div>
          <div><dt>Delivery</dt><dd data-co-ship>₦0</dd></div>
          <div class="grand"><dt>Total</dt><dd data-co-total>₦0</dd></div>
        </dl>
        <p class="form-msg" id="co-msg" role="alert"></p>
        <button class="btn btn-gold block" type="submit" id="pay-btn">Pay with Paystack</button>
        <p class="secure small"><svg viewBox="0 0 24 24" width="16" height="16" aria-hidden="true"><path d="M7 11V8a5 5 0 0 1 10 0v3M5 11h14v10H5z" fill="none" stroke="currentColor" stroke-width="2"/></svg> You'll finish payment on Paystack's secure page. Card, bank transfer and USSD accepted.</p>
      </aside>
    </form>
  </div>
</section>
<?php require __DIR__ . '/includes/footer.php'; ?>
