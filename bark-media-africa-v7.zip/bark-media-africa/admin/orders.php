<?php
/* Simple orders dashboard. Password is ADMIN_PASSWORD in includes/config.php. */
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/orders.php';
header('X-Robots-Tag: noindex');

if (isset($_GET['logout'])) { unset($_SESSION['bma_admin']); header('Location: orders.php'); exit; }
$err = '';
if (isset($_POST['password'])) {
  if (rate_limited('admin_login', 6, 900)) $err = 'Too many attempts. Wait 15 minutes.';
  elseif (ADMIN_PASSWORD !== 'change-this-password' && hash_equals(ADMIN_PASSWORD, (string) $_POST['password'])) { session_regenerate_id(true); $_SESSION['bma_admin'] = true; header('Location: orders.php'); exit; }
  else $err = ADMIN_PASSWORD === 'change-this-password' ? 'Set ADMIN_PASSWORD in includes/config.php first.' : 'Wrong password.';
}
$authed = !empty($_SESSION['bma_admin']);

if ($authed && isset($_POST['toggle']) && csrf_check($_POST['csrf'] ?? '')) {
  $o = order_load($_POST['toggle']);
  if ($o) { $o['fulfilled'] = !$o['fulfilled']; $o['fulfilled_at'] = $o['fulfilled'] ? date('c') : null; order_save($o); }
  header('Location: orders.php?' . http_build_query(['show' => $_GET['show'] ?? 'paid'])); exit;
}
if ($authed && isset($_POST['recheck']) && csrf_check($_POST['csrf'] ?? '')) {
  order_confirm($_POST['recheck']);
  header('Location: orders.php?show=all'); exit;
}

$show = $_GET['show'] ?? 'paid';
$orders = $authed ? order_all() : [];
$paid = array_filter($orders, fn($o) => $o['status'] === 'paid');
$revenue = array_sum(array_column($paid, 'total'));
$toShip = count(array_filter($paid, fn($o) => !$o['fulfilled']));
$list = array_filter($orders, fn($o) => $show === 'all' || ($show === 'paid' && $o['status'] === 'paid') || ($show === 'toship' && $o['status'] === 'paid' && !$o['fulfilled']));
?><!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><meta name="robots" content="noindex">
<title>Orders — BMA admin</title>
<link rel="stylesheet" href="../assets/css/style.css?v=3">
</head><body class="admin">
<header class="admin-bar"><div class="wrap nav-row"><a class="brand" href="../index.php"><img src="../<?= e($SITE['logo']) ?>" alt="" width="40" height="40"><span><b>BMA orders</b><small>Shop admin</small></span></a><?php if ($authed): ?><a class="btn btn-ghost" href="?logout=1">Log out</a><?php endif; ?></div></header>
<main class="section"><div class="wrap">
<?php if (!$authed): ?>
  <form method="post" class="passport admin-login">
    <h1>Sign in</h1>
    <label for="pw">Admin password</label>
    <input id="pw" type="password" name="password" autofocus required>
    <?php if ($err): ?><p class="form-msg err"><?= e($err) ?></p><?php endif; ?>
    <button class="btn btn-gold" type="submit">Sign in</button>
  </form>
<?php else: ?>
  <div class="dial admin-stats">
    <div><b><?= count($paid) ?></b><span>paid orders</span></div>
    <div><b><?= money($revenue) ?></b><span>revenue</span></div>
    <div><b><?= $toShip ?></b><span>waiting to ship</span></div>
  </div>
  <div class="chips">
    <?php foreach (['toship' => 'To ship', 'paid' => 'All paid', 'all' => 'Everything (incl. unpaid)'] as $k => $lbl): ?>
      <a class="chip" href="?show=<?= $k ?>" aria-pressed="<?= $show === $k ? 'true' : 'false' ?>"><?= $lbl ?></a>
    <?php endforeach; ?>
  </div>
  <?php if (!$list): ?><div class="empty">No orders here yet.</div><?php endif; ?>
  <div class="admin-orders">
  <?php foreach ($list as $o): $c = $o['customer']; ?>
    <article class="admin-order <?= $o['fulfilled'] ? 'done' : '' ?> st-<?= e($o['status']) ?>">
      <div class="ao-head">
        <div><b><?= e($o['ref']) ?></b> <span class="tag"><?= e($o['status']) ?><?= $o['fulfilled'] ? ' · shipped' : '' ?></span></div>
        <span class="muted small"><?= date('j M Y, g:i a', strtotime($o['paid_at'] ?? $o['created'])) ?></span>
      </div>
      <div class="ao-body">
        <div>
          <p><b><?= e($c['name']) ?></b><br><a href="mailto:<?= e($c['email']) ?>"><?= e($c['email']) ?></a><br><a href="https://wa.me/<?= e(preg_replace('/\D/', '', preg_replace('/^0/', '234', $c['phone']))) ?>" target="_blank" rel="noopener"><?= e($c['phone']) ?></a></p>
          <p class="small"><b><?= e($o['shipping']['label']) ?></b><br><?= e(implode(', ', array_filter([$c['address'], $c['city'], $c['state'], $c['country']]))) ?><?= $c['note'] ? '<br><i>' . e($c['note']) . '</i>' : '' ?></p>
        </div>
        <ul class="ao-lines">
          <?php foreach ($o['lines'] as $l): ?><li><?= $l['qty'] ?> × <?= e($l['name']) ?> <span class="muted">(<?= e(variant_label($l)) ?>)</span></li><?php endforeach; ?>
          <li class="ao-total">Total <?= money($o['total']) ?></li>
        </ul>
      </div>
      <form method="post" class="ao-actions">
        <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
        <?php if ($o['status'] === 'paid'): ?>
          <button class="btn btn-small" name="toggle" value="<?= e($o['ref']) ?>"><?= $o['fulfilled'] ? 'Mark as not shipped' : 'Mark as shipped' ?></button>
        <?php elseif ($o['status'] === 'pending'): ?>
          <button class="btn btn-small" name="recheck" value="<?= e($o['ref']) ?>">Check payment with Paystack</button>
        <?php endif; ?>
      </form>
    </article>
  <?php endforeach; ?>
  </div>
<?php endif; ?>
</div></main>
</body></html>
