<?php
$pageTitle = 'About';
$pageDesc = 'How a single X Space between African DoginalDogs holders became a network of builders, creators and learners across Africa.';
require __DIR__ . '/includes/header.php';
?>
<?= page_banner('From one X Space to a pan-African community', "It's now a network of builders, creators and learners across Africa.") ?>

<section class="section">
  <div class="wrap grid g-2 align-center">
    <div class="prose">
      <h2>Our story</h2>
      <p>BMA began when a few African DoginalDogs holders opened an X Space to talk about crypto from an African point of view. People kept coming back, and they kept bringing friends.</p>
      <p>Today we educate newcomers, help creators earn from their audience, and place trained members with Web3 projects that need an active, genuine presence on X.</p>
      <p class="muted">We connect traditional African ideas of collective strength with decentralized technology, so the next wave of Web3 includes Lagos, Accra, Nairobi and Cape Town by default.</p>
    </div>
    <figure class="media-frame"><img src="<?= e($SITE['communityImage']) ?>" alt="BMA community gathering" loading="lazy"></figure>
  </div>
</section>

<section class="section tinted">
  <div class="wrap">
    <div class="section-head"><h2>How we got here</h2></div>
    <ol class="milestones">
      <?php foreach ($MILESTONES as $i => $m): ?>
        <li><span class="m-num"><?= $i + 1 ?></span><h3><?= e($m['when']) ?></h3><p><?= e($m['text']) ?></p></li>
      <?php endforeach; ?>
    </ol>
  </div>
</section>

<section class="section values-band">
  <div class="wrap">
    <div class="section-head"><h2>What we believe</h2></div>
    <div class="grid g-3">
      <?php foreach ($VALUES as $v): ?>
        <div class="value"><h3><?= e($v['title']) ?></h3><p class="meaning"><?= e($v['meaning']) ?></p><p><?= e($v['body']) ?></p></div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<?= join_cta() ?>
<?php require __DIR__ . '/includes/footer.php'; ?>
