<?php
/* Two Paws — a standalone, full-screen game page.
   It shares the site's session (for X sign-in and the leaderboard) but none of its chrome. */
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/data.php';
require_once __DIR__ . '/includes/game_lib.php';
$teamOptions = function () use ($GAME_TEAMS, $TEAM_FLAGS) {
  $o = '<option value="">Choose your nation…</option>';
  foreach ($GAME_TEAMS as $t) $o .= '<option value="' . e($t) . '">' . ($TEAM_FLAGS[$t] ?? '') . ' ' . e($t) . '</option>';
  return $o;
};
$xIcon = '<svg viewBox="0 0 24 24" width="13" height="13" aria-hidden="true"><path fill="currentColor" d="M17.8 3h3.1l-6.8 7.7L22 21h-6.2l-4.9-6.4L5.3 21H2.2l7.2-8.3L1.8 3h6.4l4.4 5.8L17.8 3Zm-1.1 16.2h1.7L7.4 4.7H5.6l11.1 14.5Z"/></svg>';
?><!doctype html>
<html lang="en" class="tp-app">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover, interactive-widget=resizes-content">
  <title>Two Paws · Bark Media Africa</title>
  <meta name="description" content="Two Paws: a calm, cinematic co-op platformer starring the Dogs of Africa. Play with a friend on one screen and put your nation on the leaderboard.">
  <meta name="theme-color" content="#000000">
  <meta name="mobile-web-app-capable" content="yes">
  <meta name="apple-mobile-web-app-capable" content="yes">
  <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
  <meta name="csrf" content="<?= e(csrf_token()) ?>">
  <link rel="manifest" href="game.webmanifest">
  <link rel="icon" href="<?= e($SITE['logo']) ?>">
  <link rel="apple-touch-icon" href="assets/images/logo-160.png">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Bricolage+Grotesque:opsz,wght@12..96,400;12..96,600;12..96,800&family=Instrument+Sans:wght@400;500;600&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="assets/css/game-app.css?v=2">
  <script>window.TP_FLAGS = <?= json_encode($TEAM_FLAGS, JSON_UNESCAPED_UNICODE) ?>;</script>
</head>
<body>
<div class="tp" id="tp">
  <div class="tp-stage">
    <canvas id="tp-canvas" width="960" height="544" aria-label="Two Paws game screen"></canvas>

    <div class="tp-hud" id="tp-hud">
      <span class="tp-chip tp-ch-name" data-hud="chapter">Chapter 1</span>
      <span class="tp-chip"><i aria-hidden="true">⏱</i> <b data-hud="time">0:00</b></span>
      <span class="tp-chip"><i aria-hidden="true">Ð</i> <b data-hud="coins">0</b></span>
      <span class="tp-chip"><i aria-hidden="true">✖</i> <b data-hud="deaths">0</b></span>
      <span class="tp-chip tp-drum" data-hud="drum" hidden></span>
      <span class="tp-chip tp-me-tag" id="tp-me-tag" hidden></span>
      <span class="tp-hud-btns">
        <button type="button" class="tp-icon" data-act="mute" aria-label="Sound on or off" aria-pressed="false">♪</button>
        <button type="button" class="tp-icon" data-act="pause" aria-label="Pause">❚❚</button>
      </span>
    </div>
    <button type="button" class="tp-tip" id="tp-tip" hidden aria-live="polite" aria-label="Tip"><span class="tp-tip-icon" id="tp-tip-icon" aria-hidden="true">🐾</span><span class="tp-tip-text" id="tp-tip-text"></span></button>
    <div class="tp-skillbar" id="tp-skills" aria-label="Your skills"></div>
  </div>

  <!-- touch pads (phones/tablets) -->
  <div class="tp-touch" id="tp-touch" aria-hidden="true">
    <div class="tp-cluster" data-who="0">
      <span class="tp-tagline p1t">P1</span>
      <button type="button" data-who="0" data-btn="left">◀</button><button type="button" data-who="0" data-btn="right">▶</button>
      <button type="button" data-who="0" data-btn="power" class="pw">🥁</button><button type="button" data-who="0" data-btn="jump" class="jp">⤒</button>
    </div>
    <div class="tp-cluster" data-who="1">
      <span class="tp-tagline p2t">P2</span>
      <button type="button" data-who="1" data-btn="left">◀</button><button type="button" data-who="1" data-btn="right">▶</button>
      <button type="button" data-who="1" data-btn="power" class="pw">🪂</button><button type="button" data-who="1" data-btn="jump" class="jp">⤒</button>
    </div>
    <div class="tp-solo" id="tp-touch-solo" hidden>
      <div class="tp-cluster move" data-who="solo"><button type="button" data-who="solo" data-btn="left">◀</button><button type="button" data-who="solo" data-btn="right">▶</button></div>
      <div class="tp-cluster act" data-who="solo"><button type="button" data-who="solo" data-btn="swap" class="sw">⇄</button><button type="button" data-who="solo" data-btn="power" class="pw">★</button><button type="button" data-who="solo" data-btn="jump" class="jp">⤒</button></div>
    </div>
  </div>

  <div class="tp-invite" id="tp-invite" hidden role="alertdialog" aria-live="assertive">
    <span class="tp-invite-dot" aria-hidden="true">🐾</span><span id="tp-invite-text"></span>
    <button type="button" class="btn btn-gold btn-sm" data-act="accept">Team up</button><button type="button" class="tp-link" data-act="decline">Not now</button>
  </div>
  <div class="tp-toast" id="tp-toast" hidden role="status"></div>

  <!-- menus -->
  <div class="tp-ui" id="tp-ui">
    <section class="tp-screen tp-title" data-screen="title">
      <a class="tp-exit" href="index.php">← Bark Media Africa</a>
      <p class="tp-kicker">Bark Media Africa presents</p>
      <h1 class="tp-logo">TWO <span>PAWS</span></h1>
      <p class="tp-sub">A calm co-op journey across the Afro-cosmos. Ubuntu: I am because we are.</p>
      <div class="tp-menu">
        <button type="button" class="btn btn-gold big" data-act="play">Play</button>
        <button type="button" class="btn btn-ghost" data-act="board">Leaderboard</button>
        <button type="button" class="btn btn-ghost" data-act="how">How to play</button>
        <button type="button" class="btn btn-ghost" data-act="settings">Settings</button>
      </div>
      <p class="tp-rotate">Tip: turn your phone sideways for the full cinematic view.</p>
    </section>

    <section class="tp-screen" data-screen="mode" hidden>
      <button type="button" class="tp-back" data-act="title">← Back</button>
      <h2>How are you playing?</h2>
      <div class="tp-modes">
        <button type="button" class="tp-mode" data-act="coop"><b>Co-op</b><span>Two players, one screen. Each takes a side of the phone, or WASD + arrow keys.</span></button>
        <button type="button" class="tp-mode" data-act="solo"><b>Solo</b><span>One player controls both dogs and swaps between them.</span></button>
        <button type="button" class="tp-mode tp-mode-online" data-act="online"><b>Online <i>new</i></b><span>Each player on their own phone or computer. Team up with anyone on Two Paws right now.</span></button>
      </div>
    </section>

    <section class="tp-screen" data-screen="players" hidden>
      <button type="button" class="tp-back" data-act="mode">← Back</button>
      <p class="tp-kicker" id="tp-mode-label">Co-op</p>
      <h2>Who's playing?</h2>
      <p class="tp-sub">Your scores post to the leaderboard automatically, under your nation and your X accounts.</p>
      <form class="tp-form" id="tp-players" novalidate>
        <div class="tp-field full">
          <label for="tp-team">Nation team</label>
          <select id="tp-team" name="team"><?= $teamOptions() ?></select>
        </div>
        <?php foreach (['p1' => ['Player 1', 'Talking Drum'], 'p2' => ['Player 2', 'Sky Cape']] as $slot => [$lbl, $role]): ?>
          <div class="tp-field tp-x" data-xslot="<?= $slot ?>">
            <label for="tp-<?= $slot ?>"><?= $lbl ?> <small><?= $role ?></small></label>
            <div class="tp-x-row">
              <span class="tp-avatar" aria-hidden="true"></span>
              <span class="tp-at">@</span>
              <input id="tp-<?= $slot ?>" name="<?= $slot ?>" type="text" autocomplete="off" autocapitalize="off" spellcheck="false" maxlength="40" placeholder="X handle">
              <a class="tp-xbtn" href="api/x-auth.php?start=<?= $slot ?>" hidden><?= $xIcon ?> Sign in</a>
            </div>
            <p class="tp-x-who" hidden></p>
          </div>
        <?php endforeach; ?>
        <p class="tp-msg full" id="tp-players-msg" role="status" aria-live="polite"></p>
        <div class="tp-menu row full">
          <button type="submit" class="btn btn-gold">Continue</button>
          <button type="button" class="tp-link" data-act="guest">Play as guest</button>
        </div>
      </form>
    </section>

    <section class="tp-screen" data-screen="pick" hidden>
      <button type="button" class="tp-back" data-act="players">← Back</button>
      <h2>Choose your dogs</h2>
      <p class="tp-who" id="tp-who"></p>
      <div class="tp-slots" role="group" aria-label="Choosing for">
        <button type="button" class="tp-slot p1" data-slot-btn="0" aria-pressed="true"><small>P1 · Talking Drum</small><b data-pick-name="0">Rosé</b></button>
        <button type="button" class="tp-slot p2" data-slot-btn="1" aria-pressed="false"><small>P2 · Sky Cape</small><b data-pick-name="1">Cap'n Jollof</b></button>
      </div>
      <div class="tp-roster" id="tp-roster" data-slot="0"></div>
      <div class="tp-menu row">
        <button type="button" class="btn btn-gold big" data-act="start">Begin the journey</button>
        <button type="button" class="tp-link" data-act="chapters">Practice a chapter</button>
        <p class="tp-wait" id="tp-pick-wait" hidden>Pick your dog. Your partner starts the journey.</p>
      </div>
    </section>

    <section class="tp-screen tp-online" data-screen="online" hidden>
      <button type="button" class="tp-back" data-act="mode">← Back</button>
      <p class="tp-kicker">Online co-op</p>
      <h2>Team up across devices</h2>
      <p class="tp-sub">You appear as <b id="tp-me-name">you</b> · <button type="button" class="tp-link" data-act="players">change</button></p>
      <div class="tp-lobby">
        <h3>Players online <span id="tp-online-count"></span></h3>
        <ul class="tp-lobby-list" id="tp-lobby-list"><li class="tp-lempty">Looking for players…</li></ul>
      </div>
      <div class="tp-codes">
        <div class="tp-code-box"><h3>Invite by code</h3><p class="tp-dim">Make a 4-letter code and send it to a friend.</p><button type="button" class="btn btn-ghost" data-act="create-room">Create a code</button><p class="tp-my-code" id="tp-my-code" hidden></p></div>
        <form class="tp-code-box" id="tp-join-form" novalidate><h3>Got a code?</h3><p class="tp-dim">Type the code your friend sent you.</p><div class="tp-code-row"><input name="code" maxlength="4" autocomplete="off" autocapitalize="characters" spellcheck="false" placeholder="ABCD" aria-label="Room code"><button type="submit" class="btn btn-gold">Join</button></div></form>
      </div>
      <p class="tp-msg" id="tp-net-msg" role="status" aria-live="polite"></p>
    </section>

    <section class="tp-screen tp-link" data-screen="link" hidden>
      <div class="tp-radar" aria-hidden="true"><i></i><i></i><i></i><span>🐾</span></div>
      <h2 id="tp-link-text">Connecting…</h2>
      <p class="tp-big-code" id="tp-link-code" hidden></p>
      <p class="tp-sub">Keep this screen open. You'll both jump to dog selection when you're linked.</p>
      <button type="button" class="tp-link" data-act="cancel-link">Cancel</button>
    </section>

    <section class="tp-screen" data-screen="how" hidden>
      <button type="button" class="tp-back" data-act="back">← Back</button>
      <h2>How to play</h2>
      <div class="tp-how">
        <div><h3 class="p1t">P1 · Drum dog</h3><p><kbd>A</kbd><kbd>D</kbd> move · <kbd>W</kbd> jump · <kbd>S</kbd> power</p><p class="tp-dim">Walks through gold light. Gains the <b>Talking Drum</b> after Chapter 1 (bark to crack stone and beat drums) and <b>Paw Grip</b> after Chapter 3 (wall-jumping).</p></div>
        <div><h3 class="p2t">P2 · Cape dog</h3><p><kbd>←</kbd><kbd>→</kbd> move · <kbd>↑</kbd> jump · hold <kbd>↑</kbd> to glide</p><p class="tp-dim">Walks through teal light, glides over gaps and rides rising wind. Gains <b>Sky Boost</b> after Chapter 2 (tap jump again in mid-air).</p></div>
        <div><h3>Together</h3><p class="tp-dim">Jump on your partner's head to reach high ledges. Plates hold doors and bridges open for the other dog. Both dogs must reach the portal.</p></div>
        <div><h3>On a phone</h3><p class="tp-dim">Same phone: each player takes one side. Online: each player uses their own phone. Tips appear as a small bubble at the top; tap the glowing button to read the last tip again, and tap a skill icon to see what it does.</p></div>
      </div>
    </section>

    <section class="tp-screen" data-screen="chapters" hidden>
      <button type="button" class="tp-back" data-act="back">← Back</button>
      <h2>Practice a chapter</h2>
      <p class="tp-sub">Practice runs aren't posted. Begin the journey to get on the leaderboard.</p>
      <div class="tp-chapters" id="tp-chapters"></div>
    </section>

    <section class="tp-screen tp-intro" data-screen="intro" hidden>
      <p class="tp-kicker" id="tp-intro-sub">Chapter 1</p>
      <h2 class="tp-logo" id="tp-intro-name">Savanna Moon</h2>
    </section>

    <section class="tp-screen" data-screen="pause" hidden>
      <h2>Paused</h2>
      <div class="tp-menu">
        <button type="button" class="btn btn-gold" data-act="resume">Resume</button>
        <button type="button" class="btn btn-ghost" data-guest-hide data-act="restart">Restart chapter</button>
        <button type="button" class="btn btn-ghost" data-act="settings">Settings</button>
        <button type="button" class="btn btn-ghost" data-guest-hide data-act="quit">End run &amp; post score</button>
        <button type="button" class="tp-link" data-act="title">Main menu</button>
      </div>
    </section>

    <section class="tp-screen" data-screen="done" hidden>
      <p class="tp-kicker">Chapter clear</p>
      <h2 id="tp-done-title">Cleared</h2>
      <div class="tp-stats" id="tp-done-stats"></div>
      <div class="tp-unlock" id="tp-unlock" hidden></div>
      <div class="tp-menu"><button type="button" class="btn btn-gold big" id="tp-next">Next chapter</button><p class="tp-wait" id="tp-wait" hidden>Waiting for your partner to continue…</p></div>
    </section>

    <section class="tp-screen tp-over" data-screen="over" hidden>
      <p class="tp-kicker">Journey complete</p>
      <div class="tp-duo" id="tp-duo"></div>
      <p class="tp-score"><b id="tp-final-score">0</b> points</p>
      <div class="tp-stats" id="tp-final-stats"></div>
      <p class="tp-post" id="tp-post-status" role="status" aria-live="polite"></p>
      <form class="tp-form" id="tp-guest-form" hidden novalidate>
        <div class="tp-field full"><label for="tg-team">Nation team</label><select id="tg-team" name="team"><?= $teamOptions() ?></select></div>
        <div class="tp-field" data-xslot="p1"><label for="tg-p1">Player 1 on X</label><div class="tp-x-row"><span class="tp-at">@</span><input id="tg-p1" name="p1" autocomplete="off" autocapitalize="off" placeholder="handle"></div></div>
        <div class="tp-field" data-xslot="p2"><label for="tg-p2">Player 2 on X</label><div class="tp-x-row"><span class="tp-at">@</span><input id="tg-p2" name="p2" autocomplete="off" autocapitalize="off" placeholder="handle"></div></div>
        <div class="tp-menu row full"><button type="submit" class="btn btn-gold">Post score</button></div>
      </form>
      <div class="tp-mini" id="tp-over-board"></div>
      <div class="tp-menu row">
        <button type="button" class="btn btn-gold" data-guest-hide data-act="again">Play again</button>
        <button type="button" class="btn btn-ghost" data-act="board">Leaderboard</button>
        <a class="btn btn-ghost" id="tp-share" href="#" target="_blank" rel="noopener">Share on X</a>
      </div>
      <button type="button" class="tp-link" data-act="title">Main menu</button>
    </section>

    <section class="tp-screen tp-board" data-screen="board" hidden>
      <button type="button" class="tp-back" data-act="back">← Back</button>
      <h2>Which nation plays best together?</h2>
      <p class="tp-sub">Team power is the average of a nation's three best runs. Tap a player to open their X profile. ✓ = signed in with X.</p>
      <div class="lb-tabs" role="tablist">
        <button type="button" role="tab" aria-selected="true" data-lb-tab="teams">Nation teams</button>
        <button type="button" role="tab" aria-selected="false" data-lb-tab="runs">Top duos</button>
      </div>
      <div id="tp-board-body"></div>
    </section>

    <section class="tp-screen tp-settings" data-screen="settings" hidden>
      <button type="button" class="tp-back" data-act="back">← Back</button>
      <h2>Settings</h2>
      <form id="tp-settings" class="tp-set" onsubmit="return false">
        <fieldset><legend>Feel</legend>
          <label class="tp-tog"><span><b>Calm mode</b><small>Gentle camera, softer sounds, no shaking</small></span><input type="checkbox" data-set="calm"><i></i></label>
          <label class="tp-tog"><span><b>Cinematic</b><small>Letterbox intros, slow-motion finishes, film grain</small></span><input type="checkbox" data-set="cinema"><i></i></label>
          <label class="tp-tog"><span><b>Screen shake</b><small>On barks and falls</small></span><input type="checkbox" data-set="shake"><i></i></label>
          <label class="tp-tog"><span><b>Hints</b><small>Short tips as you reach each puzzle</small></span><input type="checkbox" data-set="hints"><i></i></label>
        </fieldset>
        <fieldset><legend>Sound</legend>
          <label class="tp-range"><span>Music</span><input type="range" min="0" max="100" data-set="music"></label>
          <label class="tp-range"><span>Effects</span><input type="range" min="0" max="100" data-set="sfx"></label>
        </fieldset>
        <fieldset><legend>Touch controls</legend>
          <label class="tp-sel"><span>Button size</span><select data-set="touchSize"><option value="s">Small</option><option value="m">Medium</option><option value="l">Large</option></select></label>
          <label class="tp-range"><span>Visibility</span><input type="range" min="30" max="100" data-set="touchAlpha"></label>
          <label class="tp-tog"><span><b>Left-handed (solo)</b><small>Swap move and action buttons</small></span><input type="checkbox" data-set="lefty"><i></i></label>
          <label class="tp-tog"><span><b>Vibration</b><small>Tiny buzz on barks and falls</small></span><input type="checkbox" data-set="haptics"><i></i></label>
        </fieldset>
        <fieldset><legend>Graphics</legend>
          <label class="tp-sel"><span>Quality</span><select data-set="quality"><option value="hd">HD (sharpest)</option><option value="eco">Battery saver</option></select></label>
        </fieldset>
        <button type="button" class="tp-link" data-act="reset-settings">Reset to defaults</button>
      </form>
    </section>
  </div>
</div>

<script src="assets/js/doa.js?v=2" defer></script>
<script src="assets/js/levels.js?v=2" defer></script>
<script src="assets/js/game.js?v=3" defer></script>
</body>
</html>
