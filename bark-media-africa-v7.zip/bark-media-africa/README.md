# Bark Media Africa — community website

Multi-page PHP site with three.js 3D scenes, a newsletter, and email alerts when someone joins.
Runs on any PHP 7.4+ shared host (cPanel, Hostinger, Namecheap). No database, no Composer.

## 1. Set your email (required)

Open `includes/config.php`:

| Setting | What to put |
|---|---|
| `ADMIN_EMAIL` | The inbox that should receive new member and subscriber alerts |
| `SMTP_HOST`, `SMTP_PORT`, `SMTP_SECURE` | Your mail server. cPanel: `mail.yourdomain.com`, 465, `ssl`. Gmail: `smtp.gmail.com`, 587, `tls` |
| `SMTP_USER`, `SMTP_PASS` | Mailbox login. For Gmail use an App Password, not your normal password |
| `MAIL_FROM` | Must be the same mailbox as `SMTP_USER` on most hosts |
| `SEND_CONFIRMATIONS` | `true` also emails the new member/subscriber a welcome message |

Leave `SMTP_HOST` empty to fall back to PHP `mail()` (less reliable, often lands in spam).

## 2. Turn on the shop (Paystack)

1. Log in at dashboard.paystack.com > Settings > API Keys & Webhooks.
2. Copy the **test** secret and public keys into `PAYSTACK_SECRET_KEY` / `PAYSTACK_PUBLIC_KEY` in `includes/config.php`.
3. Set the **Webhook URL** to `https://yourdomain.com/api/paystack-webhook.php`. This confirms orders even if a buyer closes the tab before returning to the site.
4. Set `ADMIN_PASSWORD`, then place a test order with Paystack's test card (4084 0840 8408 4081, any future date, CVV 408, OTP 123456).
5. When that works, swap in the **live** keys.

Your server needs PHP's cURL extension (on by default on almost every host).

### How a sale works
1. Visitors add items to the cart (kept in their browser, synced across tabs).
2. At checkout, `api/checkout.php` re-prices every item from `includes/products.php`, so nobody can change prices in the browser, saves a pending order in `storage/orders/`, and opens Paystack's secure payment page (card, bank transfer, USSD).
3. Paystack sends the buyer back to `order-complete.php`, which **verifies the payment with Paystack's API** and checks the amount and currency before marking it paid. The webhook does the same thing in the background; whichever arrives first wins, and emails go out only once.
4. You get an email with the items, sizes, colours, phone number and delivery address. The buyer gets a receipt.
5. Manage orders at `/admin/orders.php`: see revenue, filter to "To ship", tap a phone number to open WhatsApp, and mark orders as shipped. Paid orders are also logged to `storage/orders.csv`.

### Editing products
Everything is in `includes/products.php`: name, price (in naira), description, colours and sizes. Prices there are placeholders.
Product images are drawn by `art.php` with the BMA logo on them, so every colour option has its own picture. When you have real product photos, add `'photo' => 'assets/images/shop/tee.jpg'` to a product and that photo is used instead.
Delivery options and fees are in `$SHIPPING` in the same file.

## 3. Upload

Upload everything to `public_html/`. Make sure `storage/` is writable (755 or 775).

## What happens on submit

**Join form** (`join.php` → `api/join.php`)
1. Validates the email and name, checks the CSRF token, blocks bots (honeypot) and floods (3 per 15 min).
2. Saves the member to `storage/members.csv` (so nobody is lost if email fails).
3. Emails **you** the member's name, email, Telegram/X handle, country, interest, message and join time. Hit Reply to answer them directly.
4. Sends the member a welcome email (if enabled).
5. If they ticked the newsletter box, adds them to `storage/subscribers.csv`.

**Newsletter** (footer on every page + home/events band → `api/subscribe.php`)
Saves to `storage/subscribers.csv`, skips duplicates, emails you, sends a welcome email.
To send newsletters, import the CSV into Mailchimp, Brevo or MailerLite, or add their API call where marked in `api/subscribe.php`.

Both forms work without JavaScript too (they post normally and redirect back).

## 3D scenes (`assets/js/scene3d.js`)

- **Home hero**: spinning gold BMA coin (paw + "Bark Media Africa" edge text, Ubuntu/Harambee/Sankofa on the back), kente-coloured orbit rings, a particle disc and floating crystals. Follows the mouse, flips as you scroll.
- **Home "nations" section**: dotted globe with Africa lit in gold, a pin per country (height = member count) and arcs flowing out from Abuja. Drag to spin. Built from the `$NATIONS` lat/lng in `includes/data.php`.
- **Inner page banners**: floating gold coins.
- **Shop hero**: a spinning branded water bottle with the kente band, a gold coin and floating stickers.

## Homepage sections
Hero (3D coin, counting stats) → live crypto price ticker (DOGE, BTC, ETH, SOL from CoinGecko, falls back to community news) → last 24h Spaces → "Your path into Web3" steps (the line draws as you scroll) → services (3D tilt) → "Inside the pack" gallery (parallax) → nations globe → "Rep the pack" shop rail → member quotes marquee → recent events → values → newsletter → join CTA.
The member quotes and gallery posters are **samples**: replace them with real quotes and event photos in `$VOICES` and `$GALLERY` in `includes/data.php` (drop photos in `assets/images/gallery/`).

three.js is bundled in `assets/vendor/three/` (no CDN needed). Scenes pause when off screen, render one still frame for people with reduced-motion turned on, and fall back to a plain gradient if WebGL is unavailable.

## Editing content

All text lives in `includes/data.php`: services, offers, nations, values, milestones, events, Spaces and FAQ.
Spaces use `hours_from_now()` for the demo; swap in real times like `'start' => '2026-10-10T19:00:00+01:00'`.

## Files

```
index.php  about.php  services.php  events.php  spaces.php  join.php  404.php
shop.php  product.php  checkout.php  order-complete.php
art.php                 product images (SVG with logo)
admin/orders.php        orders dashboard (password)
api/checkout.php        creates order + starts Paystack payment
api/paystack-webhook.php  Paystack confirms payments here
includes/products.php   ← products, prices, delivery fees
includes/orders.php     order storage, Paystack verify, order emails
assets/js/shop.js       cart drawer, product options, checkout
api/join.php            join form handler + admin email
api/subscribe.php       newsletter handler
includes/config.php     ← edit first
includes/data.php       content
includes/header.php / footer.php / components.php / functions.php / mailer.php
lib/                    PHPMailer 6.9.1
assets/css/style.css
assets/js/main.js       menu, greeting, tilt cards, AJAX forms
assets/js/scene3d.js    3D scenes
storage/                CSV backups + orders/ (web access blocked by .htaccess)
```

Still to confirm from the client: real contact email, Telegram link, and real event entries.

---

## Partner page, Sniff chat guide and events pop-up
New files are listed below. `includes/header.php` and `includes/footer.php` were also updated to add the Partner link, the new stylesheet, and the chat + pop-up. Nothing in `includes/config.php` has to change.

| File | What it is |
|---|---|
| `partner.php` | The Partner With Us page and investor form |
| `api/partner.php` | Saves the enquiry to `storage/partners.csv`, emails your team, emails the investor a confirmation |
| `includes/partner_data.php` | The form options (investor types, budgets, interests) and the four "where support goes" cards |
| `includes/assistant.php` | Builds Sniff's knowledge from `data.php` / `products.php` and prints the chat + pop-up |
| `api/chat.php` | Optional AI mode for Sniff (see below) |
| `assets/js/assistant.js`, `assets/js/partner.js` | Chat + pop-up logic, form behaviour |
| `assets/css/extras.css` | Styles for all of the above, plus small-phone fixes for the footer and nav |

### Testing the investor emails
Add `define('DEBUG_MAIL', true);` to `includes/config.php`, submit the form, and any mail error is shown in the response.
Remove it (or set it to `false`) before going live. Enquiries are saved to `storage/partners.csv` even if email fails.

### Sniff, the chat guide
Works out of the box: it answers from your site data (events, nations, shop, shipping, FAQ), so it stays up to date when you edit `data.php`.
Edit the replies in `assets/js/assistant.js` (the `INTENTS` list).

Optional AI mode: add `define('CHATBOT_API_KEY', 'your-anthropic-api-key');` to `includes/config.php`.
Questions Sniff can't answer itself then go to `api/chat.php`, which answers only from your site facts. The key stays on the server.
If the key is missing or the call fails, Sniff falls back to the built-in answers.

### Events pop-up
Appears once per visit, 10 seconds after the visitor starts scrolling. It shows the next upcoming item from `$EVENTS` in `data.php`
(or a generic "Stay tuned" if none are dated in the future). Add `?cta=1` to any page URL to preview it again.


---

## v4: Afro-Cosmos redesign, Web3 Hub and the Two Paws game

### Look and feel
- `assets/css/cosmos.css` turns every page into one cinematic night sky. The brand indigo + gold stay; added a pan-African palette (terracotta, malachite, Ndebele sky and rose, baobab, clay), bogolan (mudcloth) patterns, animated kente strips and Adinkra symbols (`adinkra()` in `includes/components.php`).
- `assets/js/cosmos.js` draws the sky behind every page: nebula, parallax stars, shooting stars, a kente-ringed planet with Ndebele bands, and a constellation of African capitals networked together (BMA nations glow gold, data packets travel the links).
- Seamless navigation: kente-shutter page transitions, smooth wheel scrolling on desktop (touch stays native), a kente progress line under the header, and cinematic reveals. All of it switches off for people with "reduce motion" turned on.

### Web3 Hub (`web3.php`, `assets/js/web3.js`, `api/vote.php`)
- Connect **MyDoge** (Dogecoin) or **MetaMask/EVM**, or watch any Dogecoin address. Read-only: balance via BlockCypher, price via CoinGecko.
- **Chain pulse**: live Dogecoin block height, last block time, mempool and DOGE price.
- **Find your chapter**: nation chapters with member counts, a join link per chapter and a ready-made "say hi on X" post. Nothing is minted or sold; it's about real connections.
- **Pack Council**: votes on `$PROPOSALS` in `includes/data.php`. With a wallet connected, the vote is signed (no transaction) and counts once per wallet; signatures are stored for audit. Without a wallet it counts once per browser session.
- **Scam check** for links + safety rules.

### Two Paws game (`game.php`)
- Co-op platformer in the spirit of "It Takes Two": P1 carries the Talking Drum (bark breaks cracked stone and beats drums that raise sky bridges), P2 wears the Sky Cape (glide, ride rising wind). Stacking, hold-the-door plates, colour gates and latch gates mean neither dog can finish alone.
- The cast (Rosé, Cap'n Jollof, Prism, The Chairman) are full-body pixel characters built from the community PFPs in `assets/js/doa.js`. They are drawn in code, so they run, jump, squash and stretch, and stay crisp on any screen.
- Play: same-device co-op (keyboard W A S D + arrows, touch pads on phones, or two gamepads), or solo with a swap button. Four chapters in `assets/js/levels.js` (tile key at the top of that file).
- **Leaderboard** (`api/leaderboard.php`): the score is recomputed on the server. Nation teams are ranked by the average of their three best runs. Every duo links to the players' X profiles.

### Connect players' X accounts (optional, recommended)
Players can always type their @handle (shown with their X avatar). To let them **Sign in with X** for a verified ✓:
1. developer.x.com > Projects & Apps > your app > User authentication settings > OAuth 2.0, type "Web App".
2. Callback URL: `https://yourdomain.com/api/x-auth.php`. Website URL: your domain.
3. Paste the OAuth 2.0 Client ID and Client Secret into `X_CLIENT_ID` / `X_CLIENT_SECRET` in `includes/config.php`.
Only the public profile is read (`users.read`). Nothing is ever posted for the player.

### News
`$NEWS` in `includes/data.php` holds the latest Doginal Dogs ecosystem headlines with sources. The homepage also embeds the live @barkmediaafrica timeline from X, so new posts appear automatically. Add your own BMA announcements to `$NEWS` and real Spaces to `$EVENTS` / `$SPACES`.

### Data files
Leaderboard and votes are saved as `storage/leaderboard.data.php` and `storage/votes.data.php`. They start with an exit guard, so they stay private even on hosts that ignore `.htaccess`.


---

## v5: classic header, community-first Web3 Hub, standalone game

### Navigation
- The header now has six items with dropdowns: Home · Community ▾ · Services ▾ · Web3 ▾ · Play ▾ · Shop, plus "Join the community". Each dropdown link has a one-line description. On phones it becomes an accordion that opens the section you're in.
- Edit the menu in one place: `$MENU` in `includes/config.php`. The footer sitemap and the breadcrumbs (Home › Community › Events) are built from the same list.
- A back-to-top button appears on long pages.
- The multi-coloured page-change curtain is gone. Browsers that support it get a quiet cross-fade instead.

### Web3 Hub
- The Pack Passport is removed. Nothing is minted or sold on the site.
- New "Find your chapter" section (`web3.php#network`): every nation chapter with member counts, a "Join this chapter" link (pre-fills the country on the join form) and a ready-made "Say hi on X" post. Chapter data comes from `$NATIONS` in `includes/data.php`.

### Two Paws is now its own full-screen app (`game.php`)
- No site header, footer or chat button. A small "← Bark Media Africa" link on the title screen leads back to the site. Players can also "Add to Home Screen" (`game.webmanifest`).
- Flow: Play → Co-op / Solo → **Who's playing** (nation team + each player's X handle, or Sign in with X, or play as guest) → choose dogs → play. The players are remembered on that device.
- At the end of a run the score **posts automatically** to the leaderboard under the team and X handles, then shows your rank, your team's rank and the top duos. Guests get a one-step form to add names and post.
- The leaderboard lives inside the game (title menu, and after every run). `game.php#board` opens it directly.
- Calm, cinematic settings (saved per device): Calm mode, Cinematic (letterbox fly-through intro for each chapter, slow-motion finish, film grain), screen shake, hints, music and effects volume, touch button size and visibility, left-handed solo layout, vibration, HD or battery-saver graphics.
- Music is a calm ambient pad with mbira (thumb piano) notes in a different key for each chapter.
- Styles: `assets/css/game-app.css`. Engine and menus: `assets/js/game.js`.


---

## v7: Web3 Academy, events, game skills, tips and online co-op

### Web3 Academy (`academy.php`, under Web3 in the menu)
- Built from the "Web3 Made Simple" syllabus (both PDFs) and the beginner study guide. Duplicates were merged so each fact appears once.
- Sections: about the Academy, learning outcomes, 12 modules (tap a card to open notes with key terms, explanation, example, "remember" and the practical activity; swipe between modules on phones; "Mark as done" saves progress on the device), how to study (30-minute lesson + 6-week plan), searchable glossary, comparisons, six safety rules, a 10-question quiz with explanations, short-answer practice, graduation weights + checklist, resources.
- All text is in `includes/academy_data.php`; module pictures are in `assets/images/academy/`.

### Events
- The site now uses **@Barkmediafrica** (`includes/config.php`).
- Events page has "Coming up": any `$EVENTS` entry with a future date appears there first (and in the site pop-up), plus the weekly fixtures in `$REGULAR`, plus the live X feed.

### Two Paws: skills, Chapter 2, tips, online
- Skills unlock as you progress: start with jump, Pack Lift and the Sky Cape glide; clear Chapter 1 → **Talking Drum** (bark); clear Chapter 2 → **Sky Boost** (Cape dog's mid-air second jump); clear Chapter 3 → **Paw Grip** (Drum dog wall-jump). Each new skill gets an unlock card and a skill icon in the HUD (tap it to see what it does).
- **Chapter 2 (Kente Nebula)** is the new medium stage: crack stone, lift to the drum, race the sky bridge, ride the wind to open a gate, hold the door, glide-ride-raise a bridge, then latch the great gate together.
- Chapter 3 needs Sky Boost to reach the high lane; the finale has a Paw Grip wall-jump shaft.
- **Tips** are a small bubble at the top that folds into a glowing button (tap to reread). Little icons float over plates, cracked stone, wind and gates as you get close. Turn both off in Settings → Hints.
- **Online co-op**: choose Online, then tap "Team up" next to anyone in the lobby or share a 4-letter room code. Devices connect directly (WebRTC); `api/room.php` only passes the handshake, so it runs on normal PHP hosting. Most home and mobile networks work; a few strict networks block device-to-device connections and the game says so.
