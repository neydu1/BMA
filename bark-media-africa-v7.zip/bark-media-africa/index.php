<?php
$pageTitle = 'Bark Media Africa';
$bodyClass = 'home';
require __DIR__ . '/includes/header.php';

$recent = array_values(array_filter($SPACES, fn($s) => in_array(space_status($s), ['live', 'recent'])));
usort($recent, fn($a, $b) => strtotime($b['start']) - strtotime($a['start']));
$recent = array_slice($recent, 0, 3);
$live = array_values(array_filter($SPACES, fn($s) => space_status($s) === 'live'));
$maxM = max(array_column($NATIONS, 'members'));

$globeData = array_map(fn($n) => ['name' => $n['name'], 'lat' => $n['lat'], 'lng' => $n['lng'], 'members' => $n['members']], $NATIONS);
$extraScripts = '<script>window.BMA_NATIONS=' . json_encode($globeData) . ';</script><script src="assets/js/doa.js?v=1" defer></script><script src="assets/js/leaderboard.js?v=1" defer></script><script src="assets/js/home.js?v=1" defer></script>';
?>

<section class="hero">
  <canvas id="hero3d" aria-hidden="true"></canvas>
  <div class="hero-glow" aria-hidden="true"></div>
  <div class="wrap hero-inner">
    <div class="hero-copy">
      <p class="greeting" id="greeting" aria-live="polite" data-greetings='<?= e(json_encode($GREETINGS, JSON_UNESCAPED_UNICODE)) ?>'>
        <span class="g-word">Welcome</span> <span class="g-lang">English</span>
      </p>
      <h1>Africa's voice in Web3, live on X every week.</h1>
      <p class="lede">Bark Media Africa is the African chapter of the DoginalDogs community. We host Spaces, onboard newcomers to crypto, and train members to grow real accounts for real projects.</p>
      <div class="btn-row">
        <a class="btn btn-gold" href="join.php">Join the community</a>
        <a class="btn btn-ghost" href="spaces.php">See today's Spaces</a>
      </div>
      <dl class="stat-line">
        <?php foreach ($SITE['stats'] as $s): ?>
          <div><dt><?= e($s['label']) ?></dt><dd data-count="<?= e($s['value']) ?>"><?= e($s['value']) ?></dd></div>
        <?php endforeach; ?>
      </dl>
    </div>
    <?php if ($live): ?>
      <a class="live-pill" href="spaces.php"><span class="dot"></span>Live now: <?= e($live[0]['title']) ?></a>
    <?php endif; ?>
  </div>
  <a class="scroll-cue" href="#last24" aria-label="Scroll to recent Spaces"><span></span></a>
</section>
<div class="kente" aria-hidden="true"></div>
<div class="ticker" aria-label="Live crypto prices and community news">
  <div class="ticker-track" id="ticker-track">
    <span class="tk">Weekly Pan-African stage, every week on X</span>
    <span class="tk">250+ members across 6 nations</span>
    <span class="tk">Country leads wanted in Kenya, Egypt and Rwanda</span>
    <span class="tk">New: BMA swag shop is open</span>
  </div>
</div>

<section class="section" id="last24">
  <div class="wrap">
    <div class="section-head" data-reveal>
      <h2>In the last 24 hours</h2>
      <p class="muted">Spaces we hosted or joined since yesterday. Missed one? Most have a recording.</p>
    </div>
    <div class="grid g-3">
      <?php if ($recent): foreach ($recent as $s) echo space_card($s); else: ?>
        <div class="empty">No Spaces in the last 24 hours. <a href="<?= e($SITE['xUrl']) ?>" target="_blank" rel="noopener">Follow <?= e($SITE['handle']) ?></a> to catch the next one.</div>
      <?php endif; ?>
    </div>
    <p class="more"><a class="text-link" href="spaces.php">All Spaces from today</a></p>
  </div>
</section>

<section class="section timeline-news" id="fresh">
  <div class="wrap">
    <div class="section-head">
      <p class="eyebrow">Fresh from the timeline</p>
      <h2>What's moving in the Doginal Dogs world</h2>
      <p class="muted">The latest from the wider pack, and our own posts live from X.</p>
    </div>
    <div class="nw-grid">
      <div class="nw-list">
        <?php foreach ($NEWS as $n): $d = strtotime($n['date']); ?>
          <a class="nw-card" href="<?= e($n['url']) ?>" target="_blank" rel="noopener">
            <span class="nw-date"><b><?= date('j', $d) ?></b><?= date('M', $d) ?></span>
            <span><span class="tag"><?= e($n['tag']) ?></span><h3><?= e($n['title']) ?></h3><p><?= e($n['body']) ?></p><span class="nw-src">Source: <?= e($n['source']) ?> ↗</span></span>
          </a>
        <?php endforeach; ?>
      </div>
      <div class="x-embed" id="x-embed" data-handle="<?= e(ltrim($SITE['handle'], '@')) ?>">
        <a class="twitter-timeline" data-theme="dark" data-chrome="noheader nofooter transparent" data-height="640" href="https://twitter.com/<?= e(ltrim($SITE['handle'], '@')) ?>?ref_src=twsrc%5Etfw">Posts by <?= e($SITE['handle']) ?></a>
        <div class="x-fallback"><div><p>Live posts from <?= e($SITE['handle']) ?> load here.</p><a class="btn btn-gold" href="<?= e($SITE['xUrl']) ?>" target="_blank" rel="noopener">Open <?= e($SITE['handle']) ?> on X</a></div></div>
      </div>
    </div>
  </div>
</section>

<section class="section features" id="new">
  <div class="wrap">
    <div class="section-head">
      <p class="eyebrow">New on the site</p>
      <h2>Play together. Build on-chain.</h2>
    </div>
    <div class="feature-duo">
      <a class="feature feature-game" href="game.php">
        <div class="feature-art"><canvas id="feat-dogs" width="640" height="300" aria-hidden="true"></canvas></div>
        <span class="tag">BMA Arcade</span>
        <h3>Two Paws: it takes the pack</h3>
        <p>A co-op platformer starring the Dogs of Africa. Play on one screen or team up online from two phones, and unlock new skills each chapter. Top nations right now:</p>
        <ol class="mini-lb" data-mini-board><li><span>Loading…</span><b></b></li></ol>
        <span class="btn btn-gold">Play now</span>
      </a>
      <a class="feature feature-web3" href="web3.php">
        <div class="feature-art"><canvas id="feat-net" width="640" height="300" aria-hidden="true"></canvas></div>
        <span class="tag">Web3 Hub</span>
        <h3>Your wallet, your chapter, your vote</h3>
        <div class="pulse-row"><span class="pulse">Dogecoin block <b data-home-pulse="height">…</b></span><span class="pulse">DOGE <b data-home-pulse="price">…</b></span></div>
        <p>Connect MyDoge or MetaMask, find members in your nation, and sign your vote in the Pack Council.</p>
        <span class="btn btn-ghost">Open the hub</span>
      </a>
    </div>
  </div>
</section>

<section class="section path">
  <div class="wrap">
    <div class="section-head" data-reveal>
      <h2>Your path into Web3</h2>
      <p class="muted">Most members start knowing nothing about crypto. Here's how it usually goes.</p>
    </div>
    <div class="steps-wrap" id="steps">
    <svg class="steps-line" viewBox="0 0 1000 20" preserveAspectRatio="none" aria-hidden="true"><path d="M60 10 H940" pathLength="1"/></svg>
    <ol class="steps">
      <?php foreach ($STEPS as $i => $st): ?>
        <li data-reveal style="--d:<?= $i * 120 ?>ms">
          <div class="step-icon"><?= step_icon($st['icon']) ?><span class="step-n"><?= $i + 1 ?></span></div>
          <h3><?= e($st['title']) ?></h3>
          <p class="muted"><?= e($st['body']) ?></p>
        </li>
      <?php endforeach; ?>
    </ol>
    </div>
  </div>
</section>

<section class="section services-home">
  <div class="wrap">
    <div class="section-head" data-reveal>
      <h2>What we do for members and projects</h2>
      <p class="muted">Each service carries an Adinkra symbol that says what we stand for while doing it.</p>
    </div>
    <div class="grid g-4">
      <?php foreach ($SERVICES as $s): ?>
        <article class="tilt-card" data-tilt>
          <div class="tilt-inner">
            <span class="symbol"><?= adinkra($s['symbol']) ?><?= e($s['symbol']) ?><i><?= e($s['meaning']) ?></i></span>
            <h3><?= e($s['title']) ?></h3>
            <p class="summary"><?= e($s['summary']) ?></p>
            <p class="muted"><?= e($s['body']) ?></p>
          </div>
        </article>
      <?php endforeach; ?>
    </div>
    <p class="more"><a class="text-link" href="services.php">See services and pricing questions</a></p>
  </div>
</section>

<section class="section gallery-sec">
  <div class="wrap">
    <div class="gallery-head" data-reveal>
      <h2>Inside the pack</h2>
      <p class="muted">Spaces, clinics and meetups from across the continent.</p>
    </div>
    <div class="gallery">
      <?php foreach ($GALLERY as $i => $g): ?>
        <figure class="g-tile <?= e($g['size'] ?? '') ?> <?= $g['src'] ? '' : 'poster tone-' . e($g['tone'] ?? 'gold') ?>" data-reveal style="--d:<?= ($i % 3) * 90 ?>ms">
          <?php if ($g['src']): ?>
            <img src="<?= e($g['src']) ?>" alt="<?= e($g['caption']) ?>" loading="lazy" data-parallax="<?= $i % 2 ? '.06' : '-.06' ?>">
            <figcaption><?= e($g['caption']) ?></figcaption>
          <?php else: ?>
            <div class="poster-art" aria-hidden="true"><img src="<?= e($SITE['logo']) ?>" alt=""></div>
            <figcaption><b><?= e($g['caption']) ?></b><span><?= e($g['meta'] ?? '') ?></span></figcaption>
          <?php endif; ?>
        </figure>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<section class="section nations">
  <div class="wrap nations-grid">
    <div class="globe-wrap">
      <canvas id="globe3d" aria-label="Rotating globe with BMA member locations across Africa" role="img"></canvas>
      <p class="globe-hint">Drag to spin</p>
    </div>
    <div>
      <h2>One pack, six nations and counting</h2>
      <p class="muted">Members by country. We're recruiting country leads to open chapters in Kenya, Egypt, Rwanda and beyond.</p>
      <ul class="nation-list">
        <?php foreach ($NATIONS as $n): ?>
          <li>
            <span class="flag" aria-hidden="true"><?= $n['flag'] ?></span>
            <div class="n-body">
              <div class="n-top"><b><?= e($n['name']) ?></b><span><?= $n['members'] ?> members</span></div>
              <div class="bar"><i style="--w:<?= round($n['members'] / $maxM * 100) ?>%"></i></div>
              <small class="muted"><?= e($n['cities']) ?></small>
            </div>
          </li>
        <?php endforeach; ?>
      </ul>
      <a class="btn btn-ghost-dark" href="join.php?focus=Becoming+a+country+lead">Lead your country</a>
    </div>
  </div>
</section>

<section class="section shop-band">
  <div class="wrap">
    <div class="shop-band-head" data-reveal>
      <div>
        <h2>Rep the pack</h2>
        <p>Tees, hoodies, bottles and caps with the BMA mark. Pay with Paystack, delivered across Nigeria.</p>
      </div>
      <a class="btn btn-gold" href="shop.php">Visit the shop</a>
    </div>
    <div class="shop-rail">
      <?php foreach (array_slice(array_keys($PRODUCTS), 0, 4) as $i => $slug): $p = $PRODUCTS[$slug]; ?>
        <a class="rail-item" href="product.php?item=<?= e($slug) ?>" data-reveal style="--d:<?= $i * 100 ?>ms">
          <span class="rail-img" style="--f:<?= $i ?>"><img src="<?= e(product_img($slug)) ?>" alt="" loading="lazy" width="600" height="600"></span>
          <span class="rail-name"><?= e($p['name']) ?></span>
          <span class="rail-price"><?= money($p['price']) ?></span>
        </a>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<section class="section voices">
  <div class="wrap section-head" data-reveal>
    <h2>What members say</h2>
  </div>
  <div class="marquee" aria-label="Member quotes">
    <div class="marquee-track">
      <?php foreach (array_merge($VOICES, $VOICES) as $i => $v): ?>
        <blockquote class="voice" <?= $i >= count($VOICES) ? 'aria-hidden="true"' : '' ?>>
          <p><?= e($v['quote']) ?></p>
          <footer><span class="avatar" aria-hidden="true"><?= e(mb_substr($v['name'], 0, 1)) ?></span><span><b><?= e($v['name']) ?></b><small><?= e($v['tag']) ?></small></span></footer>
        </blockquote>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<section class="section events-teaser">
  <div class="wrap">
    <div class="section-head" data-reveal><h2>Recently on the timeline</h2></div>
    <div class="grid g-2">
      <?php $evs = $EVENTS; usort($evs, fn($a, $b) => strtotime($b['date']) - strtotime($a['date']));
      foreach (array_slice($evs, 0, 2) as $i => $ev): $d = strtotime($ev['date']); ?>
        <a class="ev-card" href="events.php" data-reveal style="--d:<?= $i * 120 ?>ms">
          <time datetime="<?= e($ev['date']) ?>"><b><?= date('j', $d) ?></b><?= date('M', $d) ?></time>
          <span><span class="tag"><?= e($ev['type']) ?></span><h3><?= e($ev['title']) ?></h3><span class="muted"><?= e($ev['summary']) ?></span></span>
        </a>
      <?php endforeach; ?>
    </div>
    <p class="more"><a class="text-link" href="events.php">See all events</a></p>
  </div>
</section>

<section class="section values-band">
  <div class="wrap">
    <h2 class="sr">What we believe</h2>
    <div class="grid g-3">
      <?php foreach ($VALUES as $v): ?>
        <div class="value">
          <h3><?= e($v['title']) ?></h3>
          <p class="meaning"><?= e($v['meaning']) ?></p>
          <p><?= e($v['body']) ?></p>
        </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<?= newsletter_block('home') ?>
<?= join_cta() ?>

<?php require __DIR__ . '/includes/footer.php'; ?>
