<?php
$pageTitle = 'Web3 Hub';
$pageDesc = 'Connect a Dogecoin or EVM wallet, watch the Dogecoin chain live, find your nation chapter and vote in the BMA Pack Council.';
$extraHead = '<link rel="stylesheet" href="assets/css/academy.css?v=1">';
require __DIR__ . '/includes/header.php';
$extraScripts = '<script src="assets/js/web3.js?v=2" defer></script>';
?>
<?= page_banner('The Web3 Hub', 'Wallet tools, live Dogecoin data, your nation chapter and community votes. Built by the community, for real connections.') ?>

<section class="section w3" id="wallet">
  <div class="wrap">
    <div class="w3-grid">
      <!-- wallet -->
      <article class="w3-card w3-wallet">
        <p class="eyebrow">Your wallet</p>
        <h2>Connect, or just watch</h2>
        <p class="muted">Read-only. We never ask for a seed phrase and we never move funds. Signing is only used to prove a vote is yours.</p>
        <div class="w3-connect" data-w3="buttons">
          <button type="button" class="btn btn-gold" data-connect="doge">MyDoge wallet</button>
          <button type="button" class="btn btn-ghost" data-connect="evm">MetaMask / EVM</button>
        </div>
        <form class="w3-watch" data-w3="watch">
          <label class="sr" for="w3-addr">Dogecoin address</label>
          <input id="w3-addr" name="addr" type="text" placeholder="Or paste a Dogecoin address (D…)" autocomplete="off" spellcheck="false">
          <button class="btn btn-small" type="submit">Watch</button>
        </form>
        <div class="w3-account" data-w3="account" hidden>
          <div class="w3-addr-row"><span class="w3-dot"></span><code data-w3="addr"></code><button type="button" class="tp-link" data-w3="disconnect">Disconnect</button></div>
          <dl class="w3-bal">
            <div><dt>Balance</dt><dd data-w3="bal">…</dd></div>
            <div><dt>Value</dt><dd data-w3="usd">…</dd></div>
          </dl>
          <div class="w3-links" data-w3="links"></div>
        </div>
        <p class="form-msg" data-w3="msg" role="status" aria-live="polite"></p>
      </article>

      <!-- chain pulse -->
      <article class="w3-card w3-pulse">
        <p class="eyebrow">Dogecoin, live</p>
        <h2>Chain pulse</h2>
        <dl class="w3-stats">
          <div><dt>Block height</dt><dd data-pulse="height">…</dd></div>
          <div><dt>Last block</dt><dd data-pulse="ago">…</dd></div>
          <div><dt>Waiting txs</dt><dd data-pulse="mempool">…</dd></div>
          <div><dt>DOGE / USD</dt><dd data-pulse="price">…</dd></div>
        </dl>
        <div class="w3-beat" aria-hidden="true"><?php for ($i = 0; $i < 32; $i++) echo '<i style="--i:' . $i . '"></i>'; ?></div>
        <p class="muted small" data-pulse="since">Blocks land about once a minute. This page counts the ones you witness.</p>
      </article>
    </div>
  </div>
</section>

<section class="section" id="academy">
  <div class="wrap">
    <div class="w3-academy">
      <img src="assets/images/academy/cover.jpg" alt="Web3 Made Simple course illustrations" width="900" height="910" loading="lazy">
      <div>
        <p class="eyebrow">New · Web3 Academy</p>
        <h2>Web3 Made Simple</h2>
        <p class="muted">Our free beginner course: 12 short modules from "what is a blockchain?" to your first Web3 project. Plain language, practical tasks, safety first.</p>
        <ul><li>Wallets, seed phrases and staying safe</li><li>Coins, tokens, NFTs, DeFi and smart contracts</li><li>Web3 careers, quizzes and a graduation project</li></ul>
        <a class="btn btn-gold" href="academy.php">Start learning</a>
      </div>
    </div>
  </div>
</section>

<section class="section w3-network" id="network">
  <div class="wrap">
    <div class="section-head">
      <p class="eyebrow">Community driven</p>
      <h2>Find your chapter</h2>
      <p class="muted">BMA grows one real connection at a time. Meet members in your nation, show up to a Space, and help the next person in. No bots, no follow-for-follow, nothing to buy.</p>
    </div>
    <div class="net-grid">
      <?php $maxM = max(array_column($NATIONS, 'members')); foreach ($NATIONS as $n): ?>
        <article class="net-card">
          <div class="net-top"><span class="net-flag" aria-hidden="true"><?= $n['flag'] ?></span><div><h3><?= e($n['name']) ?></h3><p class="muted small"><?= e($n['cities']) ?></p></div><span class="net-count"><b><?= (int) $n['members'] ?></b>members</span></div>
          <div class="bar"><i style="--w:<?= round($n['members'] / $maxM * 100) ?>%; width: var(--w)"></i></div>
          <div class="net-actions">
            <a class="btn btn-small" href="join.php?country=<?= urlencode($n['name']) ?>">Join this chapter</a>
            <a class="text-link" href="https://x.com/intent/post?text=<?= rawurlencode("Hi pack 👋 I'm in " . explode(',', $n['cities'])[0] . ", " . $n['name'] . " and want to connect with Web3 builders here. " . $SITE['handle']) ?>" target="_blank" rel="noopener">Say hi on X</a>
          </div>
        </article>
      <?php endforeach; ?>
      <article class="net-card net-new">
        <h3>Your country next?</h3>
        <p class="muted">Chapters are forming in <?= e(implode(', ', array_map(fn($c) => trim(preg_replace('/[^\p{L} ]/u', '', $c)), array_slice($EXTRA_COUNTRIES, 0, 5)))) ?>. Start one and become its country lead.</p>
        <a class="btn btn-small" href="join.php?focus=Becoming+a+country+lead">Lead a chapter</a>
      </article>
    </div>
    <ol class="net-ways">
      <li><b>Show up.</b> Join a weekly X Space. Listening counts; asking a question counts more.</li>
      <li><b>Be real.</b> Your own name or handle, your own voice. We grow by trust, not numbers.</li>
      <li><b>Give first.</b> Ubuntu: teach what you just learned to the next newcomer.</li>
    </ol>
  </div>
</section>

<section class="section w3-council" id="council">
  <div class="wrap">
    <div class="section-head">
      <p class="eyebrow">Pack Council</p>
      <h2>Vote on what the pack does next</h2>
      <p class="muted">Connect a wallet to sign your vote (free, no transaction) so it counts once per wallet. No wallet? Your vote still counts as a community vote.</p>
    </div>
    <div class="w3-props">
      <?php foreach ($PROPOSALS as $p): $closed = strtotime($p['closes'] . ' 23:59:59') < time(); ?>
        <article class="w3-card w3-prop" data-prop="<?= e($p['id']) ?>">
          <div class="w3-prop-head"><span class="tag"><?= $closed ? 'Closed' : 'Open until ' . date('j M', strtotime($p['closes'])) ?></span><span class="muted small" data-prop-meta></span></div>
          <h3><?= e($p['title']) ?></h3>
          <p class="muted"><?= e($p['body']) ?></p>
          <div class="w3-opts">
            <?php foreach ($p['options'] as $i => $o): ?>
              <button type="button" class="w3-opt" data-opt="<?= $i ?>" <?= $closed ? 'disabled' : '' ?>><span class="w3-fill"></span><span class="w3-label"><?= e($o) ?></span><b class="w3-pct"></b></button>
            <?php endforeach; ?>
          </div>
          <p class="form-msg" role="status" aria-live="polite"></p>
        </article>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<section class="section w3-safety" id="safety">
  <div class="wrap w3-safe-grid">
    <div>
      <p class="eyebrow">Stay safe</p>
      <h2>Scam check</h2>
      <p class="muted">Paste any link someone sent you about BMA or Doginal Dogs. We'll tell you if it's one of the official addresses.</p>
      <form class="w3-watch" id="scam-form"><label class="sr" for="scam-url">Link to check</label><input id="scam-url" placeholder="https://…" autocomplete="off"><button class="btn btn-small" type="submit">Check</button></form>
      <p class="w3-verdict" id="scam-out" role="status" aria-live="polite"></p>
    </div>
    <ul class="w3-rules">
      <li><b>No one from BMA will DM you first</b> about money, giveaways or "support".</li>
      <li><b>Never share your seed phrase.</b> Not with admins, not with "wallet sync" sites.</li>
      <li><b>P2P safely:</b> use escrow, check the buyer's history, and never release before funds land.</li>
      <li><b>Doginals trade on</b> the official marketplace only: market.doginaldogs.com.</li>
    </ul>
  </div>
</section>

<?= join_cta() ?>
<?php require __DIR__ . '/includes/footer.php'; ?>
