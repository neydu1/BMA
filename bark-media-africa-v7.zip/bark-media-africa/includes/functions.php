<?php
if (session_status() === PHP_SESSION_NONE) {
  session_start();
}

function e($s) { return htmlspecialchars((string) $s, ENT_QUOTES, 'UTF-8'); }

function current_page() { return basename($_SERVER['SCRIPT_NAME'], '.php'); }

/* ---------- Spaces ---------- */
function space_status(array $s) {
  $now = time();
  $start = strtotime($s['start']);
  $end = $s['end'] ? strtotime($s['end']) : null;
  if ($start > $now) return 'upcoming';
  if (!$end || $end > $now) return 'live';
  if ($now - $end <= 86400) return 'recent';
  return 'old';
}

function rel_time($iso) {
  $diff = strtotime($iso) - time();
  $abs = abs($diff);
  if ($abs < 3600) { $n = max(1, round($abs / 60)); $u = 'min'; }
  elseif ($abs < 86400) { $n = round($abs / 3600, $abs < 36000 ? 1 : 0); $u = $n == 1 ? 'hour' : 'hours'; }
  else { $n = round($abs / 86400); $u = $n == 1 ? 'day' : 'days'; }
  return $diff >= 0 ? "in $n $u" : "$n $u ago";
}

/* ---------- Security ---------- */
function csrf_token() {
  if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(16));
  return $_SESSION['csrf'];
}
function csrf_check($t) { return !empty($_SESSION['csrf']) && is_string($t) && hash_equals($_SESSION['csrf'], $t); }

/** Simple per-session throttle: max $max submissions per $window seconds per form. */
function rate_limited($key, $max = 4, $window = 600) {
  $now = time();
  $hits = array_filter($_SESSION['rl'][$key] ?? [], fn($t) => $now - $t < $window);
  if (count($hits) >= $max) return true;
  $hits[] = $now;
  $_SESSION['rl'][$key] = $hits;
  return false;
}

function clean($v, $max = 500) {
  $v = trim((string) ($v ?? ''));
  $v = preg_replace('/[\r\n]+/', ' ', $v);      // no header injection
  return mb_substr(strip_tags($v), 0, $max);
}

/* ---------- Storage (CSV backups) ---------- */
function store_row($file, array $row) {
  if (!is_dir(STORAGE_DIR)) @mkdir(STORAGE_DIR, 0755, true);
  $path = STORAGE_DIR . '/' . $file;
  $isNew = !file_exists($path);
  $fh = @fopen($path, 'a');
  if (!$fh) return false;
  flock($fh, LOCK_EX);
  if ($isNew) fputcsv($fh, array_keys($row));
  // Neutralise spreadsheet formulas
  fputcsv($fh, array_map(fn($v) => preg_match('/^[=+\-\t]/', (string) $v) ? "'" . $v : $v, $row));
  flock($fh, LOCK_UN);
  fclose($fh);
  return true;
}

function email_exists_in($file, $email) {
  $path = STORAGE_DIR . '/' . $file;
  if (!file_exists($path)) return false;
  $fh = fopen($path, 'r');
  $header = fgetcsv($fh);
  $idx = $header ? array_search('email', $header) : false;
  while ($idx !== false && ($r = fgetcsv($fh)) !== false) {
    if (isset($r[$idx]) && strcasecmp($r[$idx], $email) === 0) { fclose($fh); return true; }
  }
  fclose($fh);
  return false;
}

function json_out($ok, $message, $code = 200) {
  http_response_code($code);
  header('Content-Type: application/json');
  echo json_encode(['ok' => $ok, 'message' => $message]);
  exit;
}
