<?php
/* =================================================================
   SHOP CATALOGUE
   • price is in naira (whole units). Paystack is charged in kobo
     automatically. These prices are placeholders — set real ones.
   • art: tee | hoodie | bottle | cap | tote | stickers | sleeve
     (drawn by art.php, with the BMA logo on it). To use a real
     photo instead, set 'photo' => 'assets/images/shop/your.jpg'.
   • colors: logo = 'light' (white logo) or 'dark' (indigo logo)
   ================================================================= */

$SIZES_APPAREL = ['S', 'M', 'L', 'XL', 'XXL'];

$PRODUCTS = [
  'pack-tee' => [
    'name' => 'BMA pack tee', 'price' => 18000, 'art' => 'tee', 'badge' => 'Bestseller',
    'short' => 'Heavyweight cotton tee with the BMA Africa mark on the chest.',
    'desc' => '240gsm combed cotton, relaxed fit, printed in Lagos. The BMA paw-and-continent mark sits on the chest with a small kente tab at the hem.',
    'details' => ['240gsm 100% combed cotton', 'Relaxed unisex fit', 'Screen printed in Lagos', 'Machine wash cold, inside out'],
    'colors' => ['Indigo' => ['#2A2380', 'light'], 'Black' => ['#1B1B1F', 'light'], 'Gold' => ['#F4B63F', 'dark'], 'Bone' => ['#F1E8D6', 'dark']],
    'sizes' => $SIZES_APPAREL,
  ],
  'doge-hoodie' => [
    'name' => 'African Doge hoodie', 'price' => 38000, 'art' => 'hoodie', 'badge' => 'Limited run',
    'short' => 'Brushed fleece hoodie for cold Spaces and harmattan mornings.',
    'desc' => 'Midweight brushed fleece with a lined hood, kangaroo pocket and the BMA mark front and centre. Made in a limited run each season.',
    'details' => ['340gsm cotton-poly fleece', 'Lined hood with flat drawcords', 'Kangaroo pocket', 'Embroidered BMA mark'],
    'colors' => ['Indigo' => ['#2A2380', 'light'], 'Black' => ['#1B1B1F', 'light'], 'Forest' => ['#1F6B4A', 'light']],
    'sizes' => $SIZES_APPAREL,
  ],
  'steel-bottle' => [
    'name' => 'Insulated steel bottle', 'price' => 15000, 'art' => 'bottle', 'badge' => '',
    'short' => '750ml double-wall bottle. Cold for 24 hours, hot for 12.',
    'desc' => 'Double-wall vacuum insulated stainless steel with a leak-proof cap and a kente band printed around the base. Fits most car cup holders.',
    'details' => ['750ml capacity', 'Double-wall vacuum insulation', 'BPA-free leak-proof cap', 'Hand wash only'],
    'colors' => ['Indigo' => ['#2A2380', 'light'], 'Gold' => ['#F4B63F', 'dark'], 'White' => ['#F4F2EE', 'dark']],
    'sizes' => [],
  ],
  'kente-cap' => [
    'name' => 'Kente band cap', 'price' => 12000, 'art' => 'cap', 'badge' => '',
    'short' => 'Six-panel cap with a woven kente band across the front.',
    'desc' => 'Structured six-panel cap with a curved brim, adjustable strap and a woven kente band stitched across the crown.',
    'details' => ['Cotton twill, structured crown', 'Woven kente band', 'Adjustable strap, one size', 'Embroidered logo'],
    'colors' => ['Indigo' => ['#2A2380', 'light'], 'Black' => ['#1B1B1F', 'light']],
    'sizes' => [],
  ],
  'canvas-tote' => [
    'name' => 'Canvas tote', 'price' => 9500, 'art' => 'tote', 'badge' => '',
    'short' => 'Heavy canvas tote that fits a laptop and a day at the meetup.',
    'desc' => '12oz cotton canvas with long handles and an inside pocket. Big enough for a 15-inch laptop.',
    'details' => ['12oz cotton canvas', 'Inside zip pocket', 'Fits 15" laptop', '38 x 42 cm'],
    'colors' => ['Bone' => ['#EFE4CE', 'dark'], 'Black' => ['#1B1B1F', 'light']],
    'sizes' => [],
  ],
  'laptop-sleeve' => [
    'name' => 'Padded laptop sleeve', 'price' => 16000, 'art' => 'sleeve', 'badge' => 'New',
    'short' => 'Padded neoprene sleeve with a kente zip pull.',
    'desc' => 'Soft-lined neoprene sleeve with a two-way zip and a kente zip pull. Protects against bumps on the way to the co-working space.',
    'details' => ['5mm padded neoprene', 'Two-way zip', 'Fits 13–14" laptops', 'Water resistant'],
    'colors' => ['Indigo' => ['#2A2380', 'light'], 'Gold' => ['#F4B63F', 'dark']],
    'sizes' => [],
  ],
  'sticker-pack' => [
    'name' => 'Sticker pack', 'price' => 3500, 'art' => 'stickers', 'badge' => '',
    'short' => 'Six vinyl stickers for your laptop, bottle and phone.',
    'desc' => 'Six weatherproof vinyl stickers: the BMA mark, the paw, Ubuntu, Harambee, Sankofa and a kente strip.',
    'details' => ['6 die-cut stickers', 'Weatherproof vinyl', 'Up to 8 cm each'],
    'colors' => ['Mixed' => ['#F4B63F', 'dark']],
    'sizes' => [],
  ],
];

// Delivery options shown at checkout (price in naira)
$SHIPPING = [
  'abuja'   => ['label' => 'Delivery within Abuja',        'price' => 2500,  'eta' => '1–2 working days'],
  'nigeria' => ['label' => 'Delivery elsewhere in Nigeria', 'price' => 4500,  'eta' => '3–5 working days'],
  'intl'    => ['label' => 'International delivery',        'price' => 30000, 'eta' => '7–14 working days'],
  'pickup'  => ['label' => 'Pick up at a BMA meetup',       'price' => 0,     'eta' => "We'll message you with the date"],
];

function money($n) { return SHOP_SYMBOL . number_format($n); }

function product_img($slug, $color = null, $w = 600) {
  global $PRODUCTS;
  $p = $PRODUCTS[$slug];
  if (!empty($p['photo'])) return $p['photo'];
  $color = $color ?? array_key_first($p['colors']);
  return 'art.php?p=' . urlencode($slug) . '&c=' . urlencode($color);
}

/** Catalogue for the browser cart (no secrets, prices for display only). */
function catalogue_json() {
  global $PRODUCTS, $SHIPPING;
  $out = [];
  foreach ($PRODUCTS as $slug => $p) {
    $out[$slug] = ['name' => $p['name'], 'price' => $p['price'], 'colors' => array_keys($p['colors']), 'sizes' => $p['sizes'],
                   'img' => array_combine(array_keys($p['colors']), array_map(fn($c) => product_img($slug, $c), array_keys($p['colors'])))];
  }
  return json_encode(['products' => $out, 'shipping' => $SHIPPING, 'symbol' => SHOP_SYMBOL], JSON_UNESCAPED_UNICODE | JSON_HEX_TAG);
}

function product_cat($p) {
  return ['tee' => 'Apparel', 'hoodie' => 'Apparel', 'cap' => 'Apparel', 'bottle' => 'Drinkware'][$p['art']] ?? 'Accessories';
}

function product_card($slug) {
  global $PRODUCTS;
  $p = $PRODUCTS[$slug];
  $first = array_key_first($p['colors']);
  ob_start(); ?>
  <article class="product-card" data-cat="<?= e(product_cat($p)) ?>">
    <a class="pc-media" href="product.php?item=<?= e($slug) ?>">
      <?php if ($p['badge']): ?><span class="pc-badge"><?= e($p['badge']) ?></span><?php endif; ?>
      <img src="<?= e(product_img($slug, $first)) ?>" alt="<?= e($p['name']) ?>" loading="lazy" width="600" height="600" data-pc-img>
    </a>
    <div class="pc-body">
      <div class="pc-top">
        <h3><a href="product.php?item=<?= e($slug) ?>"><?= e($p['name']) ?></a></h3>
        <span class="price"><?= money($p['price']) ?></span>
      </div>
      <p class="muted small"><?= e($p['short']) ?></p>
      <div class="pc-foot">
        <?php if (count($p['colors']) > 1): ?>
          <div class="mini-swatches" role="group" aria-label="Preview colours">
            <?php foreach ($p['colors'] as $cn => [$hex]): ?>
              <button type="button" class="mini-sw" style="--sw:<?= e($hex) ?>" aria-label="<?= e($cn) ?>" data-src="<?= e(product_img($slug, $cn)) ?>" aria-pressed="<?= $cn === $first ? 'true' : 'false' ?>"></button>
            <?php endforeach; ?>
          </div>
        <?php else: ?><span></span><?php endif; ?>
        <?php if ($p['sizes']): ?>
          <a class="btn btn-small" href="product.php?item=<?= e($slug) ?>">Choose size</a>
        <?php else: ?>
          <button class="btn btn-small" type="button" data-add="<?= e($slug) ?>" data-color="<?= e($first) ?>">Add to cart</button>
        <?php endif; ?>
      </div>
    </div>
  </article>
  <?php return ob_get_clean();
}
