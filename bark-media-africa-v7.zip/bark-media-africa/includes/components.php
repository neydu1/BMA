<?php
function space_card(array $s) {
  $st = space_status($s);
  $label = ['live' => 'Live now', 'recent' => 'Ended ' . rel_time($s['end'] ?? $s['start']), 'upcoming' => 'Starts ' . rel_time($s['start'])][$st] ?? '';
  $btn = $st === 'live' ? 'Listen live' : ($st === 'upcoming' ? 'Set a reminder' : 'Play recording');
  ob_start(); ?>
  <article class="space-card is-<?= $st ?>">
    <div class="space-top">
      <span class="status"><span class="dot"></span><?= e($label) ?></span>
      <?php if ($s['listeners']): ?><span class="listeners"><?= number_format($s['listeners']) ?> listeners</span><?php endif; ?>
    </div>
    <h3><?= e($s['title']) ?></h3>
    <p class="muted">Hosted by <?= e($s['host']) ?></p>
    <div class="space-bottom">
      <span class="topics"><?php foreach ($s['topics'] as $t): ?><span class="tag"><?= e($t) ?></span><?php endforeach; ?></span>
      <a class="text-link" href="<?= e($s['link']) ?>" target="_blank" rel="noopener"><?= $btn ?></a>
    </div>
    <?php if ($st === 'live'): ?><div class="wave" aria-hidden="true"><?php for ($i = 0; $i < 18; $i++) echo '<i style="--i:' . $i . '"></i>'; ?></div><?php endif; ?>
  </article>
  <?php return ob_get_clean();
}

/* Home › Section › Page, built from $MENU */
function crumbs() {
  global $MENU, $page;
  foreach ($MENU as $m) {
    if (!in_array($page, $m['pages'], true) || $page === 'index') continue;
    $title = $m['label'];
    foreach ($m['items'] ?? [] as [$href, $t]) if (basename($href, '.php') === $page) { $title = $t; break; }
    ob_start(); ?>
    <nav class="crumbs-nav" aria-label="Breadcrumb"><ol>
      <li><a href="index.php">Home</a></li>
      <?php if (!empty($m['items']) && $m['label'] !== $title): ?><li><span><?= e($m['label']) ?></span></li><?php endif; ?>
      <li><span aria-current="page"><?= e($title) ?></span></li>
    </ol></nav>
    <?php return ob_get_clean();
  }
  return '';
}

function page_banner($title, $lede) {
  ob_start(); ?>
  <section class="banner">
    <canvas class="banner-3d" aria-hidden="true"></canvas>
    <div class="wrap">
      <?= crumbs() ?>
      <h1><?= e($title) ?></h1>
      <p class="lede"><?= e($lede) ?></p>
    </div>
  </section>
  <div class="kente" aria-hidden="true"></div>
  <?php return ob_get_clean();
}

function join_cta() {
  global $SITE;
  ob_start(); ?>
  <section class="cta-band">
    <div class="wrap cta-inner">
      <div>
        <h2>Pull up a chair in the Space.</h2>
        <p>Free to join, and you can start in today's Space.</p>
      </div>
      <div class="btn-row">
        <a class="btn btn-gold" href="join.php">Join the community</a>
        <a class="btn btn-ghost" href="<?= e($SITE['xUrl']) ?>" target="_blank" rel="noopener">Follow <?= e($SITE['handle']) ?></a>
      </div>
    </div>
  </section>
  <?php return ob_get_clean();
}

function newsletter_block($source = 'home') {
  ob_start(); ?>
  <section class="news-band" id="newsletter">
    <div class="wrap news-inner">
      <div class="news-coin" aria-hidden="true"><span>Fri</span></div>
      <div class="news-copy">
        <h2>Get the weekly bark in your inbox</h2>
        <p>Upcoming Spaces, Doginals news from an African point of view, and open intern roles. One email on Fridays. Unsubscribe any time.</p>
        <form class="news-form big" action="api/subscribe.php" method="post" data-api="api/subscribe.php" novalidate>
          <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
          <label class="sr" for="news-email-<?= e($source) ?>">Email address</label>
          <input id="news-email-<?= e($source) ?>" name="email" type="email" placeholder="you@email.com" autocomplete="email" required>
          <input type="text" name="website" class="hp" tabindex="-1" autocomplete="off" aria-hidden="true">
          <input type="hidden" name="source" value="<?= e($source) ?>">
          <button class="btn btn-gold" type="submit">Subscribe</button>
          <p class="form-msg" role="status" aria-live="polite"></p>
        </form>
      </div>
    </div>
  </section>
  <?php return ob_get_clean();
}

function step_icon($name) {
  $p = [
    'mic' => '<rect x="22" y="8" width="20" height="32" rx="10"/><path d="M14 30a18 18 0 0 0 36 0M32 48v8M22 56h20"/>',
    'wallet' => '<rect x="8" y="16" width="48" height="36" rx="6"/><path d="M8 26h40a8 8 0 0 1 8 8v4H44a6 6 0 0 1 0-12"/><circle cx="45" cy="32" r="2"/><path d="M14 16l26-8 4 8"/>',
    'rise' => '<path d="M8 50l14-14 10 10 22-24"/><path d="M42 22h12v12"/><path d="M8 58h48"/>',
  ][$name] ?? '';
  return '<svg viewBox="0 0 64 64" width="44" height="44" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' . $p . '</svg>';
}

/* Adinkra symbols as inline SVG (drawn simply, stroke = currentColor) */
function adinkra($name) {
  $p = [
    // Adinkrahene: chief of symbols, three concentric circles
    'Adinkrahene' => '<circle cx="32" cy="32" r="26"/><circle cx="32" cy="32" r="17"/><circle cx="32" cy="32" r="8"/>',
    // Nkyinkyim: twisting path, initiative and versatility
    'Nkyinkyim' => '<path d="M14 6v10h18v10H14v10h18v10H14v12"/><path d="M50 6v52"/>',
    // Nsoromma: child of the heavens, a star
    'Nsoromma' => '<path d="M32 4l6 18h18l-14 11 5 19-15-11-15 11 5-19L8 22h18z"/><circle cx="32" cy="31" r="6"/>',
    // Eban: fence, safety and security
    'Eban' => '<rect x="8" y="8" width="48" height="48"/><rect x="20" y="20" width="24" height="24"/><path d="M8 32h12M44 32h12M32 8v12M32 44v12"/>',
    // Gye Nyame-inspired spiral for the default
    'Sankofa' => '<path d="M32 56c-14-6-22-16-22-26a22 22 0 0 1 44 0c0 8-6 14-14 14s-12-5-12-10 4-8 8-8"/><circle cx="36" cy="26" r="3"/>',
  ][$name] ?? '<circle cx="32" cy="32" r="24"/>';
  return '<span class="adinkra" aria-hidden="true"><svg viewBox="0 0 64 64" fill="none" stroke="currentColor" stroke-width="3.5" stroke-linecap="round" stroke-linejoin="round">' . $p . '</svg></span>';
}
