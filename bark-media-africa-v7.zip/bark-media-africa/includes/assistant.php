<?php
/* =================================================================
   "Sniff", the BMA guide: chat assistant + events pop-up.
   • assistant_config()    builds the site knowledge the chat uses (from data.php, so it never goes stale)
   • assistant_knowledge() the same facts as plain text for the optional AI mode (api/chat.php)
   • render_assistant()    prints the widget markup (called from footer.php)

   Optional AI mode: add to includes/config.php
       define('CHATBOT_API_KEY', 'sk-ant-...');   // Anthropic API key. Leave out for the built-in guide only.
   ================================================================= */

function assistant_next_events($limit = 3) {
  global $EVENTS;
  $now = time();
  $up = array_values(array_filter($EVENTS ?? [], fn($e) => strtotime($e['date']) > $now));
  usort($up, fn($a, $b) => strtotime($a['date']) - strtotime($b['date']));
  return array_slice($up, 0, $limit);
}

function assistant_llm_enabled() {
  return (defined('CHATBOT_API_KEY') && CHATBOT_API_KEY !== '') || (getenv('ANTHROPIC_API_KEY') ?: '') !== '';
}

function assistant_config() {
  global $SITE, $NATIONS, $SERVICES, $FOCUS_OPTIONS, $FAQ, $PRODUCTS, $SHIPPING, $EXTRA_COUNTRIES;
  $events = array_map(fn($e) => [
    'title' => $e['title'], 'type' => $e['type'],
    'when' => date('D j M, g:i a', strtotime($e['date'])) . ' WAT', 'summary' => $e['summary'],
  ], assistant_next_events(5));
  $products = [];
  foreach ($PRODUCTS ?? [] as $slug => $p) $products[] = ['slug' => $slug, 'name' => $p['name'], 'price' => money($p['price'])];
  $ship = [];
  foreach ($SHIPPING ?? [] as $s) $ship[] = ['label' => $s['label'], 'price' => $s['price'] ? money($s['price']) : 'Free', 'eta' => $s['eta']];
  return [
    'name' => 'Sniff',
    'llm' => assistant_llm_enabled(),
    'site' => ['name' => $SITE['name'], 'handle' => $SITE['handle'], 'x' => $SITE['xUrl'], 'telegram' => $SITE['telegram'], 'email' => $SITE['email']],
    'stats' => $SITE['stats'],
    'nations' => array_map(fn($n) => ['name' => $n['name'], 'flag' => $n['flag'], 'members' => $n['members'], 'cities' => $n['cities']], $NATIONS),
    'extra' => $EXTRA_COUNTRIES,
    'services' => array_map(fn($s) => ['title' => $s['title'], 'summary' => $s['summary']], $SERVICES),
    'focus' => $FOCUS_OPTIONS,
    'faq' => $FAQ,
    'events' => $events,
    'products' => $products,
    'shipping' => $ship,
  ];
}

/** Plain-text facts for the AI system prompt. */
function assistant_knowledge() {
  $c = assistant_config();
  $t = "ABOUT BMA\n{$c['site']['name']} (BMA) is the African chapter of the DoginalDogs community. It began as an X Space between African DoginalDogs holders and is now a network of builders, creators and learners. Handle {$c['site']['handle']} on X ({$c['site']['x']}), Telegram {$c['site']['telegram']}, email {$c['site']['email']}.\n";
  $t .= 'Stats: ' . implode('; ', array_map(fn($s) => $s['value'] . ' ' . $s['label'], $c['stats'])) . ".\n";
  $t .= "Values: Ubuntu (I am because we are), Harambee (all pull together), Sankofa (go back and fetch it).\n";
  $t .= "\nDOGINALS\nDoginals are inscriptions on the Dogecoin blockchain, similar in idea to Bitcoin Ordinals. DoginalDogs is a collection in that ecosystem. Do not state supply, prices, mint dates or returns: say you don't have that and point to X or Telegram.\n";
  $t .= "\nSERVICES\n" . implode("\n", array_map(fn($s) => "- {$s['title']}: {$s['summary']}", $c['services'])) . "\n";
  $t .= "\nNATIONS\n" . implode("\n", array_map(fn($n) => "- {$n['name']}: {$n['members']} members ({$n['cities']})", $c['nations'])) . "\nAlso recruiting country leads in Kenya, Egypt, Rwanda and more.\n";
  $t .= "\nUPCOMING EVENTS\n" . ($c['events'] ? implode("\n", array_map(fn($e) => "- {$e['title']} ({$e['type']}), {$e['when']}", $c['events'])) : "None scheduled yet. Weekly X Spaces run; tell people to follow the X handle.") . "\n";
  $t .= "\nSHOP (naira, pay with Paystack by card, bank transfer or USSD)\n" . implode("\n", array_map(fn($p) => "- {$p['name']}: {$p['price']}", $c['products'])) . "\nDelivery:\n" . implode("\n", array_map(fn($s) => "- {$s['label']}: {$s['price']}, {$s['eta']}", $c['shipping'])) . "\n";
  $t .= "\nFAQ\n" . implode("\n", array_map(fn($f) => "Q: {$f['q']}\nA: {$f['a']}", $c['faq'])) . "\n";
  $t .= "\nPAGES (use these exact file names)\nindex.php Home; about.php Our story and values; services.php What BMA offers; events.php Events timeline; spaces.php Spaces in the last 24 hours; shop.php Merch shop; join.php Join the community form; partner.php Partner with us (sponsors, funders, chapters)\n";
  return $t;
}

function render_assistant() {
  global $page, $bodyClass, $SITE;
  $cfg = assistant_config();
  $nextEv = assistant_next_events(1)[0] ?? null;
  $skipCta = in_array($page, ['checkout', 'order-complete', 'orders'], true);
  ?>
<script>window.BMA_ASSISTANT = <?= json_encode($cfg, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP) ?>; window.BMA_PAGE = <?= json_encode($page) ?>;</script>

<?php if (!$skipCta): ?>
<aside class="event-cta" id="event-cta" role="status" aria-live="polite" hidden>
  <span class="ec-ticket" aria-hidden="true">
    <svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="5" width="18" height="16" rx="3"/><path d="M8 3v4M16 3v4M3 10h18"/></svg>
    <i class="ec-dot"></i>
  </span>
  <div class="ec-body">
    <b>Events coming up</b>
    <span><?= $nextEv ? e($nextEv['title']) . ' &middot; ' . e(date('D j M', strtotime($nextEv['date']))) . '. Stay tuned.' : 'New Spaces & meetups soon. Stay tuned.' ?></span>
  </div>
  <a class="ec-go" href="events.php">See events</a>
  <button class="ec-x" type="button" aria-label="Dismiss events reminder">&times;</button>
</aside>
<?php endif; ?>

<button class="sn-launch" id="sn-launch" type="button" aria-expanded="false" aria-controls="sn-panel" aria-label="Open chat with Sniff, the BMA guide">
  <span class="sn-launch-icon"><?= sniff_svg() ?></span>
  <span class="sn-launch-text">Ask Sniff</span>
  <i class="sn-badge" aria-hidden="true"></i>
</button>

<section class="sn-panel" id="sn-panel" role="dialog" aria-label="Chat with Sniff, the BMA guide" aria-modal="false" hidden>
  <header class="sn-head">
    <span class="sn-avatar"><?= sniff_svg() ?></span>
    <div class="sn-title"><b>Sniff</b><small><span class="sn-live"></span> BMA guide<?= $cfg['llm'] ? ' &middot; AI' : '' ?></small></div>
    <button class="sn-reset" type="button" id="sn-reset" aria-label="Start a new chat" title="New chat">
      <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 12a9 9 0 1 0 3-6.7M3 4v5h5"/></svg>
    </button>
    <button class="sn-close" type="button" id="sn-close" aria-label="Close chat">&times;</button>
  </header>
  <div class="sn-kente" aria-hidden="true"></div>
  <div class="sn-log" id="sn-log" role="log" aria-live="polite" aria-label="Conversation"></div>
  <div class="sn-chips" id="sn-chips" aria-label="Suggested questions"></div>
  <form class="sn-form" id="sn-form" autocomplete="off">
    <label class="sr" for="sn-input">Ask Sniff a question</label>
    <input id="sn-input" type="text" maxlength="300" placeholder="Ask Sniff anything…" enterkeyhint="send">
    <button class="sn-send" type="submit" aria-label="Send message"><svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12h14M13 6l6 6-6 6"/></svg></button>
  </form>
  <p class="sn-foot">Sniff is a guide, not financial advice. Never share your seed phrase.</p>
</section>
<?php
}

/** Original friendly dog-face mark for the guide. */
function sniff_svg() {
  return '<svg viewBox="0 0 48 48" aria-hidden="true" focusable="false">'
    . '<path d="M9 14c-3 1-5 7-4 13 .5 3 3 4 5 2l3-9z" fill="#C98A14"/><path d="M39 14c3 1 5 7 4 13-.5 3-3 4-5 2l-3-9z" fill="#C98A14"/>'
    . '<ellipse cx="24" cy="26" rx="14" ry="15" fill="#F4B63F"/>'
    . '<ellipse cx="24" cy="32" rx="8" ry="6.5" fill="#F5EEE1"/>'
    . '<circle cx="18" cy="23" r="2.4" fill="#16124A"/><circle cx="30" cy="23" r="2.4" fill="#16124A"/>'
    . '<circle cx="18.8" cy="22.2" r=".8" fill="#fff"/><circle cx="30.8" cy="22.2" r=".8" fill="#fff"/>'
    . '<ellipse cx="24" cy="29.5" rx="3.2" ry="2.3" fill="#16124A"/>'
    . '<path d="M24 31.5v2.5M20.5 34c1.6 1.6 5.4 1.6 7 0" fill="none" stroke="#16124A" stroke-width="1.6" stroke-linecap="round"/>'
    . '</svg>';
}
