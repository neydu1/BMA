<?php
/* Orders: saved as JSON files in storage/orders/, one per order.
   An order is marked paid only after Paystack confirms it server-side
   (verify API on return, or the webhook) and the amount matches. */
require_once __DIR__ . '/products.php';
require_once __DIR__ . '/mailer.php';

define('ORDERS_DIR', STORAGE_DIR . '/orders');

function site_url($path = '') {
  if (SITE_URL !== '') return rtrim(SITE_URL, '/') . '/' . ltrim($path, '/');
  $https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || ($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https';
  $dir = rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'])), '/');
  $dir = preg_replace('#/(api|admin)$#', '', $dir);
  return ($https ? 'https' : 'http') . '://' . $_SERVER['HTTP_HOST'] . $dir . '/' . ltrim($path, '/');
}

function paystack_ready() {
  return strpos(PAYSTACK_SECRET_KEY, 'xxxx') === false && preg_match('/^sk_(test|live)_/', PAYSTACK_SECRET_KEY);
}

/** Calls the Paystack API. Returns decoded JSON or ['status' => false, 'message' => ...]. */
function paystack_request($method, $endpoint, $body = null) {
  $url = 'https://api.paystack.co' . $endpoint;
  $headers = ['Authorization: Bearer ' . PAYSTACK_SECRET_KEY, 'Content-Type: application/json', 'Cache-Control: no-cache'];
  if (function_exists('curl_init')) {
    $ch = curl_init($url);
    curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_CUSTOMREQUEST => $method, CURLOPT_HTTPHEADER => $headers, CURLOPT_TIMEOUT => 30]);
    if ($body !== null) curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($body));
    $raw = curl_exec($ch);
    $err = curl_error($ch);
    curl_close($ch);
  } else {
    $ctx = stream_context_create(['http' => ['method' => $method, 'header' => implode("\r\n", $headers), 'content' => $body !== null ? json_encode($body) : '', 'timeout' => 30, 'ignore_errors' => true]]);
    $raw = @file_get_contents($url, false, $ctx);
    $err = $raw === false ? 'Could not connect to Paystack' : '';
  }
  if ($raw === false || $raw === null || $raw === '') return ['status' => false, 'message' => $err ?: 'No response from Paystack'];
  $json = json_decode($raw, true);
  return is_array($json) ? $json : ['status' => false, 'message' => 'Bad response from Paystack'];
}

/* ---------- order files ---------- */
function order_path($ref) { return ORDERS_DIR . '/' . preg_replace('/[^A-Za-z0-9\-]/', '', $ref) . '.json'; }

function order_load($ref) {
  $f = order_path($ref);
  return is_file($f) ? json_decode(file_get_contents($f), true) : null;
}

function order_save(array $o) {
  if (!is_dir(ORDERS_DIR)) @mkdir(ORDERS_DIR, 0755, true);
  return file_put_contents(order_path($o['ref']), json_encode($o, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE), LOCK_EX) !== false;
}

function order_all() {
  $out = [];
  foreach (glob(ORDERS_DIR . '/*.json') ?: [] as $f) { $o = json_decode(file_get_contents($f), true); if ($o) $out[] = $o; }
  usort($out, fn($a, $b) => strcmp($b['created'], $a['created']));
  return $out;
}

function new_order_ref() { return 'BMA-' . date('ymd') . '-' . strtoupper(bin2hex(random_bytes(3))); }

/**
 * Rebuilds the cart from the catalogue so prices can't be tampered with.
 * $items: [{id, color, size, qty}]. Returns [lines, subtotal] or a string error.
 */
function price_cart(array $items) {
  global $PRODUCTS;
  $lines = []; $subtotal = 0;
  foreach (array_slice($items, 0, 30) as $it) {
    $id = (string) ($it['id'] ?? '');
    if (!isset($PRODUCTS[$id])) return 'An item in your cart is no longer available. Remove it and try again.';
    $p = $PRODUCTS[$id];
    $qty = max(1, min(20, (int) ($it['qty'] ?? 1)));
    $color = (string) ($it['color'] ?? '');
    if (!isset($p['colors'][$color])) $color = array_key_first($p['colors']);
    $size = (string) ($it['size'] ?? '');
    if ($p['sizes'] && !in_array($size, $p['sizes'], true)) return 'Choose a size for ' . $p['name'] . '.';
    if (!$p['sizes']) $size = '';
    $total = $p['price'] * $qty;
    $lines[] = ['id' => $id, 'name' => $p['name'], 'color' => $color, 'size' => $size, 'qty' => $qty, 'price' => $p['price'], 'total' => $total];
    $subtotal += $total;
  }
  if (!$lines) return 'Your cart is empty.';
  return [$lines, $subtotal];
}

function variant_label(array $l) { return trim($l['color'] . ($l['size'] ? ', size ' . $l['size'] : '')); }

/**
 * Confirms a payment with Paystack and marks the order paid (once).
 * Safe to call from both the return page and the webhook.
 * Returns the order (with 'status') or null if the reference is unknown.
 */
function order_confirm($ref) {
  $order = order_load($ref);
  if (!$order) return null;
  if ($order['status'] === 'paid') return $order;

  $res = paystack_request('GET', '/transaction/verify/' . rawurlencode($ref));
  $d = $res['data'] ?? [];
  if (empty($res['status']) || ($d['status'] ?? '') !== 'success') {
    if (in_array($d['status'] ?? '', ['failed', 'abandoned', 'reversed'], true)) { $order['status'] = $d['status']; order_save($order); }
    return $order;
  }
  if ((int) $d['amount'] !== (int) $order['amount_kobo'] || strtoupper($d['currency']) !== SHOP_CURRENCY) {
    $order['status'] = 'amount_mismatch';
    $order['note'] = 'Paid ' . $d['currency'] . ' ' . ($d['amount'] / 100) . ' — expected ' . ($order['amount_kobo'] / 100);
    order_save($order);
    error_log('BMA: amount mismatch on ' . $ref);
    return $order;
  }

  // Lock so the webhook and return page can't both send emails
  $lock = fopen(order_path($ref) . '.lock', 'c');
  flock($lock, LOCK_EX);
  $order = order_load($ref);
  if ($order['status'] !== 'paid') {
    $order['status'] = 'paid';
    $order['paid_at'] = date('c');
    $order['channel'] = $d['channel'] ?? '';
    $order['paystack_id'] = $d['id'] ?? '';
    order_save($order);
    store_row('orders.csv', [
      'date' => $order['paid_at'], 'ref' => $ref, 'name' => $order['customer']['name'], 'email' => $order['customer']['email'],
      'phone' => $order['customer']['phone'], 'items' => implode('; ', array_map(fn($l) => $l['qty'] . 'x ' . $l['name'] . ' (' . variant_label($l) . ')', $order['lines'])),
      'total' => $order['total'], 'delivery' => $order['shipping']['label'], 'address' => $order['customer']['address'],
    ]);
    order_emails($order);
  }
  flock($lock, LOCK_UN); fclose($lock); @unlink(order_path($ref) . '.lock');
  return $order;
}

function order_items_table(array $o) {
  $h = '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="border-collapse:collapse;font-size:15px;margin:8px 0 18px">';
  foreach ($o['lines'] as $l) {
    $h .= '<tr><td style="padding:10px 0;border-bottom:1px solid #EEE8DA"><b>' . e($l['name']) . '</b><br><span style="color:#6B6790;font-size:13px">' . e(variant_label($l)) . ' &times; ' . $l['qty'] . '</span></td>'
        . '<td align="right" style="padding:10px 0;border-bottom:1px solid #EEE8DA;font-weight:bold">' . e(money($l['total'])) . '</td></tr>';
  }
  $h .= '<tr><td style="padding:8px 0;color:#6B6790">Subtotal</td><td align="right">' . e(money($o['subtotal'])) . '</td></tr>'
      . '<tr><td style="padding:8px 0;color:#6B6790">' . e($o['shipping']['label']) . '</td><td align="right">' . e($o['shipping']['price'] ? money($o['shipping']['price']) : 'Free') . '</td></tr>'
      . '<tr><td style="padding:12px 0;font-size:17px;font-weight:bold;border-top:2px solid #16124A">Total paid</td><td align="right" style="padding:12px 0;font-size:17px;font-weight:bold;border-top:2px solid #16124A">' . e(money($o['total'])) . '</td></tr>';
  return $h . '</table>';
}

function order_emails(array $o) {
  global $SITE;
  $c = $o['customer'];
  $admin = email_layout('New shop order ' . $o['ref'], '<p style="margin:0 0 12px;font-size:15px">Paid via Paystack (' . e($o['channel'] ?: 'card') . '). Ship to:</p>'
    . email_table(['Name' => $c['name'], 'Email' => $c['email'], 'Phone' => $c['phone'], 'Delivery' => $o['shipping']['label'],
                   'Address' => $c['address'] . ($c['city'] ? ', ' . $c['city'] : '') . ($c['state'] ? ', ' . $c['state'] : '') . ($c['country'] ? ', ' . $c['country'] : ''),
                   'Note' => $c['note'], 'Reference' => $o['ref']])
    . '<h2 style="font-size:17px;margin:24px 0 4px">Items</h2>' . order_items_table($o)
    . '<p style="font-size:13px;color:#6B6790">See all orders at ' . e(site_url('admin/orders.php')) . '</p>');
  send_mail(ADMIN_EMAIL, ADMIN_NAME, 'New order ' . $o['ref'] . ' — ' . money($o['total']), $admin, $c['email'], $c['name']);

  $first = explode(' ', $c['name'])[0];
  $receipt = email_layout("Thanks for your order, $first", '<p style="font-size:15px;line-height:1.6">We\'ve received your payment. Your order reference is <b>' . e($o['ref']) . '</b>. '
    . e($o['shipping']['eta']) . '. We\'ll message you on ' . e($c['phone']) . ' when it\'s on the way.</p>'
    . order_items_table($o)
    . '<p style="font-size:14px;color:#6B6790">Questions? Reply to this email or message ' . e($SITE['handle']) . ' on X.</p>');
  send_mail($c['email'], $c['name'], 'Your BMA order ' . $o['ref'], $receipt);
}
