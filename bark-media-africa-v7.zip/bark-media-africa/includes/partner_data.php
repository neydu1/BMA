<?php
/* Shared by partner.php (the form) and api/partner.php (the handler).
   Edit these lists to change the form options. */

$PARTNER_TYPES = [
  'Individual / angel',
  'Venture fund',
  'Brand or company',
  'Community / DAO',
  'Foundation or grant maker',
  'Other',
];

$PARTNER_BUDGETS = [
  'Not sure yet',
  'Under $5,000',
  '$5,000 - $25,000',
  '$25,000 - $100,000',
  '$100,000 - $500,000',
  '$500,000+',
];

$PARTNER_INTERESTS = [
  'Intern programme',
  'Spaces & events',
  'Country chapters',
  'Shop & merch',
  'Media & content',
  'Something else',
];

/* Cards on the page. 'interest' must match an entry in $PARTNER_INTERESTS. */
$PARTNER_WAYS = [
  ['icon' => 'people', 'title' => 'Back the intern programme', 'interest' => 'Intern programme',
   'body' => 'Help train more African members to run X accounts and communities for Web3 projects, and keep that work paid.'],
  ['icon' => 'mic', 'title' => 'Sponsor Spaces & events', 'interest' => 'Spaces & events',
   'body' => 'Put your name behind our weekly X Spaces, AMAs, workshops and meetups, in front of an engaged African audience.'],
  ['icon' => 'globe', 'title' => 'Open a country chapter', 'interest' => 'Country chapters',
   'body' => "Fund and support new BMA chapters. We're recruiting leads in Kenya, Egypt, Rwanda and beyond."],
  ['icon' => 'bag', 'title' => 'Build with our shop', 'interest' => 'Shop & merch',
   'body' => 'Co-create merchandise, books and community products that carry African Web3 culture worldwide.'],
];

function partner_icon($name) {
  $p = [
    'people' => '<circle cx="24" cy="22" r="8"/><circle cx="44" cy="26" r="6"/><path d="M8 52c1-10 8-16 16-16s15 6 16 16M38 40c8-2 16 2 18 12"/>',
    'mic'    => '<rect x="23" y="8" width="18" height="30" rx="9"/><path d="M14 30a18 18 0 0 0 36 0M32 48v8M22 56h20"/>',
    'globe'  => '<circle cx="32" cy="32" r="22"/><path d="M10 32h44M32 10c-9 10-9 34 0 44M32 10c9 10 9 34 0 44"/>',
    'bag'    => '<path d="M14 22h36l-3 34H17L14 22Z"/><path d="M23 22a9 9 0 0 1 18 0"/>',
  ][$name] ?? '';
  return '<svg viewBox="0 0 64 64" width="44" height="44" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' . $p . '</svg>';
}
