</main>

<footer class="site-footer">
  <div class="kente" aria-hidden="true"></div>
  <div class="wrap footer-grid footer-grid-v5">
    <div class="footer-news">
      <h2>The weekly bark</h2>
      <p>One email every Friday: upcoming Spaces, Doginals news from an African point of view, and open intern roles.</p>
      <form class="news-form" action="api/subscribe.php" method="post" data-api="api/subscribe.php" novalidate>
        <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
        <label class="sr" for="news-email-f">Email address</label>
        <input id="news-email-f" name="email" type="email" placeholder="you@email.com" autocomplete="email" required>
        <input type="text" name="website" class="hp" tabindex="-1" autocomplete="off" aria-hidden="true">
        <input type="hidden" name="source" value="footer">
        <button class="btn btn-gold" type="submit">Subscribe</button>
        <p class="form-msg" role="status" aria-live="polite"></p>
      </form>
    </div>
    <?php foreach ($MENU as $m): if (empty($m['items'])) continue; ?>
    <div>
      <h3><?= e($m['label']) ?></h3>
      <ul class="flinks">
        <?php foreach ($m['items'] as [$href, $t]): ?><li><a href="<?= e($href) ?>"><?= e($t) ?></a></li><?php endforeach; ?>
      </ul>
    </div>
    <?php endforeach; ?>
    <div>
      <h3>Find us</h3>
      <ul class="flinks">
        <li><a href="<?= e($SITE['xUrl']) ?>" target="_blank" rel="noopener">X: <?= e($SITE['handle']) ?></a></li>
        <li><a href="<?= e($SITE['telegram']) ?>" target="_blank" rel="noopener">Telegram group</a></li>
        <li><a href="mailto:<?= e($SITE['email']) ?>"><?= e($SITE['email']) ?></a></li>
      </ul>
    </div>
  </div>
  <div class="wrap footer-base">
    <span>© <?= date('Y') ?> <?= e($SITE['name']) ?>. Built by Africans, for the next wave of Web3.</span>
    <span>Nothing here is financial advice. <a href="#top" class="text-link">Back to top ↑</a></span>
  </div>
</footer>

<div class="drawer-scrim" data-cart-close hidden></div>
<aside class="cart-drawer" id="cart-drawer" aria-label="Your cart" aria-hidden="true" tabindex="-1">
  <div class="drawer-head">
    <h2>Your cart</h2>
    <button class="icon-btn" type="button" data-cart-close aria-label="Close cart">&times;</button>
  </div>
  <div class="drawer-body" data-cart-lines></div>
  <div class="drawer-foot" data-cart-foot>
    <div class="drawer-total"><span>Subtotal</span><b data-cart-subtotal>₦0</b></div>
    <p class="muted small">Delivery is added at checkout.</p>
    <a class="btn btn-gold block" href="checkout.php">Checkout with Paystack</a>
  </div>
</aside>
<div class="toast" id="toast" role="status" aria-live="polite"></div>

<?php require_once __DIR__ . '/assistant.php'; render_assistant(); ?>

<script>window.BMA_SHOP = <?= catalogue_json() ?>;</script>
<script src="assets/js/cosmos.js?v=6" defer></script>
<script src="assets/js/main.js?v=4" defer></script>
<script src="assets/js/shop.js?v=1" defer></script>
<script src="assets/js/assistant.js?v=3" defer></script>
<?php if (!empty($extraScripts)) echo $extraScripts; ?>
<script type="importmap">{"imports":{"three":"./assets/vendor/three/three.module.min.js","three/addons/":"./assets/vendor/three/addons/"}}</script>
<script type="module" src="assets/js/scene3d.js?v=2"></script>
</body>
</html>
