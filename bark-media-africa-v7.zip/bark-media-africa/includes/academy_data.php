<?php
/* =================================================================
   WEB3 MADE SIMPLE — Bark Media Africa Web3 Academy
   Content merged from "BMA Web3 Beginners Syllabus" and the
   "Web3 Made Simple Beginner Study Guide". Each fact appears once.
   ================================================================= */

$ACADEMY = [
  'title' => 'Web3 Made Simple',
  'subtitle' => 'Blockchain technology for beginners',
  'motto' => 'Education first. Safety always. Opportunities through knowledge.',
  'duration' => '6–12 weeks',
  'format' => 'Short lessons, demonstrations, discussions, quizzes and practical exercises',
  'audience' => 'Students, creators, entrepreneurs, professionals and curious beginners',
  'mission' => "At Bark Media Africa, we believe that knowledge creates opportunities. Our mission is to help Africans understand emerging technologies, develop practical skills, build meaningful connections, and participate confidently in the global digital economy.",
];

$ACADEMY_OBJECTIVES = [
  'Explain Web3, blockchain, cryptocurrency, decentralisation and digital ownership in plain language.',
  'Understand how blockchain transactions are recorded and verified.',
  'Describe wallets, public addresses, private keys, seed phrases and transaction fees.',
  'Recognise coins, tokens, stablecoins, NFTs, smart contracts and decentralised applications.',
  'Understand the basics of DeFi and its common technical and financial risks.',
  'Identify Web3 careers, creator opportunities, community roles and ways to contribute to projects.',
  'Spot common scams and build a safe, independent learning plan.',
];

/* 12 modules. concepts = key terms, explain = plain-language notes,
   example, remember, activity = practical task from the syllabus. */
$MODULES = [
  ['n' => 1, 'week' => 1, 'title' => 'Welcome to Web3', 'tag' => 'What exactly is Web3?',
   'concepts' => ['Web1, Web2, Web3', 'Centralised vs decentralised', 'Digital ownership', 'Myths and misconceptions'],
   'explain' => ['Web1 is commonly described as a read-focused internet. Web2 introduced interactive platforms where people create and share content. Web3 emphasises blockchain-based applications, digital assets and participation through decentralised systems.',
                 'Centralised systems are controlled by a central organisation. Decentralised systems distribute some control among many participants.'],
   'example' => 'On a conventional social platform, a company controls the rules and your account. A blockchain application may let you connect a wallet and interact with shared network records.',
   'remember' => 'Web3 does not automatically mean every application is decentralised, or that users control everything.',
   'activity' => 'List the apps you use every day and discuss who controls your account, your content and your digital assets on each.'],

  ['n' => 2, 'week' => 1, 'title' => 'Understanding Blockchain', 'tag' => 'The technology behind Web3',
   'concepts' => ['Blocks and transactions', 'Cryptographic hashes', 'Distributed ledgers', 'Public vs private chains'],
   'explain' => ['A blockchain is a ledger shared across a network. Transactions are grouped into blocks, and cryptographic hashes link the blocks and reveal changes to recorded data. Network participants follow shared rules to validate transactions.',
                 'Because copies of the ledger are kept by many participants, changing an established record is difficult: the network rules and cryptographic links expose it.'],
   'example' => 'Imagine a class record book copied by several students. If someone changes an old entry in only one copy, the other copies reveal the difference.',
   'remember' => 'Blockchains make unauthorised changes difficult, but they are not automatically error-free or immune to attacks.',
   'activity' => 'Build a paper blockchain with numbered blocks, then show what happens when someone tries to change an earlier record.'],

  ['n' => 3, 'week' => 2, 'title' => 'Cryptocurrency, Coins and Tokens', 'tag' => 'Understanding digital assets',
   'concepts' => ['Bitcoin and altcoins', 'Coins vs tokens', 'Stablecoins', 'Utility and governance tokens', 'Market cap and volatility'],
   'explain' => ['Cryptocurrency is a digital asset that uses cryptography and blockchain or related networks. Bitcoin was designed for peer-to-peer digital payments without a central payment operator.',
                 'A coin is usually the native asset of a blockchain; a token is created on an existing blockchain. Stablecoins aim to hold a steady value, often against a currency. Utility tokens give access to a product or service, and governance tokens may give holders a vote on project decisions.'],
   'example' => 'A network may use its native coin for transaction fees, while an app on that network issues a separate token for membership or voting.',
   'remember' => 'Stablecoins can lose their peg. Market capitalisation is roughly price × circulating supply, and crypto prices can swing sharply.',
   'activity' => 'Sort a list of sample digital assets by their purpose (payment, stable value, utility, governance) without buying anything.'],

  ['n' => 4, 'week' => 2, 'title' => 'Crypto Wallets and Seed Phrases', 'tag' => 'Your first step into digital ownership',
   'concepts' => ['Hot vs cold wallets', 'Custodial vs self-custody', 'Public address', 'Private key', 'Seed phrase', 'Network fees'],
   'explain' => ['A wallet is a tool for managing keys and interacting with digital assets. Your public address can be shared to receive assets. Your private key authorises transactions, and your seed phrase can restore access to the wallet.',
                 'Hot wallets are connected to the internet; cold wallets keep keys offline. With a custodial wallet a provider holds the keys; with self-custody you hold them yourself.'],
   'example' => 'Give a friend your public address so they can send you a supported asset. Never give anyone your private key or seed phrase.',
   'remember' => 'Check the network, the destination address and the fee before sending. A transfer on the wrong network or to the wrong address can be impossible to reverse.',
   'activity' => 'Explore a wallet interface with a demo or testnet wallet. Nobody should ever be asked to reveal a real seed phrase or private key.'],

  ['n' => 5, 'week' => 3, 'title' => 'Smart Contracts and dApps', 'tag' => 'How blockchain applications work',
   'concepts' => ['Smart contracts', 'dApps', 'Wallet connections', 'Permissions and approvals'],
   'explain' => ['A smart contract is a program deployed on a blockchain that runs according to programmed rules. A decentralised application (dApp) uses blockchain functionality as part of how it works.',
                 'Connecting your wallet lets an app request information or ask you to approve transactions. An approval can authorise a contract to access or move certain assets.'],
   'example' => 'A ticketing contract issues a digital ticket automatically once it receives a valid payment.',
   'remember' => 'Smart contracts can contain bugs. A wallet connection or approval is not automatically safe: read what you are signing.',
   'activity' => 'Design a simple digital agreement that releases a reward when a clearly defined condition is met.'],

  ['n' => 6, 'week' => 3, 'title' => 'Decentralised Finance (DeFi)', 'tag' => 'Financial services on blockchain',
   'concepts' => ['CeFi vs DeFi', 'CEX vs DEX', 'Liquidity pools and swaps', 'Lending, staking, yield farming', 'Gas, slippage, impermanent loss'],
   'explain' => ['DeFi uses blockchain applications to provide financial functions. A centralised exchange (CEX) is run by a company; a decentralised exchange (DEX) typically uses smart contracts to facilitate trades.',
                 'A liquidity pool is a set of assets deposited into a smart contract to support trading. A swap exchanges one asset for another and costs a gas fee. Slippage is the gap between the price you expect and the price you get. Liquidity providers can face impermanent loss when the prices of pooled assets move apart.'],
   'example' => 'Follow a sample token swap on a testnet and spot its estimated fee, the approvals it needs and the possible slippage.',
   'remember' => 'Returns are never guaranteed. Risks include contract exploits, liquidity problems and outright losses.',
   'activity' => 'Trace a sample swap on a block explorer or testnet and list every fee, approval and risk you can identify.'],

  ['n' => 7, 'week' => 4, 'title' => 'NFTs, Digital Ownership and Gaming', 'tag' => 'More than digital pictures',
   'concepts' => ['Non-fungible tokens', 'Collectibles and memberships', 'Tickets and gaming assets', 'Royalties and licensing', 'Ownership limits'],
   'explain' => ['An NFT is a distinct blockchain token that can represent a specific digital or physical item, or a claim related to it. Unlike coins, each NFT has its own identity and is not interchangeable.',
                 'Owning an NFT does not automatically mean owning the copyright or having unlimited rights to use the artwork. Your rights depend on the terms attached and the law.'],
   'example' => 'A creator issues NFT membership cards that give holders access to a community event.',
   'remember' => 'Check what an NFT actually grants, where its content is stored, and what licence applies.',
   'activity' => 'Design an NFT membership-card concept for a community, a creator or a local business.'],

  ['n' => 8, 'week' => 4, 'title' => 'Blockchain Networks and Ecosystems', 'tag' => 'Understanding different blockchains',
   'concepts' => ['Bitcoin, Ethereum, Solana, Stellar, Dogecoin', 'Layer 1 vs Layer 2', 'Speed, cost and security trade-offs', 'Bridges and interoperability', 'Block explorers'],
   'explain' => ['Different blockchains use different designs and rules. A Layer 1 is a base blockchain; Layer 2 systems work on top of a base network to improve capacity or cost.',
                 'Interoperability is about different systems working together; bridges move assets or information between networks. A block explorer lets anyone inspect public blockchain data.'],
   'example' => 'Search a transaction on a public block explorer and read its status, destination address, fee and block.',
   'remember' => 'Every network trades off speed, fees, security and decentralisation. Bridges add extra risk.',
   'activity' => 'Compare two networks on public block explorers and inspect their transaction details, fees and activity.'],

  ['n' => 9, 'week' => 5, 'title' => 'Security, Scams and Risk Management', 'tag' => 'Protect yourself before exploring',
   'concepts' => ['Phishing and fake websites', 'Impersonation', 'Fake airdrops and giveaways', 'Malicious approvals', 'Rug pulls'],
   'explain' => ['Scammers imitate trusted projects, offer fake rewards, send suspicious links and pressure people to act fast. A rug pull is when a project is abandoned or used deceptively in a way that harms participants.',
                 'Verify websites and social accounts yourself, review wallet permissions, secure your accounts, and never act under pressure.'],
   'example' => 'A message offers free tokens but asks for your recovery phrase. That is a major warning sign: real support never needs your seed phrase.',
   'remember' => 'If it promises guaranteed profit, demands urgency, or asks for secrets, stop and verify.',
   'activity' => 'Review a set of simulated scam messages and point out every red flag before interacting.'],

  ['n' => 10, 'week' => 5, 'title' => 'Web3 Careers and Creator Opportunities', 'tag' => 'Turning knowledge into useful skills',
   'concepts' => ['Community management', 'Content and storytelling', 'Research and design', 'Partnerships and ambassadors', 'Freelancing and portfolios'],
   'explain' => ['Web3 projects need more than programmers. They need people who explain concepts, support users, run and moderate communities, research projects, design, and communicate with audiences.',
                 'Business development, education, support and development roles are all open to people who can show real, verifiable work.'],
   'example' => 'Build a portfolio of educational posts that explain blockchain terms, and practise moderating a community with clear guidelines. (This is exactly what BMA interns do.)',
   'remember' => 'Focus on skills you can demonstrate and credible work samples, not promises of quick income or token rewards.',
   'activity' => 'Create a beginner Web3 profile and pick three roles or skills to develop next.'],

  ['n' => 11, 'week' => 6, 'title' => 'Building in Web3 and Finding Opportunities', 'tag' => 'From learning to contributing',
   'concepts' => ['Researching projects', 'Reading documentation', 'GitHub and open source', 'Hackathons, grants, bounties', 'Personal branding and networking'],
   'explain' => ['Before contributing to a project, research the problem it solves, read its documentation, confirm its official channels and judge whether its claims are credible.',
                 'Open-source software lets others use and contribute to the code under a licence. Hackathons are events where people build and present projects; grants fund eligible work; bounties reward a defined task.'],
   'example' => "Research a project, identify who it's for, verify its official website, and propose one improvement to its documentation.",
   'remember' => 'Opportunities can be competitive, conditional or fraudulent. Check eligibility and terms before sharing information or doing work.',
   'activity' => 'Research one project, explain the problem it solves, verify its official channels and present one way you could contribute.'],

  ['n' => 12, 'week' => 6, 'title' => 'Graduation and Your First Web3 Project', 'tag' => 'Put your knowledge into practice',
   'concepts' => ['Concept review', 'Real-world use cases', 'Project presentation', 'Risk assessment', '30-day learning roadmap'],
   'explain' => ['The final module brings everything together. You explain a real-world use case, present a small project or initiative, identify its risks and decide what to learn next.'],
   'example' => 'Propose a community event ticketing system: who it serves, why blockchain helps, its limitations and its security concerns.',
   'remember' => 'A good beginner project shows understanding and responsible research, not how much crypto you own.',
   'activity' => 'Present your final project: what you learned, the risks you considered, and your personal 30-day roadmap.'],
];

/* How a lesson runs + how to pace the course (one table, not two) */
$LESSON_FLOW = [
  ['Learn', '10 min', 'One concept in everyday language with familiar examples.'],
  ['Discuss', '5 min', 'Questions, then explain the idea in your own words.'],
  ['Demonstrate', '10 min', 'A diagram, a wallet interface, a block explorer or a testnet example.'],
  ['Practise', '5 min', 'A small task you can complete on your own.'],
];
$STUDY_PLAN = [
  [1, '1–2', 'Understand Web3 and blockchain fundamentals'],
  [2, '3–4', 'Learn digital assets and wallet security'],
  [3, '5–6', 'Understand smart contracts and DeFi risks'],
  [4, '7–8', 'Explore NFTs and blockchain networks'],
  [5, '9–10', 'Practise scam detection and explore careers'],
  [6, '11–12', 'Research a project and present your final idea'],
];

$GLOSSARY = [
  ['Web3', 'An internet vision built on blockchain, digital assets and decentralised participation.'],
  ['Blockchain', 'A ledger that records transactions in linked blocks.'],
  ['Decentralisation', 'Spreading control across many participants instead of one central authority.'],
  ['Cryptocurrency', 'A digital asset secured with cryptographic techniques.'],
  ['Coin', 'Usually the native asset of a blockchain.'],
  ['Token', 'A digital asset issued on an existing blockchain.'],
  ['Stablecoin', 'A token designed to hold a steady value, often pegged to a currency.'],
  ['Wallet', 'A tool for managing keys and interacting with blockchain assets.'],
  ['Public address', 'An address you can share to receive digital assets.'],
  ['Private key', 'A secret credential that authorises transactions.'],
  ['Seed phrase', 'A recovery phrase that restores wallet access. Never share it.'],
  ['Smart contract', 'A blockchain program that runs according to programmed rules.'],
  ['dApp', 'A decentralised application that uses blockchain functionality.'],
  ['DeFi', 'Decentralised finance: financial services built on blockchain apps.'],
  ['NFT', 'A distinct, non-fungible blockchain token.'],
  ['Gas fee', 'A fee paid to process a blockchain operation.'],
  ['Slippage', 'The difference between the expected and actual price of a trade.'],
  ['Block explorer', 'A website for inspecting public blockchain records.'],
  ['Layer 1', 'A base blockchain network.'],
  ['Layer 2', 'A system built on a base blockchain, often to make it faster or cheaper.'],
  ['Bridge', 'A tool that moves assets or information between blockchains.'],
  ['Phishing', 'A deceptive attempt to steal sensitive information or access.'],
  ['Rug pull', 'A project abandoned or used deceptively in a way that harms participants.'],
];

$COMPARISONS = [
  ['id' => 'web', 'label' => 'Web2 vs Web3', 'a' => 'Web2', 'b' => 'Web3', 'rows' => [
    ['Often relies on centrally operated platforms', 'Can use decentralised networks'],
    ['Accounts commonly controlled by service providers', 'Some apps allow wallet-based participation'],
    ['Data and platform rules managed by companies', 'Some records and rules kept by blockchain protocols'],
    ['Users depend on platform policies', 'Users may have more direct control, and more responsibility'],
  ], 'note' => 'General distinctions, not absolute rules: many Web3 apps still depend on centralised services.'],
  ['id' => 'custody', 'label' => 'Custodial vs self-custody', 'a' => 'Custodial', 'b' => 'Self-custody', 'rows' => [
    ['A provider controls the private keys', 'You control the private keys'],
    ['Provider may help you recover the account', 'Recovery depends on protecting your seed phrase'],
    ["You depend on the provider's policies and security", 'You carry more responsibility for security'],
  ], 'note' => ''],
  ['id' => 'ex', 'label' => 'CEX vs DEX', 'a' => 'CEX', 'b' => 'DEX', 'rows' => [
    ['A centralised exchange operated by a company', 'A decentralised exchange run by smart contracts'],
    ['The company holds custody during trading', 'You trade from your own wallet'],
  ], 'note' => 'Neither type is automatically risk-free.'],
  ['id' => 'coin', 'label' => 'Coins vs tokens', 'a' => 'Coin', 'b' => 'Token', 'rows' => [
    ["Native to its own blockchain", "Built on an existing blockchain's infrastructure"],
    ['Often pays the network fees', 'Often used for an app: membership, voting, access'],
  ], 'note' => ''],
];

/* One merged list: the syllabus safety principles + the study guide's security section */
$SAFETY = [
  ['Protect your recovery credentials', 'Never share your seed phrase, private key or wallet recovery code. Real support never asks for them.'],
  ['Verify official sources', 'Check websites, contract addresses and social accounts independently before you trust them.'],
  ['Inspect links and approvals', 'Avoid suspicious links and understand exactly what a wallet approval authorises before you sign.'],
  ['Distrust guaranteed returns', 'Promises of guaranteed profit, urgency, secret opportunities and surprise rewards are warning signs.'],
  ['Practise on testnets first', 'Use demo wallets and testnets for anything unfamiliar. Blockchain transactions can be irreversible.'],
  ['Never risk what you cannot lose', 'Crypto assets are volatile and projects can fail.'],
];

$QUIZ = [
  ['What is the main idea behind Web3?', ['Making every website anonymous', 'Using blockchain and decentralised systems for digital participation', 'Replacing all computers with cryptocurrencies', 'Making every online service free'], 1, 'Web3 emphasises blockchain-based applications, digital assets and decentralised participation.'],
  ['What is the primary purpose of a blockchain?', ['To store photographs only', 'To guarantee investment profits', 'To maintain a ledger of recorded transactions', 'To prevent every type of cyberattack'], 2, 'A blockchain records transactions in linked blocks according to network rules.'],
  ['What is the difference between a coin and a token?', ['Coins are always stable; tokens are always volatile', 'A coin is generally native to a blockchain; a token uses existing blockchain infrastructure', 'They are always identical', 'Tokens cannot have a use case'], 1, 'This is the standard distinction from Module 3.'],
  ['Which wallet information must remain secret?', ['Your public receiving address', 'A public transaction ID', 'Your private key and seed phrase', 'The name of a blockchain'], 2, 'Private keys and seed phrases can grant control over your wallet.'],
  ['What is a smart contract?', ['A paper agreement signed by a bank', 'A blockchain program that follows programmed rules', 'A type of computer monitor', 'A cryptocurrency price chart'], 1, 'Smart contracts execute programmed logic on a blockchain.'],
  ['What does slippage mean in a token swap?', ['The difference between expected and actual execution price', 'The time needed to download an app', 'A wallet recovery process', 'A type of NFT'], 0, 'The execution price can differ from the expected price because of market and transaction conditions.'],
  ['Does owning an NFT automatically give you copyright?', ['Yes, in every case', 'Only if the NFT is expensive', 'No, rights depend on the applicable terms and law', 'Yes, if it is on a public blockchain'], 2, 'Owning a token and owning intellectual property rights are different things.'],
  ['What is a block explorer used for?', ['Creating private keys for other people', 'Inspecting blockchain transactions and addresses', 'Guaranteeing that a project is legitimate', 'Reversing every transaction'], 1, 'Block explorers display publicly available blockchain information.'],
  ['Someone asks for your seed phrase to unlock a free reward. What do you do?', ['Share it if the website looks professional', 'Share only half of it', 'Refuse and verify the claim independently', 'Pay a fee first'], 2, 'A request for your seed phrase is a major security warning.'],
  ['What is a suitable beginner Web3 project?', ['Promising guaranteed token returns', 'Creating an educational resource and documenting its risks', "Collecting other people's recovery phrases", 'Investing all your money in a new token'], 1, 'The course prioritises learning, practical skills and responsible participation.'],
];

$PRACTICE = [
  ['Explain the difference between a centralised and a decentralised system.', 'Centralisation places control with a central organisation. Decentralisation spreads some control across many participants or network components.'],
  ['Why are cryptographic hashes useful in a blockchain?', 'A hash turns data into a fixed-length output. Change the data and the hash changes, which links blocks together and reveals tampering.'],
  ['What is the difference between a public address, a private key and a seed phrase?', 'A public address can be shared to receive assets. A private key authorises transactions. A seed phrase recovers wallet access and must stay secret.'],
  ['How could a smart contract be used for event ticketing?', 'The contract issues a digital ticket once it receives a valid payment and the programmed conditions are met.'],
  ['Name three risks of DeFi.', 'Smart-contract bugs, price slippage, impermanent loss, liquidity problems, high fees and fraudulent protocols.'],
  ['How would you investigate a transaction on a block explorer?', 'Search the transaction ID and check its status, sender, recipient, block details and fee.'],
  ['List five warning signs of a Web3 scam.', 'Requests for recovery phrases, guaranteed returns, urgency, impersonation, suspicious links and fake giveaways.'],
  ['Name three Web3 careers that do not need programming.', 'Community management, moderation, content creation, research, design, storytelling, education and user support.'],
];

$ASSESSMENT = [['Module quizzes', 25], ['Practical exercises', 35], ['Final project presentation', 30], ['Participation and peer learning', 10]];

$CHECKLIST = [
  'I can explain Web1, Web2 and Web3.',
  'I understand blocks, transactions, hashes and distributed ledgers.',
  'I can tell coins, tokens, stablecoins and NFTs apart.',
  'I understand public addresses, private keys and seed phrases.',
  'I can explain smart contracts, dApps and DeFi.',
  'I understand blockchain networks, Layer 1, Layer 2 and block explorers.',
  'I can recognise common scams and describe safe practices.',
  'I can identify Web3 careers and research a project responsibly.',
  'I can present a beginner project and explain its risks.',
];

$RESOURCES = [
  ['Bitcoin.org: beginner resources', 'https://bitcoin.org/en/', 'General Bitcoin learning.'],
  ['The Bitcoin white paper', 'https://bitcoin.org/bitcoin.pdf', 'The original paper describing Bitcoin.'],
  ['Ethereum learning hub', 'https://ethereum.org/en/learn/', 'Accounts, smart contracts and dApps.'],
  ['Etherscan', 'https://etherscan.io/', 'Explore public Ethereum transactions without connecting a wallet.'],
  ['Blockchair', 'https://blockchair.com/', 'Public data across many blockchains, including Dogecoin.'],
  ['GitHub Skills', 'https://skills.github.com/', 'Beginner activities for collaborative development.'],
];
