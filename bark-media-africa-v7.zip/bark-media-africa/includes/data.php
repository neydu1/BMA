<?php
/* =================================================================
   CONTENT — add/edit items in these arrays.
   ================================================================= */

$GREETINGS = [
  ['Ẹ káàbọ̀', 'Yoruba'], ['Karibu', 'Swahili'], ['Akwaaba', 'Twi'],
  ['Sannu', 'Hausa'], ['Nnọọ', 'Igbo'], ['Siyakwamukela', 'Zulu'], ['Welcome', 'English'],
];

$SERVICES = [
  ['title' => 'Crypto onboarding', 'summary' => 'From your first wallet to confident trading.',
   'body' => 'Step-by-step guidance built around African realities: mobile money, P2P safety, bank restrictions and the DoginalDogs ordinals ecosystem.',
   'symbol' => 'Adinkrahene', 'meaning' => 'leadership'],
  ['title' => 'Social media monetization', 'summary' => 'Turn your reach on X into income.',
   'body' => 'We help African creators earn from X, Spaces, sponsorships and decentralized social platforms through real partnerships.',
   'symbol' => 'Nkyinkyim', 'meaning' => 'initiative'],
  ['title' => 'X account management', 'summary' => 'Trained BMA interns run your account.',
   'body' => "Our members curate feeds, host Spaces and keep your project's community active and genuine, around the clock.",
   'symbol' => 'Nsoromma', 'meaning' => 'guardianship'],
  ['title' => 'Web3 experiences', 'summary' => 'Sites and tools that feel alive.',
   'body' => 'Interactive interfaces, AI assistance and live community features for projects that want more than a template.',
   'symbol' => 'Eban', 'meaning' => 'security'],
];

$OFFERS = [
  ['title' => 'Hire a trained intern', 'body' => 'Keep your crypto account active and growing with vetted BMA members.', 'cta' => 'Hire an intern', 'link' => 'join.php?focus=Hire+an+account+intern', 'tag' => 'Most requested'],
  ['title' => 'Space hosts & stages', 'body' => "Book BMA hosts for your project's X Space, or join our weekly stages.", 'cta' => 'See Spaces', 'link' => 'spaces.php', 'tag' => 'Weekly'],
  ['title' => 'Community books', 'body' => 'Publications by African blockchain writers, from African perspectives.', 'cta' => 'Ask about the library', 'link' => 'join.php?focus=Books+%26+merch', 'tag' => 'Original'],
  ['title' => 'BMA merchandise', 'body' => 'African Doge hoodies, caps, bottles and sleeves, shipped worldwide.', 'cta' => 'Shop the merch', 'link' => 'shop.php', 'tag' => 'Now in the shop'],
];

// lat/lng feed the 3D globe on the homepage
$NATIONS = [
  ['flag' => '🇳🇬', 'name' => 'Nigeria',      'members' => 110, 'cities' => 'Lagos, Abuja',            'lat' => 9.06,   'lng' => 7.49],
  ['flag' => '🇿🇦', 'name' => 'South Africa', 'members' => 55,  'cities' => 'Cape Town, Johannesburg', 'lat' => -33.92, 'lng' => 18.42],
  ['flag' => '🇬🇭', 'name' => 'Ghana',        'members' => 38,  'cities' => 'Accra',                   'lat' => 5.60,   'lng' => -0.19],
  ['flag' => '🇺🇬', 'name' => 'Uganda',       'members' => 24,  'cities' => 'Kampala',                 'lat' => 0.35,   'lng' => 32.58],
  ['flag' => '🇹🇿', 'name' => 'Tanzania',     'members' => 19,  'cities' => 'Dar es Salaam',           'lat' => -6.79,  'lng' => 39.21],
  ['flag' => '🇪🇹', 'name' => 'Ethiopia',     'members' => 15,  'cities' => 'Addis Ababa',             'lat' => 9.03,   'lng' => 38.74],
];
$EXTRA_COUNTRIES = ['Kenya 🇰🇪', 'Egypt 🇪🇬', 'Rwanda 🇷🇼', 'Cameroon 🇨🇲', 'Morocco 🇲🇦', 'Other / Diaspora 🌍'];

$FOCUS_OPTIONS = ['Crypto onboarding', 'Social media monetization', 'Hire an account intern',
                  'Hosting a Space with BMA', 'Books & merch', 'Becoming a country lead'];

$VALUES = [
  ['title' => 'Ubuntu',   'meaning' => 'I am because we are',  'body' => 'We grow together. Every member who learns teaches the next.'],
  ['title' => 'Harambee', 'meaning' => 'All pull together',    'body' => 'Projects win when the whole community pushes in one direction.'],
  ['title' => 'Sankofa',  'meaning' => 'Go back and fetch it', 'body' => 'We carry African stories and values into the future we build.'],
];

$MILESTONES = [
  ['when' => 'The start',        'text' => 'One X audio Space with a handful of African DoginalDogs holders.'],
  ['when' => 'Growth',           'text' => 'Weekly Spaces with guests from across Africa and the global Web3 scene.'],
  ['when' => 'Intern programme', 'text' => 'Members trained to manage and grow X accounts for Web3 projects.'],
  ['when' => 'Today',            'text' => '250+ members across 6 nations, with country leads being recruited.'],
];

/* EVENTS — SAMPLE ENTRIES, replace with real posts from x.com/Barkmediafrica
   type: Space | AMA | Meetup | Workshop | Contest */
$EVENTS = [
  ['title' => 'Lagos Web3 Night', 'date' => '2026-09-27T19:00:00+01:00', 'type' => 'Space', 'host' => '@Barkmediafrica', 'guests' => 'DoginalDogs builders', 'listeners' => 1200,
   'summary' => 'An evening Space on the state of Doginals in Africa and how new holders can get started safely.', 'link' => 'https://x.com/Barkmediafrica'],
  ['title' => 'Onboarding clinic: wallets & P2P safety', 'date' => '2026-09-20T17:00:00+01:00', 'type' => 'Workshop', 'host' => 'BMA onboarding team', 'guests' => '', 'listeners' => 340,
   'summary' => 'Live walkthrough of wallet setup, seed phrase safety and avoiding P2P scams.', 'link' => 'https://x.com/Barkmediafrica'],
  ['title' => 'Creators getting paid on X', 'date' => '2026-09-12T20:00:00+01:00', 'type' => 'AMA', 'host' => '@Barkmediafrica', 'guests' => 'African creators', 'listeners' => 860,
   'summary' => 'Creators shared how they qualified for X payouts and landed their first project sponsorships.', 'link' => 'https://x.com/Barkmediafrica'],
  ['title' => 'Abuja community hangout', 'date' => '2026-08-30T15:00:00+01:00', 'type' => 'Meetup', 'host' => 'BMA Nigeria', 'guests' => '', 'listeners' => 0,
   'summary' => 'In-person meetup for Abuja members, with a short intro session for newcomers.', 'link' => 'https://x.com/Barkmediafrica'],
];

/* SPACES — demo uses times relative to now (hours_from_now).
   For real use: 'start' => '2026-10-03T19:00:00+01:00', 'end' => null */
function hours_from_now($h) { return date('c', time() + (int) round($h * 3600)); }

$SPACES = [
  ['title' => 'Morning bark: market check-in', 'host' => '@Barkmediafrica', 'start' => hours_from_now(-0.5), 'end' => null,                 'listeners' => 214, 'topics' => ['Markets', 'Doginals']],
  ['title' => 'Getting your first Web3 job',    'host' => 'BMA Talent',        'start' => hours_from_now(-5),   'end' => hours_from_now(-3.5), 'listeners' => 532, 'topics' => ['Careers']],
  ['title' => 'South Africa chapter roll call', 'host' => 'BMA South Africa',  'start' => hours_from_now(-11),  'end' => hours_from_now(-9.5), 'listeners' => 188, 'topics' => ['Community']],
  ['title' => 'Doginals deep dive',             'host' => '@Barkmediafrica',  'start' => hours_from_now(-20),  'end' => hours_from_now(-18),  'listeners' => 940, 'topics' => ['Doginals', 'Education']],
  ['title' => 'Weekly Pan-African stage',       'host' => '@Barkmediafrica',  'start' => hours_from_now(6),    'end' => null,                 'listeners' => 0,   'topics' => ['Weekly']],
  ['title' => "Old Space (won't show in 24h)",  'host' => '@Barkmediafrica',  'start' => hours_from_now(-60),  'end' => hours_from_now(-58),  'listeners' => 400, 'topics' => ['Archive']],
];
foreach ($SPACES as &$s) { $s['link'] = $s['link'] ?? $SITE['xUrl']; } unset($s);

$FAQ = [
  ['q' => 'Who can join Bark Media Africa?', 'a' => 'Anyone in Africa or the diaspora who is curious about Web3. Beginners are welcome; our onboarding starts from zero.'],
  ['q' => 'Does it cost anything to join?',  'a' => 'Joining the community and our public Spaces is free. Some services, like hiring an intern for your project, are paid.'],
  ['q' => 'How do I hire an account intern?', 'a' => "Fill the join form and choose 'Hire an account intern'. Our team will reach out on Telegram or X to agree scope and pricing."],
  ['q' => "My country isn't listed. Can I still join?", 'a' => "Yes. We're recruiting country leads in Kenya, Egypt, Rwanda and more. Select your country in the form and tell us you'd like to lead."],
];

/* ---------- Homepage extras ---------- */
$STEPS = [
  ['title' => 'Join a Space', 'body' => 'Drop into one of our weekly X Spaces. Listen first, ask questions when you are ready. No wallet needed.', 'icon' => 'mic'],
  ['title' => 'Get onboarded', 'body' => 'Our onboarding team walks you through wallets, P2P safety and Doginals, one step at a time.', 'icon' => 'wallet'],
  ['title' => 'Earn and lead', 'body' => 'Grow your audience, join the intern programme, or start a BMA chapter in your country.', 'icon' => 'rise'],
];

/* Gallery: 'src' = photo URL or path (e.g. assets/images/gallery/lagos.jpg).
   Tiles with no src show as a designed event poster. Replace with real event photos. */
$GALLERY = [
  ['src' => $SITE['communityImage'], 'caption' => 'BMA community gathering', 'size' => 'tall'],
  ['src' => '', 'caption' => 'Lagos Web3 Night', 'meta' => '1,200 listeners', 'tone' => 'gold'],
  ['src' => '', 'caption' => 'Onboarding clinic', 'meta' => 'Wallets & P2P safety', 'tone' => 'green'],
  ['src' => $SITE['heroImage'], 'caption' => 'The African Doge totem', 'size' => 'wide'],
  ['src' => '', 'caption' => 'Abuja hangout', 'meta' => 'In person', 'tone' => 'red'],
  ['src' => '', 'caption' => 'Creators getting paid', 'meta' => 'AMA on X', 'tone' => 'indigo'],
];

/* SAMPLE quotes — replace with real member quotes (with permission). */
$VOICES = [
  ['quote' => 'I joined a Space not knowing what a wallet was. Three weeks later I was helping newcomers in the Telegram.', 'name' => 'Member, Abuja', 'tag' => 'Onboarding'],
  ['quote' => 'The intern programme gave me my first paid Web3 role. I manage two project accounts now.', 'name' => 'Intern, Accra', 'tag' => 'Intern programme'],
  ['quote' => 'Our project hired BMA hosts for launch week. The Space was full and the questions were sharp.', 'name' => 'Project founder', 'tag' => 'Space hosting'],
  ['quote' => 'Finally a crypto community that understands bank restrictions and P2P in Africa.', 'name' => 'Member, Nairobi', 'tag' => 'Community'],
  ['quote' => 'I qualified for X payouts after the creators AMA. The advice was practical, not hype.', 'name' => 'Creator, Lagos', 'tag' => 'Monetization'],
  ['quote' => 'Ubuntu is real here. People share what they know without gatekeeping.', 'name' => 'Member, Cape Town', 'tag' => 'Community'],
];

/* ---------- v4: Doginal Dogs ecosystem news (from public reports; refresh from x.com/Barkmediafrica) ---------- */
$NEWS = [
  ['date' => '2026-09-13', 'tag' => 'Doginal Dogs', 'title' => 'DDNYC 2026 posts record turnout',
   'body' => 'The sold-out flagship (Sept 2–4, Dream Downtown, New York) was a full hotel takeover with the DD Awards, a rooftop party and a post-event rating of 9.95/10.',
   'source' => 'Newsfile', 'url' => 'https://www.newsfilecorp.com/release/313975'],
  ['date' => '2026-09-04', 'tag' => 'Games', 'title' => 'Legends card game debuts in person',
   'body' => 'Doginal Dogs Legends had its first live pack-opening and tournament at DDNYC, after its preorder sold out on day one.',
   'source' => 'Newsfile', 'url' => 'https://www.newsfilecorp.com/release/313975'],
  ['date' => '2026-09-03', 'tag' => 'Giving back', 'title' => 'Plush toys for kids in Harlem',
   'body' => "The community's Do Only Good Everyday Foundation donated hundreds of plush toys to children during DDNYC week.",
   'source' => 'Newsfile', 'url' => 'https://www.newsfilecorp.com/release/313975'],
  ['date' => '2026-08-11', 'tag' => 'On X', 'title' => '"This Is Me" goes viral',
   'body' => 'Holders are posting their real face next to their Doginal Dog. Our pack is joining in: tag @Barkmediafrica with yours.',
   'source' => 'TechBullion', 'url' => 'https://techbullion.com/the-most-active-nft-community-in-2026-doginal-dogs-goes-viral-with-a-new-trend/'],
  ['date' => '2026-04-01', 'tag' => 'Milestone', 'title' => '1,000+ daily broadcasts and counting',
   'body' => 'The Doginal Dogs daily show passed 1,000 consecutive sessions. 10,000 pixel dogs, inscribed on Dogecoin since the free mint of Jan 11, 2024.',
   'source' => 'TechBullion', 'url' => 'https://techbullion.com/doginal-dogs-a-full-history-of-the-number-one-nft-collection-on-dogecoin/'],
];

/* ---------- v4: Pack Council proposals (Web3 hub). Votes are saved in storage/votes.json ---------- */
$PROPOSALS = [
  ['id' => 'meetup-2027', 'title' => 'Where should the first BMA meetup of 2027 land?', 'body' => 'The winning city gets an in-person night plus a live X Space.',
   'options' => ['Lagos', 'Accra', 'Nairobi', 'Johannesburg'], 'closes' => '2026-11-30'],
  ['id' => 'space-series', 'title' => 'Next Space series theme', 'body' => 'A four-week run of Spaces on one topic.',
   'options' => ['Doginals 101 in local languages', 'Getting paid as a creator on X', 'Building on Dogecoin', 'Women in Web3 Africa'], 'closes' => '2026-11-15'],
  ['id' => 'two-paws-cup', 'title' => 'Run a pan-African Two Paws Cup with merch prizes?', 'body' => 'Nation teams play for the top of the leaderboard over two weeks.',
   'options' => ['Yes, run it', 'Not yet'], 'closes' => '2026-10-31'],
];

/* ---------- v4: Two Paws game teams ---------- */
$GAME_TEAMS = array_merge(array_column($NATIONS, 'name'), ['Kenya', 'Egypt', 'Rwanda', 'Cameroon', 'Morocco', 'Diaspora']);
$TEAM_FLAGS = ['Nigeria' => '🇳🇬', 'South Africa' => '🇿🇦', 'Ghana' => '🇬🇭', 'Uganda' => '🇺🇬', 'Tanzania' => '🇹🇿', 'Ethiopia' => '🇪🇹',
  'Kenya' => '🇰🇪', 'Egypt' => '🇪🇬', 'Rwanda' => '🇷🇼', 'Cameroon' => '🇨🇲', 'Morocco' => '🇲🇦', 'Diaspora' => '🌍'];

/* ---------- v7: regular fixtures shown under "Coming up" on the Events page.
   For a dated event, add it to $EVENTS above with a future 'date' and it appears
   at the top of "Coming up" automatically (and in the site pop-up). ---------- */
$REGULAR = [
  ['title' => 'Weekly Pan-African stage', 'type' => 'Space', 'when' => 'Every week on X', 'body' => 'Our flagship X Space: Doginals news, guests from across Africa and open mic for newcomers.', 'link' => $SITE['xUrl']],
  ['title' => 'Web3 Made Simple: live class', 'type' => 'Workshop', 'when' => '30-minute lessons, schedule posted on X', 'body' => 'Learn, discuss, demonstrate, practise. One Academy module per session, beginners welcome.', 'link' => 'academy.php'],
  ['title' => 'Onboarding clinic', 'type' => 'Workshop', 'when' => 'Announced on X', 'body' => 'Wallet setup, seed phrase safety and avoiding P2P scams, step by step.', 'link' => $SITE['xUrl']],
];
