<?php
/* =================================================================
   Two Paws leaderboard + X identity helpers
   Runs are kept in storage/leaderboard.data.php (web access blocked).
   ================================================================= */

const TP_CHAPTERS = 4;
const TP_MAX_COINS = 72;          // total Doge coins across the four chapters (assets/js/levels.js)
const TP_CHARS = ['rose', 'jollof', 'prism', 'chairman'];

/** Same formula as score() in assets/js/game.js. The server always recomputes it. */
function tp_score(int $levels, int $coins, float $time, int $deaths): int {
  $bonus = $levels >= TP_CHAPTERS ? max(0, 900 - (int) round($time)) * 5 : 0;
  return max(0, $levels * 1000 + $coins * 100 + $bonus - $deaths * 25);
}

/* Data files start with an exit guard, so they stay private even on hosts that ignore .htaccess. */
const DATA_GUARD = "<?php exit; ?>\n";
function tp_file() { return STORAGE_DIR . '/leaderboard.data.php'; }
function data_decode($raw) {
  $raw = (string) $raw;
  if (strpos($raw, DATA_GUARD) === 0) $raw = substr($raw, strlen(DATA_GUARD));
  $d = json_decode($raw ?: '[]', true);
  return is_array($d) ? $d : [];
}
function data_write($fh, $data) {
  ftruncate($fh, 0); rewind($fh);
  fwrite($fh, DATA_GUARD . json_encode($data, JSON_UNESCAPED_UNICODE));
  fflush($fh);
}

function tp_load(): array {
  $f = tp_file();
  return file_exists($f) ? data_decode(@file_get_contents($f)) : [];
}

/** Append a run under an exclusive lock; keeps the best 2,000. */
function tp_add(array $run): array {
  if (!is_dir(STORAGE_DIR)) @mkdir(STORAGE_DIR, 0755, true);
  $fh = fopen(tp_file(), 'c+');
  if (!$fh) return [];
  flock($fh, LOCK_EX);
  $runs = data_decode(stream_get_contents($fh));
  $runs[] = $run;
  usort($runs, fn($a, $b) => $b['score'] <=> $a['score'] ?: $a['time'] <=> $b['time']);
  $runs = array_slice($runs, 0, 2000);
  data_write($fh, $runs);
  flock($fh, LOCK_UN); fclose($fh);
  return $runs;
}

function tp_handle($h): string {
  $h = ltrim(trim((string) $h), '@');
  if (preg_match('~(?:x|twitter)\.com/([A-Za-z0-9_]{1,15})~i', $h, $m)) $h = $m[1];
  return preg_match('/^[A-Za-z0-9_]{1,15}$/', $h) ? $h : '';
}

function tp_player(string $handle, string $slot): array {
  $x = $_SESSION['x'][$slot] ?? null;
  $verified = $x && strcasecmp($x['username'], $handle) === 0;
  return [
    'handle' => $handle,
    'name' => $verified ? $x['name'] : '',
    'avatar' => $verified && !empty($x['avatar']) ? $x['avatar'] : ($handle ? 'https://unavatar.io/x/' . rawurlencode($handle) : ''),
    'verified' => (bool) $verified,
  ];
}

/** Team table: power = average of a team's best three runs, so a big team can't win on volume alone. */
function tp_teams(array $runs): array {
  global $TEAM_FLAGS;
  $by = [];
  foreach ($runs as $r) $by[$r['team']][] = $r;
  $out = [];
  foreach ($by as $team => $list) {
    usort($list, fn($a, $b) => $b['score'] <=> $a['score']);
    $top = array_slice($list, 0, 3);
    $players = [];
    foreach ($list as $r) foreach (['p1', 'p2'] as $p) if (!empty($r[$p]['handle'])) $players[strtolower($r[$p]['handle'])] = 1;
    $out[] = [
      'team' => $team, 'flag' => $TEAM_FLAGS[$team] ?? '🌍',
      'power' => (int) round(array_sum(array_column($top, 'score')) / count($top)),
      'best' => $list[0]['score'], 'runs' => count($list), 'players' => count($players),
      'duo' => [$list[0]['p1'], $list[0]['p2']], 'chars' => $list[0]['chars'] ?? [],
    ];
  }
  usort($out, fn($a, $b) => $b['power'] <=> $a['power']);
  return $out;
}

function tp_public(array $runs, int $n = 25): array {
  return array_map(fn($r) => [
    'score' => $r['score'], 'team' => $r['team'], 'p1' => $r['p1'], 'p2' => $r['p2'], 'chars' => $r['chars'],
    'levels' => $r['levels'], 'time' => $r['time'], 'coins' => $r['coins'], 'deaths' => $r['deaths'], 'mode' => $r['mode'], 'at' => $r['at'],
  ], array_slice($runs, 0, $n));
}

/* ---------- X OAuth 2.0 (PKCE) ---------- */
function x_configured(): bool { return defined('X_CLIENT_ID') && X_CLIENT_ID !== ''; }

function base_url(): string {
  if (SITE_URL) return rtrim(SITE_URL, '/');
  $https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || ($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https';
  $dir = rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'])), '/');
  $dir = preg_replace('~/(api|admin)$~', '', $dir);
  return ($https ? 'https' : 'http') . '://' . $_SERVER['HTTP_HOST'] . $dir;
}

function x_http(string $method, string $url, array $headers = [], $body = null): array {
  $ch = curl_init($url);
  curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 15, CURLOPT_CUSTOMREQUEST => $method, CURLOPT_HTTPHEADER => $headers]);
  if ($body !== null) curl_setopt($ch, CURLOPT_POSTFIELDS, $body);
  $res = curl_exec($ch);
  $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
  curl_close($ch);
  return [$code, json_decode((string) $res, true)];
}
