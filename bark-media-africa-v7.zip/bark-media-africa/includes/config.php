<?php
/* =================================================================
   BARK MEDIA AFRICA — SITE CONFIG
   Edit this file first. Everything else reads from here.
   ================================================================= */

// ---- Who gets notified when someone joins or subscribes ----------
define('ADMIN_EMAIL', 'barkmediafrica@gmail.com');        // TODO: your inbox
define('ADMIN_NAME',  'BMA Admin');

// ---- Outgoing mail (SMTP) ----------------------------------------
// Use your host's mailbox (cPanel "Email Accounts") or Gmail/Zoho/Brevo.
// If SMTP_HOST is left empty, PHP's built-in mail() is used instead.
define('SMTP_HOST',   'mail.barkmediafrica.com'); // e.g. smtp.gmail.com
define('SMTP_PORT',   465);                        // 465 = SSL, 587 = TLS
define('SMTP_SECURE', 'ssl');                      // 'ssl' or 'tls'
define('SMTP_USER',   'admin@barkmediafrica.com');
define('SMTP_PASS',   '@Barkmedia001');
define('MAIL_FROM',      'admin@barkmediafrica.com');
define('MAIL_FROM_NAME', 'Bark Media Africa');

// Send a "welcome" email to the new member / subscriber too?
define('SEND_CONFIRMATIONS', true);

// ---- Shop + Paystack ---------------------------------------------
// Get keys at dashboard.paystack.com > Settings > API Keys & Webhooks.
// Use the sk_test_/pk_test_ keys while testing, then switch to live.
define('PAYSTACK_SECRET_KEY', 'sk_test_xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
define('PAYSTACK_PUBLIC_KEY', 'pk_test_xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
define('SHOP_CURRENCY', 'NGN');          // Paystack currency: NGN, GHS, ZAR, KES, USD
define('SHOP_SYMBOL', '₦');

// Full public address of the site, no trailing slash. Leave '' to auto-detect.
define('SITE_URL', '');

// Password for /admin/orders.php (change this!)
define('ADMIN_PASSWORD', 'change-this-password');

// ---- Sign in with X (for the Two Paws leaderboard) ----------------
// Create an app at developer.x.com > Projects & Apps. Turn on OAuth 2.0
// (type: Web App), add the callback URL https://yourdomain.com/api/x-auth.php
// and paste the OAuth 2.0 Client ID / Secret here. Leave empty and players can
// still type their @handle (shown as "unverified" on the leaderboard).
define('X_CLIENT_ID', '');
define('X_CLIENT_SECRET', '');

// ---- Where submissions are saved (CSV backups) -------------------
define('STORAGE_DIR', __DIR__ . '/../storage');

date_default_timezone_set('Africa/Lagos');

$SITE = [
  'name'     => 'Bark Media Africa',
  'short'    => 'BMA',
  'tagline'  => 'DoginalDogs African Collective',
  'handle'   => '@Barkmediafrica',
  'xUrl'     => 'https://x.com/Barkmediafrica',
  'telegram' => 'https://t.me/barkmediaafrica',     // TODO: confirm
  'email'    => 'hello@Barkmediafrica.com',        // TODO: confirm
  'logo'     => 'assets/images/logo.png',
  'heroImage'      => 'https://vibe.filesafe.space/1789381503189835252/assets/6b47563c-c2f9-4721-87df-cc7a11d729e7.png',
  'communityImage' => 'https://vibe.filesafe.space/1789381503189835252/assets/5e037613-dca8-457b-ab07-22a414a0d4a8.png',
  'stats' => [
    ['value' => '250+', 'label' => 'active members'],
    ['value' => '6',    'label' => 'African nations'],
    ['value' => '42',   'label' => 'intern accounts managed'],
  ],
];

$NAV = [
  'index'    => 'Home',
  'about'    => 'About',
  'services' => 'Services',
  'events'   => 'Events',
  'spaces'   => 'Spaces 24h',
  'web3'     => 'Web3 Hub',
  'game'     => 'Game',
  'shop'     => 'Shop',
];

/* Header menu: top items with optional dropdowns.
   Each dropdown item: [link, title, one-line description] */
$MENU = [
  ['label' => 'Home', 'href' => 'index.php', 'pages' => ['index']],
  ['label' => 'Community', 'pages' => ['about', 'events', 'spaces', 'join'], 'items' => [
    ['about.php', 'About us', 'Our story, values and milestones'],
    ['events.php', 'Events', 'Spaces, AMAs, workshops and meetups'],
    ['spaces.php', 'Spaces 24h', 'Live now and the last 24 hours on X'],
    ['join.php', 'Join the pack', 'Free membership, start today'],
  ]],
  ['label' => 'Services', 'pages' => ['services', 'partner'], 'items' => [
    ['services.php', 'What we offer', 'Onboarding, monetization and account interns'],
    ['partner.php', 'Partner with us', 'For Web3 projects and investors'],
  ]],
  ['label' => 'Web3', 'pages' => ['web3', 'academy'], 'items' => [
    ['web3.php', 'Web3 Hub', 'Connect a wallet, watch Dogecoin live'],
    ['academy.php', 'Web3 Academy', 'Free beginner course in 12 modules'],
    ['web3.php#network', 'Find your chapter', 'Meet members in your nation'],
    ['web3.php#council', 'Pack Council', 'Vote on what the pack does next'],
    ['web3.php#safety', 'Stay safe', 'Scam check and safety rules'],
  ]],
  ['label' => 'Play', 'pages' => ['game'], 'items' => [
    ['game.php', 'Two Paws', 'Our co-op game, full screen'],
    ['game.php#board', 'Leaderboard', 'Which nation plays best'],
  ]],
  ['label' => 'Shop', 'href' => 'shop.php', 'pages' => ['shop', 'product', 'checkout', 'order-complete']],
];
