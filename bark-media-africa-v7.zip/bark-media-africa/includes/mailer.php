<?php
require_once __DIR__ . '/../lib/Exception.php';
require_once __DIR__ . '/../lib/PHPMailer.php';
require_once __DIR__ . '/../lib/SMTP.php';

use PHPMailer\PHPMailer\PHPMailer;

/**
 * Send an email. Returns true on success, or an error string.
 * $replyTo lets you hit "Reply" in your inbox and answer the member directly.
 *
 * With define('DEBUG_MAIL', true) in config.php, a failure also includes the last
 * lines of the SMTP conversation (credentials are masked) so you can see where it broke.
 */
function send_mail($to, $toName, $subject, $html, $replyTo = null, $replyName = '') {
  $m = new PHPMailer(true);
  $log = '';
  try {
    // Fail with a clear message instead of a fatal "undefined constant" error
    foreach (['MAIL_FROM', 'MAIL_FROM_NAME', 'SMTP_HOST'] as $c) {
      if (!defined($c)) return "Config problem: $c is not defined in config.php";
    }
    if (!filter_var(MAIL_FROM, FILTER_VALIDATE_EMAIL)) {
      return 'Config problem: MAIL_FROM ("' . MAIL_FROM . '") is not a valid email address';
    }
    if (!filter_var($to, FILTER_VALIDATE_EMAIL)) {
      return 'Recipient address is not valid: ' . $to;
    }

    if (SMTP_HOST !== '') {
      foreach (['SMTP_PORT', 'SMTP_USER', 'SMTP_PASS', 'SMTP_SECURE'] as $c) {
        if (!defined($c)) return "Config problem: $c is not defined in config.php";
      }
      $port = (int) SMTP_PORT;
      $secure = strtolower((string) SMTP_SECURE);

      $m->isSMTP();
      $m->Host = SMTP_HOST;
      $m->Port = $port;
      $m->SMTPAuth = SMTP_USER !== '';
      $m->Username = SMTP_USER;
      $m->Password = SMTP_PASS;

      // Port decides the encryption mode, which fixes the most common misconfiguration
      // (e.g. SMTP_SECURE = 'tls' with port 465, or 'ssl' with port 587).
      if ($port === 465)      $m->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;
      elseif ($port === 587)  $m->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
      elseif (in_array($secure, ['ssl', 'smtps'], true)) $m->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;
      elseif (in_array($secure, ['tls', 'starttls'], true)) $m->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
      else { $m->SMTPSecure = ''; $m->SMTPAutoTLS = false; }

      $m->Timeout = 15;

      if (defined('DEBUG_MAIL') && DEBUG_MAIL) {
        $m->SMTPDebug = 2;
        $m->Debugoutput = function ($str, $level) use (&$log) {
          $str = preg_replace('/(CLIENT -> SERVER: )[A-Za-z0-9+\/=]{16,}/', '$1[hidden]', trim($str));
          $log .= $str . "\n";
        };
      }
    } else {
      $m->isMail();   // PHP mail(): often blocked or sent to spam on shared hosting. SMTP is better.
    }

    $m->CharSet = 'UTF-8';
    $m->setFrom(MAIL_FROM, MAIL_FROM_NAME);
    $m->addAddress($to, $toName);
    if ($replyTo && filter_var($replyTo, FILTER_VALIDATE_EMAIL)) $m->addReplyTo($replyTo, $replyName);
    $m->isHTML(true);
    $m->Subject = trim(preg_replace('/[\r\n]+/', ' ', (string) $subject));
    $m->Body = $html;
    $m->AltBody = trim(html_entity_decode(strip_tags(str_replace(['<br>', '</tr>', '</p>'], "\n", $html)), ENT_QUOTES, 'UTF-8'));
    $m->send();
    return true;
  } catch (\Throwable $ex) {
    $reason = $m->ErrorInfo ?: $ex->getMessage();
    error_log('BMA mail error: ' . $reason);
    if ($log !== '') {
      $tail = implode("\n", array_slice(array_filter(explode("\n", $log)), -8));
      $reason .= " | SMTP log (last lines): " . str_replace("\n", ' // ', $tail);
    }
    return $reason;
  }
}

/** Wraps content in the branded email layout. */
function email_layout($title, $innerHtml) {
  return '<!doctype html><html><body style="margin:0;background:#EDE6D8;font-family:Arial,Helvetica,sans-serif;color:#1B1650">
  <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="padding:24px 12px"><tr><td align="center">
  <table role="presentation" width="600" cellpadding="0" cellspacing="0" style="max-width:600px;width:100%;background:#ffffff;border-radius:14px;overflow:hidden">
    <tr><td style="background:#16124A;padding:22px 28px;color:#F4B63F;font-size:20px;font-weight:bold">Bark Media Africa</td></tr>
    <tr><td style="height:6px;background:linear-gradient(90deg,#F4B63F 0 25%,#1F8A5B 25% 50%,#C8372D 50% 75%,#F4B63F 75%)"></td></tr>
    <tr><td style="padding:28px">
      <h1 style="margin:0 0 16px;font-size:22px;color:#16124A">' . e($title) . '</h1>' . $innerHtml . '
    </td></tr>
    <tr><td style="padding:18px 28px;background:#F7F3EA;font-size:12px;color:#6B6790">Sent from barkmediaafrica.com</td></tr>
  </table></td></tr></table></body></html>';
}

/** Renders key => value pairs as an email table. */
function email_table(array $rows) {
  $h = '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="border-collapse:collapse;font-size:15px">';
  foreach ($rows as $k => $v) {
    $h .= '<tr><td style="padding:10px 12px;border-bottom:1px solid #EEE8DA;color:#6B6790;width:38%;vertical-align:top">' . e($k) . '</td>'
        . '<td style="padding:10px 12px;border-bottom:1px solid #EEE8DA;font-weight:bold">' . nl2br(e($v !== '' ? $v : '—')) . '</td></tr>';
  }
  return $h . '</table>';
}