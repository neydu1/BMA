<?php
$pageTitle = 'Partner with us';
$pageDesc = 'Partner with Bark Media Africa: fund the intern programme, sponsor Spaces and events, open a country chapter or build with our shop.';
$extraScripts = '<script src="assets/js/partner.js?v=1" defer></script>';
require __DIR__ . '/includes/header.php';
require __DIR__ . '/includes/partner_data.php';

$flash = $_SESSION['flash'] ?? null; unset($_SESSION['flash']);
$pre = $_GET['interest'] ?? '';
$countries = array_merge(array_map(fn($n) => $n['name'] . ' ' . $n['flag'], $NATIONS), $EXTRA_COUNTRIES, ['Outside Africa']);
?>
<?= page_banner('Partner with us', 'Back the African chapter of DoginalDogs. Fund the interns, sponsor the Spaces, or help us open a new chapter.') ?>

<section class="pt-stats" aria-label="BMA at a glance">
  <div class="wrap">
    <dl class="pt-stat-grid">
      <?php foreach ($SITE['stats'] as $s): ?>
        <div data-reveal><dt><?= e($s['label']) ?></dt><dd data-count="<?= e($s['value']) ?>"><?= e($s['value']) ?></dd></div>
      <?php endforeach; ?>
      <div data-reveal><dt>X Spaces</dt><dd>Weekly</dd></div>
    </dl>
  </div>
</section>

<section class="section">
  <div class="wrap">
    <div class="section-head" data-reveal>
      <h2>Where your support goes</h2>
      <p>Pick one area or mix a few. Every partnership starts with a conversation about what the community needs and what you want to see happen.</p>
    </div>
    <div class="pt-ways">
      <?php foreach ($PARTNER_WAYS as $i => $w): ?>
        <article class="pt-way" data-reveal style="--d:<?= $i * 80 ?>ms">
          <span class="pt-ico"><?= partner_icon($w['icon']) ?></span>
          <h3><?= e($w['title']) ?></h3>
          <p><?= e($w['body']) ?></p>
          <a class="text-link" href="partner.php?interest=<?= urlencode($w['interest']) ?>#partner-form">I'm interested<span aria-hidden="true"> &rarr;</span></a>
        </article>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<section class="section tinted">
  <div class="wrap">
    <div class="section-head" data-reveal><h2>How it works</h2></div>
    <ol class="pt-steps">
      <li data-reveal><span class="pt-n">1</span><h3>Tell us about you</h3><p>Fill in the short form below. It takes about two minutes.</p></li>
      <li data-reveal style="--d:90ms"><span class="pt-n">2</span><h3>We reply within two days</h3><p>You get a confirmation email straight away, then someone from the team writes to you personally.</p></li>
      <li data-reveal style="--d:180ms"><span class="pt-n">3</span><h3>Shape the plan together</h3><p>We talk through goals, timing and what success looks like, then agree the next step.</p></li>
    </ol>
  </div>
</section>

<section class="section" id="partner-section">
  <div class="wrap join-grid">
    <div class="passport pt-passport" id="partner-card">
      <h2>Start the conversation</h2>
      <p class="muted">Tell us who you are and what you have in mind. We'll email you a copy of what you send.</p>

      <form class="form pt-form" id="partner-form" action="api/partner.php" method="post" novalidate>
        <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
        <input type="text" name="website" class="hp" tabindex="-1" autocomplete="off" aria-hidden="true">

        <div><label for="pf-fn">First name</label><input id="pf-fn" name="first_name" autocomplete="given-name" required></div>
        <div><label for="pf-ln">Last name</label><input id="pf-ln" name="last_name" autocomplete="family-name"></div>
        <div><label for="pf-em">Email address</label><input id="pf-em" name="email" type="email" autocomplete="email" required></div>
        <div><label for="pf-ph">Phone or WhatsApp <span class="opt">(optional)</span></label><input id="pf-ph" name="phone" type="tel" autocomplete="tel" inputmode="tel"></div>
        <div><label for="pf-org">Organisation <span class="opt">(optional)</span></label><input id="pf-org" name="organisation" autocomplete="organization"></div>
        <div><label for="pf-role">Your role <span class="opt">(optional)</span></label><input id="pf-role" name="role" autocomplete="organization-title"></div>

        <fieldset class="full pt-fieldset" id="pf-type">
          <legend>I'm partnering as</legend>
          <div class="pills">
            <?php foreach ($PARTNER_TYPES as $t): ?>
              <label class="pill"><input type="radio" name="investor_type" value="<?= e($t) ?>"><span><?= e($t) ?></span></label>
            <?php endforeach; ?>
          </div>
        </fieldset>

        <fieldset class="full pt-fieldset">
          <legend>I'm interested in <span class="opt">(pick any)</span></legend>
          <div class="pills">
            <?php foreach ($PARTNER_INTERESTS as $t): ?>
              <label class="pill"><input type="checkbox" name="interests[]" value="<?= e($t) ?>" <?= $t === $pre ? 'checked' : '' ?>><span><?= e($t) ?></span></label>
            <?php endforeach; ?>
          </div>
        </fieldset>

        <div><label for="pf-bg">Indicative budget</label>
          <select id="pf-bg" name="budget"><?php foreach ($PARTNER_BUDGETS as $b): ?><option><?= e($b) ?></option><?php endforeach; ?></select></div>
        <div><label for="pf-co">Where are you based?</label>
          <select id="pf-co" name="country"><?php foreach ($countries as $c): ?><option><?= e($c) ?></option><?php endforeach; ?></select></div>

        <div class="full"><label for="pf-ms">What do you have in mind? <span class="opt">(optional)</span></label>
          <textarea id="pf-ms" name="message" rows="4" placeholder="Goals, timing, questions, anything that helps us prepare"></textarea></div>

        <label class="full check pt-consent"><input type="checkbox" name="consent" value="1" required>
          <span>I agree that BMA can contact me about this enquiry. I understand this form starts a conversation and is not an offer or commitment of any kind.</span></label>

        <p class="full form-msg <?= $flash ? ($flash['ok'] ? 'ok' : 'err') : '' ?>" id="pf-msg" role="status" aria-live="polite"><?= $flash ? e($flash['msg']) : '' ?></p>
        <div class="full"><button class="btn btn-gold" type="submit" id="pf-submit">Send my enquiry</button></div>
      </form>

      <div class="pt-thanks" id="pf-thanks" hidden tabindex="-1">
        <div class="pt-check" aria-hidden="true"><svg viewBox="0 0 24 24" width="34" height="34" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg></div>
        <h2 id="pf-thanks-title">Thank you</h2>
        <p id="pf-thanks-text">We've got your enquiry.</p>
        <div class="btn-row">
          <a class="btn btn-gold" href="events.php">See upcoming events</a>
          <a class="btn btn-ghost-dark" href="index.php">Back to home</a>
        </div>
      </div>
    </div>

    <aside class="panel-dark">
      <h3>What happens next</h3>
      <ul class="pt-next">
        <li><b>Now</b><span>A confirmation email lands in your inbox with a copy of your answers.</span></li>
        <li><b>Within two days</b><span>A member of the BMA team replies to you personally.</span></li>
        <li><b>After that</b><span>We talk it through and agree the next step together.</span></li>
      </ul>
      <div class="kente thin" aria-hidden="true"></div>
      <h3>Prefer to talk first?</h3>
      <p><strong>X:</strong> <a href="<?= e($SITE['xUrl']) ?>" target="_blank" rel="noopener"><?= e($SITE['handle']) ?></a></p>
      <p><strong>Telegram:</strong> <a href="<?= e($SITE['telegram']) ?>" target="_blank" rel="noopener">Join the group</a></p>
      <p><strong>Email:</strong> <a href="mailto:<?= e($SITE['email']) ?>"><?= e($SITE['email']) ?></a></p>
    </aside>
  </div>
</section>

<section class="section tinted">
  <div class="wrap narrow">
    <div class="section-head"><h2>Good to know</h2></div>
    <details class="faq"><summary>Is this an investment offer?</summary>
      <p>No. This page and form start a conversation. Nothing here is an offer of securities, a promise of returns or financial advice, and any partnership is agreed separately and in writing.</p></details>
    <details class="faq"><summary>Who can partner with BMA?</summary>
      <p>Individuals, funds, brands, DAOs, foundations and communities. If you care about getting more of Africa into Web3, we'd like to hear from you.</p></details>
    <details class="faq"><summary>How quickly will I hear back?</summary>
      <p>You get an automatic confirmation email straight away, and a personal reply from the team within two days. If nothing arrives, check your spam folder or message us on X or Telegram.</p></details>
    <details class="faq"><summary>Can I support without money?</summary>
      <p>Yes. Hosting a Space, sharing expertise, offering tools or opening doors for interns are all welcome. Pick "Something else" and tell us what you can offer.</p></details>
  </div>
</section>

<?= join_cta() ?>
<?php require __DIR__ . '/includes/footer.php'; ?>
