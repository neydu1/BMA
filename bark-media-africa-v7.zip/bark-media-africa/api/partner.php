<?php
/* Handles the Partner With Us form.
   1. Saves the enquiry to storage/partners.csv (so nothing is lost if email fails)
   2. Emails ADMIN_EMAIL the details (Reply goes straight to the enquirer)
   3. Emails the enquirer a confirmation with a copy of their answers

   Turn on define('DEBUG_MAIL', true); in includes/config.php to see the real
   mail error in the response while testing. */
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/data.php';
require_once __DIR__ . '/../includes/partner_data.php';
require_once __DIR__ . '/../includes/mailer.php';

if (!defined('DEBUG_MAIL')) define('DEBUG_MAIL', false);
ini_set('display_errors', '0');

$isAjax = ($_SERVER['HTTP_X_REQUESTED_WITH'] ?? '') === 'fetch';

function finish($ok, $msg, $code = 200, $debug = null) {
  global $isAjax;
  if ($debug !== null && DEBUG_MAIL) $msg .= ' [DEBUG: ' . $debug . ']';
  if ($isAjax) json_out($ok, $msg, $code);
  $_SESSION['flash'] = ['ok' => $ok, 'msg' => $msg];
  header('Location: ../partner.php' . ($ok ? '?sent=1' : '') . '#partner-card');
  exit;
}

function one_line($s) { return trim(preg_replace('/[\r\n]+/', ' ', (string) $s)); }

function try_send($to, $toName, $subject, $html, $replyTo = null, $replyName = '') {
  try {
    $r = send_mail($to, $toName, one_line($subject), $html, $replyTo, $replyName);
    if ($r === true) return [true, ''];
    return [false, is_string($r) && $r !== '' ? $r : 'send_mail() returned no reason'];
  } catch (Throwable $t) {
    return [false, get_class($t) . ': ' . $t->getMessage()];
  }
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') finish(false, 'Use the form on the Partner page.', 405);

if (!empty($_POST['website'])) {
  error_log('BMA partner: honeypot triggered from ' . ($_SERVER['REMOTE_ADDR'] ?? '?'));
  finish(true, "Thank you. We've got your enquiry and will reply within two days.");
}
if (!csrf_check($_POST['csrf'] ?? '')) finish(false, 'Your session expired. Refresh the page and send the form again.', 400);
if (rate_limited('partner', 3, 900)) finish(false, 'You have sent several enquiries already. Try again in 15 minutes.', 429);

$first   = one_line(clean($_POST['first_name'] ?? '', 60));
$last    = one_line(clean($_POST['last_name'] ?? '', 60));
$email   = filter_var(trim($_POST['email'] ?? ''), FILTER_VALIDATE_EMAIL);
$phone   = one_line(clean($_POST['phone'] ?? '', 40));
$org     = one_line(clean($_POST['organisation'] ?? '', 100));
$role    = one_line(clean($_POST['role'] ?? '', 80));
$type    = clean($_POST['investor_type'] ?? '', 60);
$budget  = clean($_POST['budget'] ?? '', 60);
$country = one_line(clean($_POST['country'] ?? '', 60));
$message = mb_substr(strip_tags(trim($_POST['message'] ?? '')), 0, 3000);
$consent = !empty($_POST['consent']);

$interestsIn = $_POST['interests'] ?? [];
if (!is_array($interestsIn)) $interestsIn = [];
$interests = array_values(array_intersect($PARTNER_INTERESTS, array_map('strval', $interestsIn)));

if ($first === '')  finish(false, 'Enter your first name.', 422);
if (!$email)        finish(false, 'Enter a valid email address so we can reply.', 422);
if (!in_array($type, $PARTNER_TYPES, true)) finish(false, 'Choose how you are partnering with us.', 422);
if (!$consent)      finish(false, 'Tick the box to confirm we can contact you.', 422);
if (!in_array($budget, $PARTNER_BUDGETS, true)) $budget = 'Not sure yet';

$fullName = trim("$first $last");
$interestText = $interests ? implode(', ', $interests) : 'Not specified';
$when = date('D j M Y, g:i a T');

/* ---- 1. Save first ---- */
try {
  store_row('partners.csv', [
    'date' => date('c'), 'first_name' => $first, 'last_name' => $last, 'email' => $email, 'phone' => $phone,
    'organisation' => $org, 'role' => $role, 'type' => $type, 'interests' => $interestText,
    'budget' => $budget, 'country' => $country, 'message' => $message, 'ip' => $_SERVER['REMOTE_ADDR'] ?? '',
  ]);
} catch (Throwable $t) {
  error_log('BMA partner: could not save CSV: ' . $t->getMessage());
}

/* ---- 2. Email to the BMA team ---- */
$adminOk = false; $adminWhy = 'not attempted';
if (!defined('ADMIN_EMAIL') || !filter_var(ADMIN_EMAIL, FILTER_VALIDATE_EMAIL)) {
  $adminWhy = 'ADMIN_EMAIL is missing or invalid in config.php';
} else {
  $adminHtml = email_layout("New partnership enquiry: $fullName", '
    <p style="margin:0 0 18px;font-size:15px;line-height:1.5">Someone wants to partner with BMA. Hit Reply to answer them directly.</p>'
    . email_table([
      'Name' => $fullName, 'Email' => $email, 'Phone / WhatsApp' => $phone,
      'Organisation' => $org, 'Role' => $role, 'Partnering as' => $type,
      'Interested in' => $interestText, 'Indicative budget' => $budget,
      'Based in' => $country, 'Message' => $message, 'Received' => $when,
    ]));
  [$adminOk, $adminWhy] = try_send(
    ADMIN_EMAIL, defined('ADMIN_NAME') ? ADMIN_NAME : 'Admin',
    "New partner enquiry: $fullName" . ($org !== '' ? " ($org)" : ''),
    $adminHtml, $email, $fullName
  );
}

/* ---- 3. Confirmation email to the enquirer (always sent) ---- */
$mine = email_table([
  'Partnering as' => $type, 'Interested in' => $interestText,
  'Indicative budget' => $budget, 'Organisation' => $org, 'Message' => $message,
]);
$confirmHtml = email_layout("Thank you, $first", '
  <p style="font-size:15px;line-height:1.6;margin:0 0 14px">Thanks for reaching out about partnering with Bark Media Africa. We have your enquiry and someone from the team will reply to you personally <b>within two days</b>.</p>
  <h2 style="margin:22px 0 10px;font-size:16px;color:#16124A">What you sent us</h2>' . $mine . '
  <h2 style="margin:24px 0 10px;font-size:16px;color:#16124A">What happens next</h2>
  <ol style="font-size:15px;line-height:1.7;padding-left:20px;margin:0 0 18px">
    <li>We read your note and match you with the right person on the team.</li>
    <li>They email you to talk through goals and timing.</li>
    <li>Together we agree the next step.</li>
  </ol>
  <p style="margin:22px 0"><a href="' . e($SITE['xUrl']) . '" style="background:#F4B63F;color:#16124A;padding:12px 20px;border-radius:999px;text-decoration:none;font-weight:bold">Follow ' . e($SITE['handle']) . '</a>
  &nbsp; <a href="' . e($SITE['telegram']) . '" style="color:#1F8A5B;font-weight:bold">Join the Telegram group</a></p>
  <p style="font-size:12px;line-height:1.5;color:#6B6790;margin:18px 0 0">This email confirms we received your enquiry. It is not an offer of securities, a commitment of any kind or financial advice. If you did not send this, you can ignore it.</p>');
[$confirmOk, $confirmWhy] = try_send($email, $fullName, 'We received your partnership enquiry | Bark Media Africa', $confirmHtml);

/* ---- Report ---- */
$problems = [];
if (!$adminOk)   $problems[] = 'Team email failed: ' . $adminWhy;
if (!$confirmOk) $problems[] = 'Confirmation email failed: ' . $confirmWhy;
if ($problems) error_log('BMA partner mail problem for ' . $email . ' | ' . implode(' | ', $problems));

if (!$confirmOk) {
  // Don't tell them to check their inbox for something that never left the server.
  finish(true, "Thank you, $first. We've received your enquiry and will reply within two days.", 200, implode(' | ', $problems));
}
finish(true, "Thank you, $first. We've emailed you a copy and will reply within two days.", 200, $problems ? implode(' | ', $problems) : null);
