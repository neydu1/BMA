<?php
/* Two Paws leaderboard
   GET  → { ok, runs: top 25, teams: nation ranking, total }
   POST → save a finished run (score is recomputed here, never trusted from the browser) */
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/data.php';
require_once __DIR__ . '/../includes/game_lib.php';

header('Content-Type: application/json');
header('Cache-Control: no-store');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
  $runs = tp_load();
  echo json_encode(['ok' => true, 'runs' => tp_public($runs), 'teams' => tp_teams($runs), 'total' => count($runs)], JSON_UNESCAPED_UNICODE);
  exit;
}

if (!csrf_check($_POST['csrf'] ?? '')) json_out(false, 'Your session expired. Refresh the page and submit again.', 403);
if (!empty($_POST['website'])) json_out(true, 'Saved.');
if (rate_limited('leaderboard', 6, 600)) json_out(false, 'Too many submissions. Try again in a few minutes.', 429);

$team = clean($_POST['team'] ?? '', 40);
if (!in_array($team, $GAME_TEAMS, true)) json_out(false, 'Pick the nation team you play for.', 422);

$p1 = tp_handle($_POST['p1'] ?? '');
$p2 = tp_handle($_POST['p2'] ?? '');
$mode = ($_POST['mode'] ?? '') === 'solo' ? 'solo' : 'coop';
if (!$p1) json_out(false, 'Add Player 1\'s X handle (letters, numbers and _ only).', 422);
if ($mode === 'coop' && !$p2) json_out(false, 'Add Player 2\'s X handle, or play solo.', 422);

$c1 = in_array($_POST['c1'] ?? '', TP_CHARS, true) ? $_POST['c1'] : TP_CHARS[0];
$c2 = in_array($_POST['c2'] ?? '', TP_CHARS, true) ? $_POST['c2'] : TP_CHARS[1];

$levels = max(0, min(TP_CHAPTERS, (int) ($_POST['levels'] ?? 0)));
$coins = max(0, min(TP_MAX_COINS, (int) ($_POST['coins'] ?? 0)));
$deaths = max(0, min(9999, (int) ($_POST['deaths'] ?? 0)));
$time = (float) ($_POST['time'] ?? 0);
if ($levels < 1) json_out(false, 'Clear at least one chapter to post a score.', 422);
if ($time < $levels * 20 || $time > 36000) json_out(false, 'That run time does not look right.', 422);

$score = tp_score($levels, $coins, $time, $deaths);
$run = [
  'score' => $score, 'team' => $team, 'mode' => $mode,
  'p1' => tp_player($p1, 'p1'), 'p2' => $mode === 'coop' ? tp_player($p2, 'p2') : ['handle' => '', 'name' => '', 'avatar' => '', 'verified' => false],
  'chars' => [$c1, $c2], 'levels' => $levels, 'coins' => $coins, 'deaths' => $deaths, 'time' => round($time, 1),
  'at' => date('c'), 'ip' => hash('sha256', ($_SERVER['REMOTE_ADDR'] ?? '') . 'bma'),
];
$runs = tp_add($run);
$rank = 1;
foreach ($runs as $i => $r) { if ($r['at'] === $run['at'] && $r['p1']['handle'] === $p1 && $r['score'] === $score) { $rank = $i + 1; break; } }

echo json_encode(['ok' => true, 'message' => "Saved! You're #$rank overall.", 'score' => $score, 'rank' => $rank,
  'runs' => tp_public($runs), 'teams' => tp_teams($runs), 'total' => count($runs)], JSON_UNESCAPED_UNICODE);
