<?php
/* Handles the Join form. Emails ADMIN_EMAIL with the new member's details,
   saves a CSV backup, and (optionally) sends the member a welcome email.

   DEBUGGING MAIL: add this line to includes/config.php while testing:
       define('DEBUG_MAIL', true);
   With it on, the real mail error is shown in the form response and the browser
   console. Set it to false (or remove it) before going live. Errors are always
   written to the PHP error log either way. */
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/data.php';
require_once __DIR__ . '/../includes/mailer.php';

if (!defined('DEBUG_MAIL')) define('DEBUG_MAIL', false);
if (!defined('SEND_CONFIRMATIONS')) define('SEND_CONFIRMATIONS', false);

if (DEBUG_MAIL) {
  ini_set('display_errors', '0');          // never print raw PHP errors into the JSON response
  ini_set('log_errors', '1');
  error_reporting(E_ALL);
}

$isAjax = ($_SERVER['HTTP_X_REQUESTED_WITH'] ?? '') === 'fetch';

/* Turn whatever send_mail() returned into a readable reason. */
function mail_reason($result) {
  if ($result === true) return '';
  if ($result === false || $result === null) return 'send_mail() returned false (no reason given; check mailer.php and the server mail log)';
  if (is_string($result)) return $result;
  if ($result instanceof Throwable) return get_class($result) . ': ' . $result->getMessage();
  return 'Unexpected result: ' . json_encode($result);
}

/* Run send_mail() safely: exceptions and fatal-ish errors become a reason string. */
function try_send($to, $toName, $subject, $html, $replyTo = null, $replyName = null) {
  try {
    $r = ($replyTo !== null)
      ? send_mail($to, $toName, $subject, $html, $replyTo, $replyName)
      : send_mail($to, $toName, $subject, $html);
    return ['ok' => $r === true, 'reason' => mail_reason($r)];
  } catch (Throwable $t) {
    return ['ok' => false, 'reason' => mail_reason($t)];
  }
}

function finish($ok, $msg, $code = 200, $debug = null) {
  global $isAjax;
  if ($isAjax) {
    if ($debug !== null && DEBUG_MAIL) $msg .= ' [DEBUG: ' . $debug . ']';
    json_out($ok, $msg, $code);
  }
  // No-JS fallback: back to the form with a message
  if ($debug !== null && DEBUG_MAIL) $msg .= ' [DEBUG: ' . $debug . ']';
  $_SESSION['flash'] = ['ok' => $ok, 'msg' => $msg];
  header('Location: ../join.php' . ($ok ? '?joined=1' : '') . '#join-form');
  exit;
}

/* Strip line breaks so user input can never inject extra mail headers. */
function one_line($s) { return trim(preg_replace('/[\r\n]+/', ' ', (string) $s)); }

if ($_SERVER['REQUEST_METHOD'] !== 'POST') finish(false, 'Use the form on the Join page.', 405);

if (!empty($_POST['website'])) {
  // Honeypot filled. Log it so a browser autofilling the field doesn't hide real applications.
  error_log('BMA join: honeypot triggered from ' . ($_SERVER['REMOTE_ADDR'] ?? '?'));
  finish(true, "Application sent. Welcome to BMA — we'll reach out within two days.");
}
if (!csrf_check($_POST['csrf'] ?? '')) finish(false, 'Your session expired. Refresh the page and send the form again.', 400);
if (rate_limited('join', 3, 900)) finish(false, 'You have sent several applications already. Try again in 15 minutes.', 429);

$first   = one_line(clean($_POST['first_name'] ?? '', 60));
$last    = one_line(clean($_POST['last_name'] ?? '', 60));
$email   = filter_var(trim($_POST['email'] ?? ''), FILTER_VALIDATE_EMAIL);
$handle  = one_line(clean($_POST['handle'] ?? '', 60));
$nation  = one_line(clean($_POST['nation'] ?? '', 60));
$focus   = clean($_POST['focus'] ?? '', 60);
$message = mb_substr(strip_tags(trim($_POST['message'] ?? '')), 0, 2000);
$newsOpt = !empty($_POST['newsletter']);

if (!$email) finish(false, 'Enter a valid email address so we can reply.', 422);
if ($first === '') finish(false, 'Enter your first name.', 422);
if (!in_array($focus, $FOCUS_OPTIONS, true)) $focus = 'Not specified';

$fullName = trim("$first $last");
$when = date('D j M Y, g:i a T');

/* ---- Save first, so no member is ever lost even if email fails ---- */
$row = [
  'date' => date('c'), 'first_name' => $first, 'last_name' => $last, 'email' => $email,
  'handle' => $handle, 'country' => $nation, 'interest' => $focus, 'message' => $message,
  'newsletter' => $newsOpt ? 'yes' : 'no', 'ip' => $_SERVER['REMOTE_ADDR'] ?? '',
];
try {
  store_row('members.csv', $row);
  if ($newsOpt && !email_exists_in('subscribers.csv', $email)) {
    store_row('subscribers.csv', ['date' => date('c'), 'email' => $email, 'name' => $fullName, 'source' => 'join form']);
  }
} catch (Throwable $t) {
  error_log('BMA join: could not save CSV: ' . $t->getMessage());
  // Not fatal for the visitor; the admin email below is still attempted.
}

/* ---- 1. Email to you (admin) ---- */
$handleLink = '';
if ($handle !== '') {
  $h = ltrim($handle, '@');
  $handleLink = '<p style="margin:18px 0 0"><a href="https://x.com/' . rawurlencode($h) . '" style="color:#1F8A5B">Open @' . e($h) . ' on X</a></p>';
}

$adminResult = ['ok' => false, 'reason' => 'not attempted'];
if (!defined('ADMIN_EMAIL') || !filter_var(ADMIN_EMAIL, FILTER_VALIDATE_EMAIL)) {
  $adminResult['reason'] = 'ADMIN_EMAIL is missing or not a valid email address in config.php';
} else {
  $adminHtml = email_layout("New member: $fullName", '
    <p style="margin:0 0 18px;font-size:15px;line-height:1.5">Someone just joined through the website. Hit Reply to answer them directly.</p>'
    . email_table([
        'Name' => $fullName, 'Email' => $email, 'Telegram / X' => $handle, 'Country' => $nation,
        'Interested in' => $focus, 'Message' => $message,
        'Newsletter' => $newsOpt ? 'Subscribed' : 'No', 'Joined' => $when,
      ]) . $handleLink);

  $adminResult = try_send(
    ADMIN_EMAIL, defined('ADMIN_NAME') ? ADMIN_NAME : 'Admin',
    one_line("New BMA member: $fullName ($focus)"), $adminHtml, $email, $fullName
  );
}

/* ---- 2. Welcome email to the member ---- */
$welcomeResult = ['ok' => true, 'reason' => ''];
if (SEND_CONFIRMATIONS) {
  $welcome = email_layout("Welcome to the pack, $first", '
    <p style="font-size:15px;line-height:1.6">Thanks for joining Bark Media Africa. We\'ve got your application for <b>' . e($focus) . '</b> and someone from the team will reach out on Telegram or X within two days.</p>
    <p style="font-size:15px;line-height:1.6">While you wait, the quickest way in is to join a live Space. We\'re on X most days.</p>
    <p style="margin:24px 0"><a href="' . e($SITE['xUrl']) . '" style="background:#F4B63F;color:#16124A;padding:12px 20px;border-radius:999px;text-decoration:none;font-weight:bold">Follow ' . e($SITE['handle']) . '</a>
    &nbsp; <a href="' . e($SITE['telegram']) . '" style="color:#1F8A5B;font-weight:bold">Join the Telegram group</a></p>
    <p style="font-size:13px;color:#6B6790">Ubuntu: I am because we are.</p>');
  $welcomeResult = try_send($email, $fullName, 'Welcome to Bark Media Africa', $welcome);
}

/* ---- Report problems: always to the log, and to the response when DEBUG_MAIL is on ---- */
$problems = [];
if (!$adminResult['ok'])   $problems[] = 'Admin email failed: ' . $adminResult['reason'];
if (!$welcomeResult['ok']) $problems[] = 'Welcome email failed: ' . $welcomeResult['reason'];

if ($problems) {
  error_log('BMA join mail problem for ' . $email . ' | ' . implode(' | ', $problems));
  finish(
    true,
    "Application received, $first. We'll reach out within two days.",
    200,
    implode(' | ', $problems)
  );
}

finish(true, "Application sent. Welcome to BMA, $first — check your inbox, and we'll reach out within two days.");