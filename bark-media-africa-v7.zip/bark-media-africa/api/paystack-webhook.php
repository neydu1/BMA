<?php
/* Paystack webhook — set this URL in Paystack dashboard > Settings > API Keys & Webhooks:
   https://yourdomain.com/api/paystack-webhook.php
   Catches payments even if the customer closes the tab before returning. */
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/orders.php';

$raw = file_get_contents('php://input');
$sig = $_SERVER['HTTP_X_PAYSTACK_SIGNATURE'] ?? '';
if (!$sig || !hash_equals(hash_hmac('sha512', $raw, PAYSTACK_SECRET_KEY), $sig)) { http_response_code(401); exit; }

http_response_code(200);           // acknowledge quickly
$event = json_decode($raw, true);
if (($event['event'] ?? '') === 'charge.success' && !empty($event['data']['reference'])) {
  order_confirm($event['data']['reference']);   // re-verifies with the API before marking paid
}
echo 'ok';
