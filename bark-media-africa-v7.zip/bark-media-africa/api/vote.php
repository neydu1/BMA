<?php
/* Pack Council votes
   GET  → tallies for every proposal + this visitor's own votes
   POST → { proposal, option, address?, signature?, chain? }
   A vote signed by a wallet counts once per wallet; an unsigned community vote counts once per browser session.
   Signatures are stored for audit so anyone can verify them later against the message. */
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/data.php';
require_once __DIR__ . '/../includes/game_lib.php';   // data guard helpers

header('Content-Type: application/json');
header('Cache-Control: no-store');
$file = STORAGE_DIR . '/votes.data.php';
$byId = array_column($PROPOSALS, null, 'id');

function vote_keys() {
  $k = ['s:' . session_id()];
  foreach ($_SESSION['wallets'] ?? [] as $w) $k[] = 'w:' . $w;
  return $k;
}
function tallies(array $db, array $byId) {
  $out = []; $mine = [];
  $keys = vote_keys();
  foreach ($byId as $id => $p) {
    $counts = array_fill(0, count($p['options']), 0); $signed = 0;
    foreach ($db[$id] ?? [] as $voter => $v) {
      if (isset($counts[$v['o']])) $counts[$v['o']]++;
      if (!empty($v['sig'])) $signed++;
      if (in_array($voter, $keys, true)) $mine[$id] = $v['o'];
    }
    $out[$id] = ['counts' => $counts, 'total' => array_sum($counts), 'signed' => $signed];
  }
  return ['ok' => true, 'tallies' => $out, 'mine' => (object) $mine];
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
  $db = file_exists($file) ? data_decode(@file_get_contents($file)) : [];
  echo json_encode(tallies($db, $byId)); exit;
}

if (!csrf_check($_POST['csrf'] ?? '')) json_out(false, 'Your session expired. Refresh and try again.', 403);
if (rate_limited('vote', 12, 600)) json_out(false, 'Too many votes in a short time. Try again shortly.', 429);
$id = (string) ($_POST['proposal'] ?? '');
$opt = (int) ($_POST['option'] ?? -1);
if (!isset($byId[$id]) || $opt < 0 || $opt >= count($byId[$id]['options'])) json_out(false, 'Unknown proposal or option.', 422);
if (!empty($byId[$id]['closes']) && strtotime($byId[$id]['closes'] . ' 23:59:59') < time()) json_out(false, 'Voting on this proposal has closed.', 422);

$addr = preg_replace('/[^A-Za-z0-9]/', '', (string) ($_POST['address'] ?? ''));
$sig = substr(preg_replace('/[^A-Za-z0-9+\/=x]/', '', (string) ($_POST['signature'] ?? '')), 0, 400);
$chain = in_array($_POST['chain'] ?? '', ['doge', 'evm'], true) ? $_POST['chain'] : '';
$validAddr = ($chain === 'doge' && preg_match('/^[DA9][1-9A-HJ-NP-Za-km-z]{25,34}$/', $addr)) || ($chain === 'evm' && preg_match('/^0x[0-9a-fA-F]{40}$/', $addr));
$voter = ($validAddr && $sig) ? 'w:' . strtolower($addr) : 's:' . session_id();
if ($validAddr && $sig) $_SESSION['wallets'][] = strtolower($addr);

$fh = fopen($file, 'c+');
if (!$fh) json_out(false, 'Could not save your vote. Try again later.', 500);
flock($fh, LOCK_EX);
$db = data_decode(stream_get_contents($fh));
if (isset($db[$id][$voter])) { flock($fh, LOCK_UN); fclose($fh); $r = tallies($db, $byId); $r['ok'] = false; $r['message'] = 'You already voted on this one.'; echo json_encode($r); exit; }
$db[$id][$voter] = ['o' => $opt, 't' => date('c'), 'sig' => $validAddr ? $sig : '', 'chain' => $chain, 'addr' => $validAddr ? $addr : ''];
data_write($fh, $db);
flock($fh, LOCK_UN); fclose($fh);

$r = tallies($db, $byId);
$r['message'] = $validAddr && $sig ? 'Signed vote recorded. Thank you!' : 'Vote recorded. Thank you!';
echo json_encode($r);
