<?php
/* Creates an order from the cart and starts a Paystack payment.
   Returns { ok, url } — the browser then goes to Paystack's checkout page. */
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/orders.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') json_out(false, 'Use the checkout form.', 405);
if (!csrf_check($_POST['csrf'] ?? '')) json_out(false, 'Your session expired. Refresh the page and try again.', 400);
if (!empty($_POST['website'])) json_out(false, 'Could not start payment.', 400);
if (rate_limited('checkout', 8, 600)) json_out(false, 'Too many checkout attempts. Wait a few minutes and try again.', 429);
if (!paystack_ready()) json_out(false, 'Payments are not switched on yet. Add your Paystack keys in includes/config.php.', 503);

$items = json_decode($_POST['cart'] ?? '[]', true);
$priced = price_cart(is_array($items) ? $items : []);
if (is_string($priced)) json_out(false, $priced, 422);
[$lines, $subtotal] = $priced;

$ship = $_POST['shipping'] ?? '';
if (!isset($SHIPPING[$ship])) json_out(false, 'Choose a delivery option.', 422);

$c = [
  'name'    => clean($_POST['name'] ?? '', 80),
  'email'   => filter_var(trim($_POST['email'] ?? ''), FILTER_VALIDATE_EMAIL) ?: '',
  'phone'   => clean($_POST['phone'] ?? '', 30),
  'address' => clean($_POST['address'] ?? '', 200),
  'city'    => clean($_POST['city'] ?? '', 60),
  'state'   => clean($_POST['state'] ?? '', 60),
  'country' => clean($_POST['country'] ?? 'Nigeria', 60),
  'note'    => clean($_POST['note'] ?? '', 300),
];
if ($c['name'] === '') json_out(false, 'Enter your full name.', 422);
if ($c['email'] === '') json_out(false, 'Enter a valid email address for your receipt.', 422);
if (strlen(preg_replace('/\D/', '', $c['phone'])) < 7) json_out(false, 'Enter a phone number so the rider can reach you.', 422);
if ($ship !== 'pickup' && $c['address'] === '') json_out(false, 'Enter a delivery address.', 422);

$shipping = $SHIPPING[$ship] + ['key' => $ship];
$total = $subtotal + $shipping['price'];
$ref = new_order_ref();
$order = [
  'ref' => $ref, 'status' => 'pending', 'created' => date('c'),
  'lines' => $lines, 'subtotal' => $subtotal, 'shipping' => $shipping, 'total' => $total,
  'amount_kobo' => $total * 100, 'currency' => SHOP_CURRENCY, 'customer' => $c, 'fulfilled' => false,
];
if (!order_save($order)) json_out(false, 'Could not save your order. Contact us and we\'ll sort it out.', 500);

$res = paystack_request('POST', '/transaction/initialize', [
  'email' => $c['email'],
  'amount' => $order['amount_kobo'],
  'currency' => SHOP_CURRENCY,
  'reference' => $ref,
  'callback_url' => site_url('order-complete.php'),
  'metadata' => [
    'order_ref' => $ref,
    'cancel_action' => site_url('checkout.php?cancelled=1'),
    'custom_fields' => [
      ['display_name' => 'Customer', 'variable_name' => 'customer', 'value' => $c['name']],
      ['display_name' => 'Phone', 'variable_name' => 'phone', 'value' => $c['phone']],
      ['display_name' => 'Items', 'variable_name' => 'items', 'value' => implode(', ', array_map(fn($l) => $l['qty'] . 'x ' . $l['name'], $lines))],
    ],
  ],
]);

if (empty($res['status']) || empty($res['data']['authorization_url'])) {
  error_log('BMA Paystack init failed: ' . ($res['message'] ?? 'unknown'));
  $order['status'] = 'init_failed'; order_save($order);
  json_out(false, 'Paystack could not start the payment: ' . ($res['message'] ?? 'unknown error') . '. Try again in a moment.', 502);
}

http_response_code(200);
header('Content-Type: application/json');
echo json_encode(['ok' => true, 'url' => $res['data']['authorization_url'], 'ref' => $ref]);
