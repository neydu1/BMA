<?php
/* Two Paws online lobby + WebRTC signalling.
   Players on the game page say "hello" every few seconds; they can invite each other or share a room code.
   Only the connection handshake passes through here; the game itself runs device-to-device.
   Everything expires on its own (players after 45 s, invites after 90 s, rooms after 15 min). */
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/data.php';
require_once __DIR__ . '/../includes/game_lib.php';

header('Content-Type: application/json');
header('Cache-Control: no-store');
if ($_SERVER['REQUEST_METHOD'] !== 'POST') json_out(false, 'POST only', 405);
if (!csrf_check($_POST['csrf'] ?? '')) json_out(false, 'Session expired. Refresh the page.', 403);

$id = preg_replace('/[^a-f0-9]/', '', (string) ($_POST['id'] ?? ''));
if (strlen($id) < 12) json_out(false, 'Missing player id', 422);
$id = substr($id, 0, 24);
$act = (string) ($_POST['act'] ?? '');
$now = time();
$file = STORAGE_DIR . '/rooms.data.php';

if (!is_dir(STORAGE_DIR)) @mkdir(STORAGE_DIR, 0755, true);
$fh = fopen($file, 'c+');
if (!$fh) json_out(false, 'Storage unavailable', 500);
flock($fh, LOCK_EX);
$db = data_decode(stream_get_contents($fh)) + ['presence' => [], 'invites' => [], 'rooms' => []];
foreach (['presence', 'invites', 'rooms'] as $k) if (!is_array($db[$k])) $db[$k] = [];

// tidy up
foreach ($db['presence'] as $k => $p) if ($now - $p['t'] > 45) unset($db['presence'][$k]);
foreach ($db['invites'] as $to => $list) { $db['invites'][$to] = array_values(array_filter($list, fn($i) => $now - $i['t'] < 90)); if (!$db['invites'][$to]) unset($db['invites'][$to]); }
foreach ($db['rooms'] as $c => $r) if ($now - $r['t'] > 900) unset($db['rooms'][$c]);

$name = fn($v) => mb_substr(preg_replace('/[^\p{L}\p{N}_ .\-@]/u', '', (string) $v), 0, 24);
$code = strtoupper(preg_replace('/[^A-Za-z0-9]/', '', (string) ($_POST['room'] ?? '')));
$out = ['ok' => true];
$newCode = function () use (&$db) { do { $c = ''; for ($i = 0; $i < 4; $i++) $c .= 'ABCDEFGHJKMNPQRSTUVWXYZ23456789'[random_int(0, 30)]; } while (isset($db['rooms'][$c])); return $c; };

switch ($act) {
  case 'hello':
    $team = in_array($_POST['team'] ?? '', $GAME_TEAMS, true) ? $_POST['team'] : '';
    $db['presence'][$id] = ['name' => $name($_POST['name'] ?? 'Player') ?: 'Player', 'team' => $team, 't' => $now, 'busy' => !empty($_POST['busy'])];
    $others = [];
    foreach ($db['presence'] as $k => $p) if ($k !== $id) $others[] = ['id' => $k, 'name' => $p['name'], 'team' => $p['team'], 'flag' => $TEAM_FLAGS[$p['team']] ?? '', 'busy' => $p['busy']];
    usort($others, fn($a, $b) => $a['busy'] <=> $b['busy']);
    $out['others'] = array_slice($others, 0, 30);
    $out['invites'] = array_values(array_filter($db['invites'][$id] ?? [], fn($i) => isset($db['rooms'][$i['room']])));
    $out['online'] = count($db['presence']);
    break;

  case 'invite':
    $to = preg_replace('/[^a-f0-9]/', '', (string) ($_POST['to'] ?? ''));
    if (!isset($db['presence'][$to])) { $out = ['ok' => false, 'message' => 'That player just went offline.']; break; }
    $c = $newCode();
    $db['rooms'][$c] = ['host' => $id, 'guest' => null, 'invited' => $to, 't' => $now, 'hostName' => $db['presence'][$id]['name'] ?? 'Player'];
    $db['invites'][$to][] = ['room' => $c, 'from' => $id, 'name' => $db['presence'][$id]['name'] ?? 'Player', 'team' => $db['presence'][$id]['team'] ?? '', 't' => $now];
    $out['room'] = $c;
    break;

  case 'create':
    $c = $newCode();
    $db['rooms'][$c] = ['host' => $id, 'guest' => null, 't' => $now, 'hostName' => $db['presence'][$id]['name'] ?? 'Player'];
    $out['room'] = $c;
    break;

  case 'join':
    $r = $db['rooms'][$code] ?? null;
    if (!$r) { $out = ['ok' => false, 'message' => 'No game with that code. Check the letters with your partner.']; break; }
    if ($r['host'] === $id) { $out = ['ok' => false, 'message' => "That's your own room code. Share it with your partner."]; break; }
    if ($r['guest'] && $r['guest'] !== $id) { $out = ['ok' => false, 'message' => 'That game already has two players.']; break; }
    $db['rooms'][$code]['guest'] = $id; $db['rooms'][$code]['guestName'] = $db['presence'][$id]['name'] ?? 'Player'; $db['rooms'][$code]['t'] = $now;
    unset($db['invites'][$id]);
    $out['room'] = $code; $out['hostName'] = $r['hostName'];
    break;

  case 'decline':
    if (isset($db['rooms'][$code])) $db['rooms'][$code]['declined'] = true;
    if (isset($db['invites'][$id])) $db['invites'][$id] = array_values(array_filter($db['invites'][$id], fn($i) => $i['room'] !== $code));
    break;

  case 'signal':
    $r = $db['rooms'][$code] ?? null;
    if (!$r || ($r['host'] !== $id && $r['guest'] !== $id)) { $out = ['ok' => false, 'message' => 'Room closed.']; break; }
    $kind = ($_POST['kind'] ?? '') === 'answer' ? 'answer' : 'offer';
    $sdp = (string) ($_POST['sdp'] ?? '');
    if (strlen($sdp) > 20000) { $out = ['ok' => false, 'message' => 'Signal too large']; break; }
    $db['rooms'][$code][$kind] = $sdp; $db['rooms'][$code]['t'] = $now;
    break;

  case 'poll':
    $r = $db['rooms'][$code] ?? null;
    if (!$r || ($r['host'] !== $id && $r['guest'] !== $id && ($r['invited'] ?? '') !== $id)) { $out = ['ok' => false, 'message' => 'Room closed.']; break; }
    $out['room'] = ['guest' => (bool) $r['guest'], 'guestName' => $r['guestName'] ?? '', 'hostName' => $r['hostName'] ?? '', 'declined' => !empty($r['declined']),
                    'offer' => $r['host'] !== $id ? ($r['offer'] ?? null) : null, 'answer' => $r['host'] === $id ? ($r['answer'] ?? null) : null];
    break;

  case 'close':
    if (isset($db['rooms'][$code]) && in_array($id, [$db['rooms'][$code]['host'], $db['rooms'][$code]['guest']], true)) unset($db['rooms'][$code]);
    break;

  case 'bye':
    unset($db['presence'][$id], $db['invites'][$id]);
    break;

  default:
    $out = ['ok' => false, 'message' => 'Unknown action'];
}

data_write($fh, $db);
flock($fh, LOCK_UN); fclose($fh);
echo json_encode($out, JSON_UNESCAPED_UNICODE);
