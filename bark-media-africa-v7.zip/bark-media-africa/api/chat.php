<?php
/* Optional AI mode for Sniff. Only used when CHATBOT_API_KEY is set in includes/config.php
   (or ANTHROPIC_API_KEY in the server environment). The key stays on the server.
   If it is missing or the call fails, the browser falls back to the built-in guide. */
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/data.php';
require_once __DIR__ . '/../includes/products.php';
require_once __DIR__ . '/../includes/assistant.php';

ini_set('display_errors', '0');

function chat_out($ok, $reply = '', $code = 200, $extra = []) {
  http_response_code($code);
  header('Content-Type: application/json');
  echo json_encode(array_merge(['ok' => $ok, 'reply' => $reply], $extra), JSON_UNESCAPED_UNICODE);
  exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') chat_out(false, '', 405);
if (!assistant_llm_enabled()) chat_out(false, '', 503, ['fallback' => true]);
if (!csrf_check($_SERVER['HTTP_X_CSRF'] ?? '')) chat_out(false, '', 400, ['fallback' => true]);
if (rate_limited('chat', 20, 600)) chat_out(false, 'You have asked a lot of questions in a short time. Give me a minute and try again.', 429);

$raw = json_decode(file_get_contents('php://input'), true);
$in = is_array($raw['messages'] ?? null) ? $raw['messages'] : [];
$msgs = [];
foreach (array_slice($in, -8) as $m) {
  $role = ($m['role'] ?? '') === 'assistant' ? 'assistant' : 'user';
  $text = trim(mb_substr(strip_tags((string) ($m['content'] ?? '')), 0, 600));
  if ($text === '') continue;
  if ($msgs && $msgs[count($msgs) - 1]['role'] === $role) { $msgs[count($msgs) - 1]['content'] .= "\n" . $text; continue; }
  $msgs[] = ['role' => $role, 'content' => $text];
}
while ($msgs && $msgs[0]['role'] !== 'user') array_shift($msgs);
if (!$msgs || $msgs[count($msgs) - 1]['role'] !== 'user') chat_out(false, '', 422, ['fallback' => true]);

$system = "You are Sniff, the friendly guide on the Bark Media Africa (BMA) website. You help members and visitors find their way around BMA and the DoginalDogs / Doginals world.\n\n"
  . "RULES\n"
  . "- Answer only from the FACTS below. If something isn't covered, say you don't have that detail and suggest asking on X or Telegram.\n"
  . "- Keep replies short: 2 to 4 sentences, plain text, warm and clear. No markdown, no lists longer than 3 items.\n"
  . "- You are not a financial adviser. Never give price predictions, buy/sell advice or promises of returns. Remind people to do their own research.\n"
  . "- Never ask for or accept seed phrases, private keys or passwords. If someone offers one, tell them to never share it.\n"
  . "- Never invent facts, dates, prices, people or partnerships.\n"
  . "- Stay on topic (BMA, Doginals, the site). Politely steer back if asked about unrelated things.\n"
  . "- If a page would help, end your reply with one extra line exactly like: LINK: events.php (use only the page file names listed under PAGES).\n\n"
  . "FACTS\n" . assistant_knowledge();

$key = defined('CHATBOT_API_KEY') && CHATBOT_API_KEY !== '' ? CHATBOT_API_KEY : (getenv('ANTHROPIC_API_KEY') ?: '');
$model = defined('CHATBOT_MODEL') ? CHATBOT_MODEL : 'claude-haiku-4-5-20251001';

if (!function_exists('curl_init')) chat_out(false, '', 503, ['fallback' => true]);
$ch = curl_init('https://api.anthropic.com/v1/messages');
curl_setopt_array($ch, [
  CURLOPT_POST => true,
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_TIMEOUT => 20,
  CURLOPT_HTTPHEADER => ['content-type: application/json', 'x-api-key: ' . $key, 'anthropic-version: 2023-06-01'],
  CURLOPT_POSTFIELDS => json_encode(['model' => $model, 'max_tokens' => 350, 'system' => $system, 'messages' => $msgs]),
]);
$body = curl_exec($ch);
$status = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
$err = curl_error($ch);
curl_close($ch);

$data = $body ? json_decode($body, true) : null;
$text = '';
foreach (($data['content'] ?? []) as $block) if (($block['type'] ?? '') === 'text') $text .= $block['text'];
$text = trim($text);

if ($status !== 200 || $text === '') {
  error_log('BMA chat: API call failed, status ' . $status . ' ' . $err . ' ' . mb_substr((string) $body, 0, 300));
  chat_out(false, '', 502, ['fallback' => true]);
}

// Pull out an optional "LINK: page.php" line, whitelisted to real pages.
$link = null;
if (preg_match('/^\s*LINK:\s*([a-z\-]+\.php)\s*$/mi', $text, $m)) {
  $ok = ['index.php', 'about.php', 'services.php', 'events.php', 'spaces.php', 'shop.php', 'join.php', 'partner.php'];
  if (in_array(strtolower($m[1]), $ok, true)) $link = strtolower($m[1]);
  $text = trim(preg_replace('/^\s*LINK:.*$/mi', '', $text));
}
chat_out(true, mb_substr($text, 0, 900), 200, ['link' => $link]);
