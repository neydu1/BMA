<?php
/* Newsletter signup. Saves to storage/subscribers.csv, notifies admin,
   and sends the subscriber a welcome email.
   To use Mailchimp/Brevo later, add the API call where marked below. */
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/mailer.php';

$isAjax = ($_SERVER['HTTP_X_REQUESTED_WITH'] ?? '') === 'fetch';
function finish($ok, $msg, $code = 200) {
  global $isAjax;
  if ($isAjax) json_out($ok, $msg, $code);
  $_SESSION['flash'] = ['ok' => $ok, 'msg' => $msg];
  header('Location: ' . ($_SERVER['HTTP_REFERER'] ?? '../index.php'));
  exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') finish(false, 'Use the subscribe form.', 405);
if (!empty($_POST['website'])) finish(true, "You're subscribed. See you Friday.");
if (!csrf_check($_POST['csrf'] ?? '')) finish(false, 'Your session expired. Refresh the page and try again.', 400);
if (rate_limited('news', 5, 600)) finish(false, 'Too many attempts. Try again in 10 minutes.', 429);

$email = filter_var(trim($_POST['email'] ?? ''), FILTER_VALIDATE_EMAIL);
$source = clean($_POST['source'] ?? 'site', 30);
if (!$email) finish(false, 'Enter a valid email address, like name@email.com.', 422);

if (email_exists_in('subscribers.csv', $email)) finish(true, "You're already on the list. Next issue lands Friday.");

store_row('subscribers.csv', ['date' => date('c'), 'email' => $email, 'name' => '', 'source' => $source]);

// --- Optional: push to Mailchimp / Brevo / ConvertKit here ---

send_mail(ADMIN_EMAIL, ADMIN_NAME, "New newsletter subscriber: $email",
  email_layout('New newsletter subscriber', email_table(['Email' => $email, 'Signed up from' => $source, 'Date' => date('D j M Y, g:i a T')])),
  $email);

if (SEND_CONFIRMATIONS) {
  send_mail($email, '', "You're on the weekly bark",
    email_layout("You're on the list", '<p style="font-size:15px;line-height:1.6">Every Friday you\'ll get upcoming Spaces, Doginals news from an African point of view, and open intern roles. No spam, and you can unsubscribe by replying "stop".</p>'));
}

finish(true, "You're subscribed. See you Friday.");
