<?php
/* Sign in with X (OAuth 2.0 + PKCE) for the Two Paws leaderboard.
   ?status          → JSON: is it configured, who is signed in (p1 / p2)
   ?start=p1|p2     → sends the player to X to approve
   (X redirects back here with ?code&state)
   ?logout=p1|p2    → forget that player
   Only the public profile is read (users.read). Nothing is ever posted. */
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/game_lib.php';

$back = base_url() . '/game.php';
$redirect = base_url() . '/api/x-auth.php';
$slotOk = fn($s) => in_array($s, ['p1', 'p2'], true);

if (isset($_GET['status'])) {
  header('Content-Type: application/json'); header('Cache-Control: no-store');
  $p = [];
  foreach (['p1', 'p2'] as $s) if (!empty($_SESSION['x'][$s])) $p[$s] = $_SESSION['x'][$s];
  echo json_encode(['ok' => true, 'configured' => x_configured(), 'players' => (object) $p]);
  exit;
}

if (isset($_GET['logout']) && $slotOk($_GET['logout'])) {
  unset($_SESSION['x'][$_GET['logout']]);
  header('Location: ' . $back . '?x=out'); exit;
}

if (isset($_GET['start'])) {
  if (!x_configured()) { header('Location: ' . $back . '?x=off'); exit; }
  $slot = $slotOk($_GET['start']) ? $_GET['start'] : 'p1';
  $verifier = rtrim(strtr(base64_encode(random_bytes(48)), '+/', '-_'), '=');
  $state = bin2hex(random_bytes(16));
  $_SESSION['x_oauth'] = ['state' => $state, 'verifier' => $verifier, 'slot' => $slot, 't' => time()];
  $challenge = rtrim(strtr(base64_encode(hash('sha256', $verifier, true)), '+/', '-_'), '=');
  $q = http_build_query([
    'response_type' => 'code', 'client_id' => X_CLIENT_ID, 'redirect_uri' => $redirect,
    'scope' => 'users.read tweet.read', 'state' => $state, 'code_challenge' => $challenge, 'code_challenge_method' => 'S256',
  ], '', '&', PHP_QUERY_RFC3986);
  header('Location: https://x.com/i/oauth2/authorize?' . $q); exit;
}

if (isset($_GET['code'], $_GET['state'])) {
  $o = $_SESSION['x_oauth'] ?? null;
  unset($_SESSION['x_oauth']);
  if (!$o || !hash_equals($o['state'], (string) $_GET['state']) || time() - $o['t'] > 900) { header('Location: ' . $back . '?x=expired'); exit; }
  $headers = ['Content-Type: application/x-www-form-urlencoded'];
  $body = ['grant_type' => 'authorization_code', 'code' => $_GET['code'], 'redirect_uri' => $redirect, 'code_verifier' => $o['verifier'], 'client_id' => X_CLIENT_ID];
  if (X_CLIENT_SECRET !== '') $headers[] = 'Authorization: Basic ' . base64_encode(X_CLIENT_ID . ':' . X_CLIENT_SECRET);
  [$code, $tok] = x_http('POST', 'https://api.x.com/2/oauth2/token', $headers, http_build_query($body));
  if ($code !== 200 || empty($tok['access_token'])) { header('Location: ' . $back . '?x=failed'); exit; }
  [$c2, $me] = x_http('GET', 'https://api.x.com/2/users/me?user.fields=profile_image_url,verified', ['Authorization: Bearer ' . $tok['access_token']]);
  if ($c2 !== 200 || empty($me['data']['username'])) { header('Location: ' . $back . '?x=failed'); exit; }
  $u = $me['data'];
  $_SESSION['x'][$o['slot']] = [
    'id' => $u['id'], 'username' => $u['username'], 'name' => mb_substr($u['name'] ?? $u['username'], 0, 50),
    'avatar' => str_replace('_normal.', '_bigger.', $u['profile_image_url'] ?? ''),
  ];
  header('Location: ' . $back . '?x=ok&slot=' . $o['slot']); exit;
}

if (isset($_GET['error'])) { header('Location: ' . $back . '?x=cancelled'); exit; }
header('Location: ' . $back);
