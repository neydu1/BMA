<?php
$pageTitle = 'Web3 Academy';
$pageDesc = 'Web3 Made Simple: Bark Media Africa\'s free beginner course in 12 modules. Blockchain, wallets, tokens, DeFi, NFTs, safety and Web3 careers, explained in plain language.';
$extraHead = '<link rel="stylesheet" href="assets/css/academy.css?v=1">';
require __DIR__ . '/includes/header.php';
require __DIR__ . '/includes/academy_data.php';
$extraScripts = '<script src="assets/js/academy.js?v=1" defer></script>';
$pad = fn($n) => str_pad($n, 2, '0', STR_PAD_LEFT);
?>
<?= page_banner('Web3 Academy', 'Web3 Made Simple: blockchain technology for beginners, in 12 short modules. Free, practical, and safety-first.') ?>

<!-- About the Academy -->
<section class="section ac-about" id="about">
  <div class="wrap ac-about-grid">
    <figure class="ac-cover"><img src="assets/images/academy/cover.jpg" alt="Illustrations from the twelve Web3 Made Simple modules" width="900" height="910" loading="eager"></figure>
    <div>
      <p class="eyebrow">About the Academy</p>
      <h2>Your journey into blockchain starts here</h2>
      <p class="lede-sm">Heard people talk about Bitcoin, wallets, NFTs or DeFi and never quite understood them? The BMA Web3 Academy breaks complicated ideas into simple explanations, practical demonstrations and real-world examples. No technical background or crypto experience needed.</p>
      <p class="muted"><?= e($ACADEMY['mission']) ?> We learn together, grow together, and create opportunities together.</p>
      <dl class="ac-facts">
        <div><dt>Duration</dt><dd><?= e($ACADEMY['duration']) ?></dd></div>
        <div><dt>Modules</dt><dd>12</dd></div>
        <div><dt>Format</dt><dd>Short lessons + practice</dd></div>
        <div><dt>Cost</dt><dd>Free</dd></div>
      </dl>
      <p class="ac-for"><b>Who it's for:</b> <?= e($ACADEMY['audience']) ?>.</p>
      <div class="btn-row">
        <a class="btn btn-gold" href="#modules">Start Module 1</a>
        <a class="btn btn-ghost" href="join.php?focus=Crypto+onboarding">Join a live class</a>
      </div>
      <p class="ac-motto"><?= e($ACADEMY['motto']) ?></p>
    </div>
  </div>
</section>

<!-- in-page navigation + progress -->
<nav class="ac-jump" aria-label="Academy sections">
  <div class="wrap ac-jump-row">
    <div class="ac-jump-links">
      <a href="#modules">Modules</a><a href="#study">How to study</a><a href="#glossary">Glossary</a><a href="#compare">Compare</a><a href="#safety">Safety</a><a href="#quiz">Quiz</a><a href="#graduate">Graduate</a><a href="#resources">Resources</a>
    </div>
    <div class="ac-progress" aria-live="polite"><span class="ac-bar"><i data-progress-bar></i></span><b data-progress-text>0/12</b></div>
  </div>
</nav>

<!-- What you'll be able to do -->
<section class="section ac-objectives">
  <div class="wrap">
    <div class="section-head"><p class="eyebrow">Learning outcomes</p><h2>By the end you'll be able to…</h2></div>
    <ul class="ac-obj">
      <?php foreach ($ACADEMY_OBJECTIVES as $o): ?><li><?= e($o) ?></li><?php endforeach; ?>
    </ul>
  </div>
</section>

<!-- Modules -->
<section class="section ac-modules" id="modules">
  <div class="wrap">
    <div class="section-head"><p class="eyebrow">The course</p><h2>12 modules, one step at a time</h2><p class="muted">Tap a module to open its notes. Mark it done when you finish; your progress is saved on this device.</p></div>
    <div class="ac-grid">
      <?php foreach ($MODULES as $m): ?>
        <button type="button" class="ac-card" data-module="<?= $m['n'] ?>" aria-haspopup="dialog">
          <span class="ac-img"><img src="assets/images/academy/module-<?= $pad($m['n']) ?>.jpg" alt="" width="400" height="300" loading="lazy"><i class="ac-done" aria-hidden="true">✓</i></span>
          <span class="ac-meta">Module <?= $pad($m['n']) ?> · Week <?= $m['week'] ?></span>
          <b><?= e($m['title']) ?></b>
          <small><?= e($m['tag']) ?></small>
        </button>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- module notes (moved into the dialog by academy.js; readable without JS too) -->
<div class="ac-notes" id="ac-notes">
  <?php foreach ($MODULES as $m): ?>
    <article class="ac-note" id="module-<?= $m['n'] ?>" data-note="<?= $m['n'] ?>">
      <img class="ac-note-img" src="assets/images/academy/module-<?= $pad($m['n']) ?>.jpg" alt="" width="400" height="300" loading="lazy">
      <p class="ac-meta">Module <?= $pad($m['n']) ?> · Week <?= $m['week'] ?> · <?= e($m['tag']) ?></p>
      <h3><?= e($m['title']) ?></h3>
      <ul class="ac-chips"><?php foreach ($m['concepts'] as $c): ?><li><?= e($c) ?></li><?php endforeach; ?></ul>
      <?php foreach ($m['explain'] as $p): ?><p><?= e($p) ?></p><?php endforeach; ?>
      <div class="ac-boxes">
        <div class="ac-box ex"><b>Example</b><p><?= e($m['example']) ?></p></div>
        <div class="ac-box rem"><b>Remember</b><p><?= e($m['remember']) ?></p></div>
        <div class="ac-box act"><b>Practical activity</b><p><?= e($m['activity']) ?></p></div>
      </div>
    </article>
  <?php endforeach; ?>
</div>

<dialog class="ac-dialog" id="ac-dialog" aria-labelledby="ac-dialog-title">
  <div class="ac-dialog-inner">
    <button type="button" class="ac-x" data-close aria-label="Close">&times;</button>
    <div class="ac-dialog-body" id="ac-dialog-body"></div>
    <div class="ac-dialog-foot">
      <button type="button" class="tp-link ac-prev" data-step="-1">← Previous</button>
      <button type="button" class="btn btn-gold ac-mark" data-mark>Mark as done</button>
      <button type="button" class="tp-link ac-next" data-step="1">Next →</button>
    </div>
  </div>
</dialog>

<!-- How to study -->
<section class="section ac-study" id="study">
  <div class="wrap ac-two">
    <div>
      <p class="eyebrow">How to study</p>
      <h2>A 30-minute lesson</h2>
      <ol class="ac-flow">
        <?php foreach ($LESSON_FLOW as [$stage, $time, $what]): ?><li><b><?= e($stage) ?> <span><?= e($time) ?></span></b><p><?= e($what) ?></p></li><?php endforeach; ?>
      </ol>
    </div>
    <div>
      <p class="eyebrow">Pace</p>
      <h2>Six weeks, two modules a week</h2>
      <p class="muted">Prefer a slower pace? Take one module a week over twelve weeks.</p>
      <ol class="ac-plan">
        <?php foreach ($STUDY_PLAN as [$w, $mods, $goal]): ?><li><span class="ac-wk">Week <?= $w ?></span><span><b>Modules <?= e($mods) ?></b><small><?= e($goal) ?></small></span></li><?php endforeach; ?>
      </ol>
    </div>
  </div>
</section>

<!-- Glossary -->
<section class="section ac-glossary" id="glossary">
  <div class="wrap">
    <div class="section-head"><p class="eyebrow">Vocabulary</p><h2>Web3 words, in plain language</h2></div>
    <label class="ac-search"><span class="sr">Search the glossary</span><input type="search" id="ac-gsearch" placeholder="Search a word, e.g. seed phrase" autocomplete="off"></label>
    <dl class="ac-terms" id="ac-terms">
      <?php foreach ($GLOSSARY as [$t, $d]): ?><div class="ac-term"><dt><?= e($t) ?></dt><dd><?= e($d) ?></dd></div><?php endforeach; ?>
    </dl>
    <p class="muted ac-empty" id="ac-gempty" hidden>No match. Try another word.</p>
  </div>
</section>

<!-- Comparisons -->
<section class="section ac-compare" id="compare">
  <div class="wrap">
    <div class="section-head"><p class="eyebrow">Side by side</p><h2>Important comparisons</h2></div>
    <div class="ac-tabs" role="tablist">
      <?php foreach ($COMPARISONS as $i => $c): ?><button type="button" role="tab" id="tab-<?= $c['id'] ?>" aria-controls="pane-<?= $c['id'] ?>" aria-selected="<?= $i ? 'false' : 'true' ?>"><?= e($c['label']) ?></button><?php endforeach; ?>
    </div>
    <?php foreach ($COMPARISONS as $i => $c): ?>
      <div class="ac-pane" role="tabpanel" id="pane-<?= $c['id'] ?>" aria-labelledby="tab-<?= $c['id'] ?>" <?= $i ? 'hidden' : '' ?>>
        <div class="ac-vs"><div class="ac-vs-col"><h3><?= e($c['a']) ?></h3><ul><?php foreach ($c['rows'] as [$a]): ?><li><?= e($a) ?></li><?php endforeach; ?></ul></div><span class="ac-vs-mid" aria-hidden="true">vs</span><div class="ac-vs-col b"><h3><?= e($c['b']) ?></h3><ul><?php foreach ($c['rows'] as [, $b]): ?><li><?= e($b) ?></li><?php endforeach; ?></ul></div></div>
        <?php if ($c['note']): ?><p class="muted small"><?= e($c['note']) ?></p><?php endif; ?>
      </div>
    <?php endforeach; ?>
  </div>
</section>

<!-- Safety -->
<section class="section ac-safety" id="safety">
  <div class="wrap">
    <div class="section-head"><p class="eyebrow">Safety always</p><h2>Six rules to protect yourself</h2></div>
    <ol class="ac-rules">
      <?php foreach ($SAFETY as [$t, $d]): ?><li><b><?= e($t) ?></b><p><?= e($d) ?></p></li><?php endforeach; ?>
    </ol>
    <p class="muted small">Want to check a link someone sent you? Use the <a class="text-link" href="web3.php#safety">scam checker in the Web3 Hub</a>.</p>
  </div>
</section>

<!-- Quiz -->
<section class="section ac-quiz-sec" id="quiz">
  <div class="wrap narrow">
    <div class="section-head"><p class="eyebrow">Check yourself</p><h2>10-question review quiz</h2></div>
    <div class="ac-quiz" id="ac-quiz" data-total="<?= count($QUIZ) ?>">
      <?php foreach ($QUIZ as $i => [$q, $opts, $ans, $why]): ?>
        <fieldset class="ac-q" data-q="<?= $i ?>" data-ans="<?= $ans ?>" <?= $i ? 'hidden' : '' ?>>
          <legend><span>Question <?= $i + 1 ?> of <?= count($QUIZ) ?></span><?= e($q) ?></legend>
          <?php foreach ($opts as $k => $o): ?><button type="button" class="ac-opt" data-opt="<?= $k ?>"><i><?= chr(65 + $k) ?></i><?= e($o) ?></button><?php endforeach; ?>
          <p class="ac-why" hidden><?= e($why) ?></p>
        </fieldset>
      <?php endforeach; ?>
      <div class="ac-result" hidden><p class="ac-score"><b data-score>0</b>/<?= count($QUIZ) ?></p><p data-verdict></p><button type="button" class="btn btn-ghost" data-retry>Try again</button></div>
      <div class="ac-quiz-foot"><span class="ac-dots" aria-hidden="true"><?php foreach ($QUIZ as $i => $_) echo '<i></i>'; ?></span><button type="button" class="btn btn-gold" data-next disabled>Next question</button></div>
    </div>

    <h3 class="ac-sub">Short-answer practice</h3>
    <p class="muted">Answer in your own words first, then reveal a suggested answer.</p>
    <div class="ac-practice">
      <?php foreach ($PRACTICE as [$q, $a]): ?><details><summary><?= e($q) ?></summary><p><?= e($a) ?></p></details><?php endforeach; ?>
    </div>
  </div>
</section>

<!-- Graduate -->
<section class="section ac-grad" id="graduate">
  <div class="wrap ac-two">
    <div>
      <p class="eyebrow">Assessment &amp; graduation</p>
      <h2>How you graduate</h2>
      <p class="muted">We assess understanding and practical skills, never how much crypto you own or whether a token goes up.</p>
      <div class="ac-weights">
        <?php foreach ($ASSESSMENT as [$t, $w]): ?><div class="ac-w"><span><?= e($t) ?></span><span class="ac-w-bar"><i style="width:<?= $w ?>%"></i></span><b><?= $w ?>%</b></div><?php endforeach; ?>
      </div>
      <p class="ac-req"><b>To complete the course:</b> a final score of at least 70%, the security module (Module 9) completed, and your final project submitted. You receive a BMA certificate of completion.</p>
    </div>
    <div>
      <p class="eyebrow">Final revision checklist</p>
      <h2>Am I ready?</h2>
      <ul class="ac-check" id="ac-check">
        <?php foreach ($CHECKLIST as $i => $c): ?><li><label><input type="checkbox" data-check="<?= $i ?>"><span><?= e($c) ?></span></label></li><?php endforeach; ?>
      </ul>
    </div>
  </div>
</section>

<!-- Resources -->
<section class="section ac-res" id="resources">
  <div class="wrap">
    <div class="section-head"><p class="eyebrow">Keep learning</p><h2>Recommended resources</h2><p class="muted">Always check you are on the official site before connecting anything.</p></div>
    <div class="ac-res-grid">
      <?php foreach ($RESOURCES as [$t, $u, $d]): ?><a class="ac-res-card" href="<?= e($u) ?>" target="_blank" rel="noopener"><b><?= e($t) ?> ↗</b><small><?= e(parse_url($u, PHP_URL_HOST)) ?></small><span><?= e($d) ?></span></a><?php endforeach; ?>
    </div>
    <p class="ac-final">You don't need to know everything to get started. You only need to be willing to learn.</p>
  </div>
</section>

<?= join_cta() ?>
<?php require __DIR__ . '/includes/footer.php'; ?>
