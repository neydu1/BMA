<?php
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/orders.php';
$ref = preg_replace('/[^A-Za-z0-9\-]/', '', $_GET['reference'] ?? $_GET['trxref'] ?? '');
$order = $ref ? order_confirm($ref) : null;
$status = $order['status'] ?? 'unknown';
$pageTitle = $status === 'paid' ? 'Order confirmed' : 'Order status';
$bodyClass = $status === 'paid' ? 'order-paid' : '';
require __DIR__ . '/includes/header.php';
?>
<section class="section order-done">
  <div class="wrap narrow">
    <?php if ($status === 'paid'): ?>
      <div class="receipt" data-clear-cart>
        <div class="receipt-coin" aria-hidden="true"><svg viewBox="0 0 24 24" width="44" height="44"><path d="M5 12.5l4.5 4.5L19 7.5" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"/></svg></div>
        <h1>Payment received. Thank you, <?= e(explode(' ', $order['customer']['name'])[0]) ?>!</h1>
        <p class="lede">Order <b><?= e($order['ref']) ?></b> is confirmed. A receipt is on its way to <?= e($order['customer']['email']) ?>. <?= e($order['shipping']['eta']) ?>.</p>
        <ul class="receipt-lines">
          <?php foreach ($order['lines'] as $l): ?>
            <li><img src="<?= e(product_img($l['id'], $l['color'])) ?>" alt="" width="64" height="64"><span><b><?= e($l['name']) ?></b><small><?= e(variant_label($l)) ?> × <?= $l['qty'] ?></small></span><span><?= money($l['total']) ?></span></li>
          <?php endforeach; ?>
          <li class="r-sub"><span>Delivery: <?= e($order['shipping']['label']) ?></span><span><?= $order['shipping']['price'] ? money($order['shipping']['price']) : 'Free' ?></span></li>
          <li class="r-total"><span>Total paid</span><span><?= money($order['total']) ?></span></li>
        </ul>
        <div class="btn-row center"><a class="btn btn-gold" href="shop.php">Keep shopping</a><a class="btn btn-ghost-dark" href="<?= e($SITE['xUrl']) ?>" target="_blank" rel="noopener">Show it off on X</a></div>
      </div>
    <?php elseif ($status === 'pending'): ?>
      <div class="receipt">
        <h1>We're confirming your payment</h1>
        <p class="lede">Paystack hasn't confirmed order <b><?= e($ref) ?></b> yet. This usually takes a few seconds for bank transfers and USSD.</p>
        <div class="btn-row center"><a class="btn btn-gold" href="order-complete.php?reference=<?= e($ref) ?>">Check again</a><a class="btn btn-ghost-dark" href="checkout.php">Back to checkout</a></div>
        <p class="muted small">If money left your account, you'll get an email as soon as it's confirmed.</p>
      </div>
    <?php elseif ($order): ?>
      <div class="receipt">
        <h1>Payment didn't go through</h1>
        <p class="lede">Order <b><?= e($ref) ?></b> wasn't paid<?= $status === 'amount_mismatch' ? ' in full. Contact us with your reference and we\'ll sort it out' : '' ?>. Your cart is still saved.</p>
        <div class="btn-row center"><a class="btn btn-gold" href="checkout.php">Try paying again</a><a class="btn btn-ghost-dark" href="mailto:<?= e($SITE['email']) ?>?subject=Order <?= e($ref) ?>">Email us</a></div>
      </div>
    <?php else: ?>
      <div class="receipt">
        <h1>We couldn't find that order</h1>
        <p class="lede">Check the link in your email, or go back to the shop.</p>
        <div class="btn-row center"><a class="btn btn-gold" href="shop.php">Go to the shop</a></div>
      </div>
    <?php endif; ?>
  </div>
</section>
<?php require __DIR__ . '/includes/footer.php'; ?>
