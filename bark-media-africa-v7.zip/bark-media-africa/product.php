<?php
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/products.php';
$slug = $_GET['item'] ?? '';
if (!isset($PRODUCTS[$slug])) { require __DIR__ . '/404.php'; exit; }
$p = $PRODUCTS[$slug];
$pageTitle = $p['name'];
$pageDesc = $p['short'];
require __DIR__ . '/includes/header.php';
$first = array_key_first($p['colors']);
$related = array_slice(array_values(array_filter(array_keys($PRODUCTS), fn($s) => $s !== $slug)), 0, 3);
?>
<section class="section product-page">
  <div class="wrap">
    <nav class="crumbs" aria-label="Breadcrumb"><a href="shop.php">Shop</a> <span aria-hidden="true">/</span> <span><?= e($p['name']) ?></span></nav>
    <div class="pd-grid">
      <div class="pd-media" data-tilt-media>
        <div class="pd-stage">
          <img src="<?= e(product_img($slug, $first)) ?>" alt="<?= e($p['name'] . ' in ' . $first) ?>" id="pd-img" width="600" height="600">
        </div>
      </div>
      <form class="pd-info" id="pd-form" data-product="<?= e($slug) ?>">
        <?php if ($p['badge']): ?><span class="tag"><?= e($p['badge']) ?></span><?php endif; ?>
        <h1><?= e($p['name']) ?></h1>
        <p class="pd-price"><?= money($p['price']) ?></p>
        <p class="pd-desc"><?= e($p['desc']) ?></p>

        <?php if (count($p['colors']) > 1): ?>
        <fieldset class="opt">
          <legend>Colour: <b id="color-name"><?= e($first) ?></b></legend>
          <div class="swatches">
            <?php foreach ($p['colors'] as $cn => [$hex]): ?>
              <label class="sw" style="--sw:<?= e($hex) ?>">
                <input type="radio" name="color" value="<?= e($cn) ?>" data-src="<?= e(product_img($slug, $cn)) ?>" <?= $cn === $first ? 'checked' : '' ?>>
                <span class="sr"><?= e($cn) ?></span>
              </label>
            <?php endforeach; ?>
          </div>
        </fieldset>
        <?php else: ?><input type="hidden" name="color" value="<?= e($first) ?>"><?php endif; ?>

        <?php if ($p['sizes']): ?>
        <fieldset class="opt">
          <legend>Size</legend>
          <div class="sizes">
            <?php foreach ($p['sizes'] as $s): ?>
              <label class="size"><input type="radio" name="size" value="<?= e($s) ?>"><span><?= e($s) ?></span></label>
            <?php endforeach; ?>
          </div>
          <p class="form-msg err" id="size-msg" role="alert"></p>
        </fieldset>
        <?php endif; ?>

        <div class="buy-row">
          <div class="qty" aria-label="Quantity">
            <button type="button" data-qty="-1" aria-label="Decrease quantity">−</button>
            <input type="number" name="qty" value="1" min="1" max="20" inputmode="numeric" aria-label="Quantity">
            <button type="button" data-qty="1" aria-label="Increase quantity">+</button>
          </div>
          <button class="btn btn-gold grow" type="submit" name="action" value="add">Add to cart</button>
        </div>
        <button class="btn btn-ghost-dark block" type="submit" name="action" value="buy">Buy now</button>

        <ul class="pd-details">
          <?php foreach ($p['details'] as $d): ?><li><?= e($d) ?></li><?php endforeach; ?>
        </ul>
        <p class="muted small">Pay with card, bank transfer or USSD through Paystack. Abuja delivery from <?= money($SHIPPING['abuja']['price']) ?>, or free pickup at a meetup.</p>
      </form>
    </div>
  </div>
</section>

<section class="section tinted">
  <div class="wrap">
    <div class="section-head"><h2>Goes well with</h2></div>
    <div class="product-grid">
      <?php foreach ($related as $r) echo product_card($r); ?>
    </div>
  </div>
</section>
<?php require __DIR__ . '/includes/footer.php'; ?>
