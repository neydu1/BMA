<?php
/* Draws product mockups as SVG with the BMA logo on them.
   art.php?p=pack-tee&c=Indigo  — cached by the browser for a week. */
require __DIR__ . '/includes/config.php';
require __DIR__ . '/includes/products.php';

$slug = $_GET['p'] ?? '';
if (!isset($PRODUCTS[$slug])) { http_response_code(404); exit; }
$p = $PRODUCTS[$slug];
$cName = $_GET['c'] ?? array_key_first($p['colors']);
if (!isset($p['colors'][$cName])) $cName = array_key_first($p['colors']);
[$hex, $logoTone] = $p['colors'][$cName];

$etag = '"' . md5($slug . $cName . filemtime(__FILE__) . filemtime(__DIR__ . '/includes/products.php')) . '"';
header('Content-Type: image/svg+xml; charset=utf-8');
header('Cache-Control: public, max-age=604800');
header('ETag: ' . $etag);
if (($_SERVER['HTTP_IF_NONE_MATCH'] ?? '') === $etag) { http_response_code(304); exit; }

$logoFile = __DIR__ . '/assets/images/' . ($logoTone === 'dark' ? 'logo-dark-160.png' : 'logo-160.png');
$logo = 'data:image/png;base64,' . base64_encode(file_get_contents($logoFile));
$logoDark = 'data:image/png;base64,' . base64_encode(file_get_contents(__DIR__ . '/assets/images/logo-dark-160.png'));
$L = fn($x, $y, $s, $src = null) => '<image href="' . ($src ?? $logo) . '" x="' . $x . '" y="' . $y . '" width="' . $s . '" height="' . $s . '"/>';

$defs = '<defs>
  <linearGradient id="shade" x1="0" x2="1"><stop offset="0" stop-color="#fff" stop-opacity=".22"/><stop offset=".45" stop-color="#fff" stop-opacity="0"/><stop offset="1" stop-color="#000" stop-opacity=".28"/></linearGradient>
  <linearGradient id="cyl" x1="0" x2="1"><stop offset="0" stop-color="#000" stop-opacity=".2"/><stop offset=".22" stop-color="#fff" stop-opacity=".35"/><stop offset=".5" stop-color="#fff" stop-opacity="0"/><stop offset=".92" stop-color="#000" stop-opacity=".4"/></linearGradient>
  <linearGradient id="top" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#fff" stop-opacity=".18"/><stop offset="1" stop-color="#000" stop-opacity=".18"/></linearGradient>
  <pattern id="kente" width="60" height="40" patternUnits="userSpaceOnUse">
    <rect width="24" height="40" fill="#F4B63F"/><rect x="24" width="3" height="40" fill="#0F0C36"/><rect x="27" width="13" height="40" fill="#1F8A5B"/>
    <rect x="40" width="3" height="40" fill="#F4B63F"/><rect x="43" width="14" height="40" fill="#C8372D"/><rect x="57" width="3" height="40" fill="#0F0C36"/>
  </pattern>
  <radialGradient id="ground"><stop offset="0" stop-color="#000" stop-opacity=".28"/><stop offset="1" stop-color="#000" stop-opacity="0"/></radialGradient>
</defs>';
$ground = '<ellipse cx="300" cy="555" rx="200" ry="22" fill="url(#ground)"/>';
$both = fn($d, $extra = '') => '<path d="' . $d . '" fill="' . $hex . '"' . $extra . '/><path d="' . $d . '" fill="url(#shade)"/>';

switch ($p['art']) {
  case 'tee':
    $body = 'M180 105 L248 80 Q300 120 352 80 L420 105 L515 175 L475 255 L428 232 L428 515 Q300 530 172 515 L172 232 L125 255 L85 175 Z';
    $art = $ground . $both($body)
      . '<path d="M248 80 Q300 120 352 80 Q300 142 248 80 Z" fill="#000" opacity=".28"/>'
      . '<path d="M172 232 Q177 170 181 108 M428 232 Q423 170 419 108" stroke="#000" stroke-opacity=".14" stroke-width="3" fill="none"/>'
      . $L(245, 150, 110)
      . '<rect x="392" y="478" width="22" height="30" fill="url(#kente)"/>';
    break;

  case 'hoodie':
    $body = 'M200 130 Q300 175 400 130 L470 165 L540 400 L500 420 L440 262 L440 520 Q300 535 160 520 L160 262 L100 420 L60 400 L130 165 Z';
    $art = $ground
      . '<path d="M212 135 Q300 25 388 135 L372 180 Q300 150 228 180 Z" fill="' . $hex . '"/><path d="M212 135 Q300 25 388 135 L372 180 Q300 150 228 180 Z" fill="#000" opacity=".22"/>'
      . $both($body)
      . '<path d="M232 138 Q300 215 368 138 Q300 165 232 138 Z" fill="#000" opacity=".38"/>'
      . '<path d="M282 172 L276 252 M318 172 L324 252" stroke="#F5EEE1" stroke-width="5" stroke-linecap="round"/>'
      . '<path d="M222 400 L378 400 L402 482 L198 482 Z" fill="#000" opacity=".13"/>'
      . '<rect x="160" y="500" width="280" height="22" fill="#000" opacity=".12"/>'
      . '<path d="M500 420 L540 400 L548 425 L508 444 Z M100 420 L60 400 L52 425 L92 444 Z" fill="#000" opacity=".15"/>'
      . $L(252, 272, 96);
    break;

  case 'bottle':
    $body = 'M262 136 Q262 160 228 185 Q205 202 205 238 L205 505 Q205 540 240 540 L360 540 Q395 540 395 505 L395 238 Q395 202 372 185 Q338 160 338 136 Z';
    $art = $ground
      . '<path d="M272 72 Q300 30 328 72" stroke="#2B2B33" stroke-width="12" fill="none" stroke-linecap="round"/>'
      . '<rect x="250" y="70" width="100" height="44" rx="12" fill="#2B2B33"/><rect x="250" y="70" width="100" height="44" rx="12" fill="url(#cyl)"/>'
      . '<rect x="262" y="112" width="76" height="28" fill="#C9C9CF"/><rect x="262" y="112" width="76" height="28" fill="url(#cyl)"/>'
      . '<clipPath id="bc"><path d="' . $body . '"/></clipPath>'
      . '<path d="' . $body . '" fill="' . $hex . '"/>'
      . '<rect x="190" y="460" width="220" height="38" fill="url(#kente)" clip-path="url(#bc)"/>'
      . '<path d="' . $body . '" fill="url(#cyl)"/>'
      . '<rect x="226" y="212" width="12" height="270" rx="6" fill="#fff" opacity=".28"/>'
      . $L(250, 272, 100);
    break;

  case 'cap':
    $crown = 'M140 335 Q140 172 300 162 Q460 172 460 335 Z';
    $brim = 'M122 332 Q300 296 478 332 Q470 392 300 396 Q130 392 122 332 Z';
    $art = $ground
      . '<clipPath id="cc"><path d="' . $crown . '"/></clipPath>'
      . '<path d="' . $crown . '" fill="' . $hex . '"/>'
      . '<rect x="120" y="290" width="360" height="26" fill="url(#kente)" clip-path="url(#cc)"/>'
      . '<path d="' . $crown . '" fill="url(#shade)"/>'
      . '<path d="M300 166 Q290 250 300 290 M300 166 Q222 222 204 300 M300 166 Q378 222 396 300" stroke="#000" stroke-opacity=".2" stroke-width="3" fill="none"/>'
      . '<circle cx="300" cy="166" r="11" fill="' . $hex . '"/><circle cx="300" cy="166" r="11" fill="#000" opacity=".2"/>'
      . '<path d="' . $brim . '" fill="' . $hex . '"/><path d="' . $brim . '" fill="url(#top)"/><path d="' . $brim . '" fill="#000" opacity=".18"/>'
      . '<path d="M140 350 Q300 318 460 350" stroke="#fff" stroke-opacity=".25" stroke-width="2" stroke-dasharray="6 6" fill="none"/>'
      . $L(260, 196, 82);
    break;

  case 'tote':
    $bag = 'M150 220 L450 220 L472 522 L128 522 Z';
    $art = $ground
      . '<path d="M222 236 Q222 92 300 92 Q378 92 378 236" stroke="' . $hex . '" stroke-width="18" fill="none"/>'
      . '<path d="M222 236 Q222 92 300 92 Q378 92 378 236" stroke="#000" stroke-opacity=".22" stroke-width="18" fill="none"/>'
      . $both($bag)
      . '<rect x="150" y="220" width="300" height="26" fill="#000" opacity=".1"/>'
      . '<path d="M160 246 L440 246" stroke="#000" stroke-opacity=".18" stroke-width="2" stroke-dasharray="7 6"/>'
      . $L(222, 296, 156);
    break;

  case 'sleeve':
    $art = $ground . '<g transform="rotate(-6 300 320)">'
      . '<rect x="105" y="170" width="390" height="300" rx="42" fill="' . $hex . '"/><rect x="105" y="170" width="390" height="300" rx="42" fill="url(#shade)"/>'
      . '<rect x="117" y="182" width="366" height="276" rx="34" fill="none" stroke="#000" stroke-opacity=".18" stroke-width="2" stroke-dasharray="6 5"/>'
      . '<path d="M150 196 L450 196" stroke="#1B1B1F" stroke-opacity=".55" stroke-width="7" stroke-linecap="round"/>'
      . '<rect x="438" y="190" width="16" height="44" rx="5" fill="url(#kente)"/>'
      . $L(245, 262, 110) . '</g>';
    break;

  case 'stickers':
  default:
    $paw = '<g fill="#F5EEE1"><ellipse cx="0" cy="12" rx="22" ry="18"/><ellipse cx="-24" cy="-8" rx="8" ry="11"/><ellipse cx="-9" cy="-24" rx="8" ry="11"/><ellipse cx="9" cy="-24" rx="8" ry="11"/><ellipse cx="24" cy="-8" rx="8" ry="11"/></g>';
    $art = '<g filter="url(#ds)">'
      . '<g transform="rotate(-14 210 455)"><rect x="80" y="430" width="270" height="52" rx="10" fill="#fff"/><rect x="88" y="438" width="254" height="36" rx="6" fill="url(#kente)"/></g>'
      . '<circle cx="235" cy="250" r="120" fill="#fff"/><circle cx="235" cy="250" r="108" fill="#F4B63F"/>' . $L(160, 175, 150, $logoDark)
      . '<g transform="rotate(10 400 360)"><rect x="300" y="310" width="220" height="104" rx="52" fill="#fff"/><rect x="309" y="319" width="202" height="86" rx="43" fill="#2A2380"/>'
      . '<text x="410" y="374" text-anchor="middle" font-family="Arial Black,Arial,sans-serif" font-weight="900" font-size="34" fill="#F4B63F">UBUNTU</text></g>'
      . '<circle cx="450" cy="170" r="68" fill="#fff"/><circle cx="450" cy="170" r="58" fill="#1F8A5B"/><g transform="translate(450 175) scale(1.2)">' . $paw . '</g>'
      . '<g transform="rotate(-8 175 120)"><rect x="95" y="90" width="170" height="64" rx="12" fill="#fff"/><rect x="103" y="98" width="154" height="48" rx="8" fill="#C8372D"/>'
      . '<text x="180" y="131" text-anchor="middle" font-family="Arial Black,Arial,sans-serif" font-weight="900" font-size="24" fill="#F5EEE1">SANKOFA</text></g>'
      . '</g>';
    $defs = str_replace('</defs>', '<filter id="ds" x="-10%" y="-10%" width="120%" height="130%"><feDropShadow dx="0" dy="8" stdDeviation="8" flood-opacity=".25"/></filter></defs>', $defs);
    break;
}

echo '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 600 600" role="img" aria-label="' . htmlspecialchars($p['name'] . ' in ' . $cName) . '">' . $defs . $art . '</svg>';
