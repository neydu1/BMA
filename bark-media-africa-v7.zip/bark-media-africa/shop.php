<?php
$pageTitle = 'Shop';
$pageDesc = 'Official Bark Media Africa swag: tees, hoodies, bottles, caps and more. Pay securely with Paystack.';
require __DIR__ . '/includes/header.php';
$cats = array_values(array_unique(array_map('product_cat', $PRODUCTS)));
?>
<section class="shop-hero">
  <canvas id="shop3d" aria-hidden="true"></canvas>
  <div class="wrap shop-hero-inner">
    <h1>Rep the pack</h1>
    <p class="lede">Official BMA swag, printed in Lagos and shipped across Nigeria and beyond. Every order funds free onboarding Spaces.</p>
    <ul class="trust">
      <li>Secure checkout with Paystack</li>
      <li>Card, bank transfer and USSD</li>
      <li>Abuja delivery in 1–2 days</li>
    </ul>
  </div>
</section>
<div class="kente" aria-hidden="true"></div>

<section class="section">
  <div class="wrap">
    <div class="chips" role="group" aria-label="Filter products">
      <button class="chip" type="button" aria-pressed="true" data-shop-filter="All">All</button>
      <?php foreach ($cats as $c): ?><button class="chip" type="button" aria-pressed="false" data-shop-filter="<?= e($c) ?>"><?= e($c) ?></button><?php endforeach; ?>
    </div>
    <div class="product-grid" id="product-grid">
      <?php foreach (array_keys($PRODUCTS) as $slug) echo product_card($slug); ?>
    </div>
  </div>
</section>

<section class="section tinted">
  <div class="wrap grid g-3 shop-info">
    <div><h3>Delivery</h3><p class="muted">Abuja in 1–2 working days, the rest of Nigeria in 3–5. International orders ship in 7–14 days, or pick up free at the next meetup.</p></div>
    <div><h3>Sizing</h3><p class="muted">Tees and hoodies are a relaxed unisex fit. If you're between sizes, take the smaller one for a closer fit.</p></div>
    <div><h3>Returns</h3><p class="muted">Wrong size? Message us within 7 days of delivery and we'll swap it, as long as it's unworn.</p></div>
  </div>
</section>

<?= newsletter_block('shop') ?>
<?php require __DIR__ . '/includes/footer.php'; ?>
