<?php
$pageTitle = 'Spaces in the last 24 hours';
$pageDesc = 'Every X Space Bark Media Africa hosted or co-hosted in the last 24 hours, plus what is live now and coming up.';
require __DIR__ . '/includes/header.php';
$by = fn($st) => array_values(array_filter($SPACES, fn($s) => space_status($s) === $st));
$live = $by('live');     usort($live, fn($a, $b) => strtotime($b['start']) - strtotime($a['start']));
$recent = $by('recent'); usort($recent, fn($a, $b) => strtotime($b['end']) - strtotime($a['end']));
$upcoming = $by('upcoming'); usort($upcoming, fn($a, $b) => strtotime($a['start']) - strtotime($b['start']));
$total = array_sum(array_column(array_merge($live, $recent), 'listeners'));
$groups = [
  ['Live now', $live, 'Nobody is live right now. The next Space is listed below.'],
  ['Earlier today', $recent, 'No Spaces ended in the last 24 hours.'],
  ['Coming up', $upcoming, 'Nothing scheduled yet. Follow ' . $SITE['handle'] . ' to get notified.'],
];
?>
<?= page_banner('Spaces in the last 24 hours', 'Every X Space BMA hosted or co-hosted since this time yesterday, plus what\'s live now.') ?>

<section class="section">
  <div class="wrap">
    <div class="dial">
      <span class="dot <?= $live ? 'on' : '' ?>"></span>
      <div><b><?= count($live) ?></b><span>live now</span></div>
      <div><b><?= count($recent) ?></b><span>in the last 24h</span></div>
      <div><b><?= number_format($total) ?></b><span>listeners</span></div>
      <div><b><?= count($upcoming) ?></b><span>coming up</span></div>
    </div>
    <?php foreach ($groups as [$title, $list, $emptyText]): ?>
      <h2 class="group-title"><?= e($title) ?></h2>
      <div class="grid g-3">
        <?php if ($list): foreach ($list as $s) echo space_card($s); else: ?><div class="empty"><?= e($emptyText) ?></div><?php endif; ?>
      </div>
    <?php endforeach; ?>
  </div>
</section>

<?= join_cta() ?>
<?php require __DIR__ . '/includes/footer.php'; ?>
